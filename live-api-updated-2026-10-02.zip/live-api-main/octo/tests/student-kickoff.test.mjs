import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import vm from 'node:vm';

const source = await readFile(new URL('../bridge/octo-student.js', import.meta.url), 'utf8');

async function session() {
  let handlers, socket;
  const packets = [];
  const delays = [];
  const bridge = { connect(h) { handlers = h; }, on() {}, speaking() {}, ended() {}, log() {} };
  class Socket {
    static OPEN = 1;
    static CLOSED = 3;
    readyState = Socket.OPEN;
    send(payload) { packets.push(JSON.parse(payload)); }
    addEventListener() {}
  }
  const context = vm.createContext({
    window: { OCTO_CONFIG: { key: 'test-key', prompt: null }, LiveBridge: bridge },
    WebSocket: Socket, Date, atob,
    setTimeout(resolve, ms) { delays.push({ resolve, ms }); },
    setInterval() {},
  });
  vm.runInContext(source, context);
  context.window.OctoStudent.connect({
    async start() { socket = new Socket(); }, stop() {}, socket: () => socket,
    ready: () => true, speaking: () => false, prompt: async () => '',
  });
  await handlers.start();
  return { handlers, socket, packets, delays };
}

async function finishInjection(state, pending) {
  // Let say() enter its delayed microphone-restoration phase.
  await Promise.resolve();
  assert.equal(state.delays.length, 1, 'forwarded input has a bounded microphone exclusion window');
  assert.equal(state.delays[0].ms, 200);
  state.delays.shift().resolve();
  await pending;
}

export async function runKickoffChecks() {
  let count = 0;
  const textOnly = await session();
  const textPending = textOnly.handlers.say('도리야, 인사해줘');
  assert.deepEqual(textOnly.packets, [{
    clientContent: {
      turns: [{ role: 'user', parts: [{ text: '도리야, 인사해줘' }] }],
      turnComplete: true,
    },
  }], 'text-only kickoff must explicitly complete its user turn');
  count++;
  await finishInjection(textOnly, textPending);

  const audioInput = await session();
  const audioPending = audioInput.handlers.say('관람객 음성', {
    mimeType: 'audio/pcm;rate=16000', chunks: ['AQIDBA==', 'BQYHCA=='],
  });
  assert.deepEqual(audioInput.packets, [
    { realtimeInput: { text: '관람객 음성' } },
    { realtimeInput: { audio: { data: 'AQIDBA==', mimeType: 'audio/pcm;rate=16000' } } },
    { realtimeInput: { audio: { data: 'BQYHCA==', mimeType: 'audio/pcm;rate=16000' } } },
    { realtimeInput: { audioStreamEnd: true } },
  ], 'visitor audio keeps realtime text, PCM, and the end-of-stream marker together');
  count++;

  await Promise.resolve();
  const sent = audioInput.packets.length;
  const micFrame = JSON.stringify({ realtimeInput: {
    audio: { data: 'CQoLDA==', mimeType: 'audio/pcm;rate=16000' },
  } });
  audioInput.socket.send(micFrame);
  assert.equal(audioInput.packets.length, sent, 'live mic packets must be excluded until injected input settles');
  count++;
  await finishInjection(audioInput, audioPending);
  audioInput.socket.send(micFrame);
  assert.equal(audioInput.packets.length, sent + 1, 'live microphone streaming must resume after injection');
  assert.deepEqual(audioInput.packets.at(-1), JSON.parse(micFrame));
  count++;
  return count;
}

if (typeof process !== 'undefined' && import.meta.url === `file://${process.argv[1]}`) {
  console.log(`${await runKickoffChecks()} student kickoff checks passed`);
}
