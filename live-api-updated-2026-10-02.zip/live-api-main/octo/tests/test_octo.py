"""No Pi or Gemini key required: real HTTP/WebSocket plus installation failure checks."""
import asyncio
import base64
import importlib.util
import io
import json
import shutil
import sys
import tempfile
import unittest
import zipfile
from pathlib import Path
from unittest.mock import AsyncMock, patch

from aiohttp import web
from aiohttp.test_utils import TestClient, TestServer

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import project


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value


controller = module('controller', ROOT / 'controller/server.py')
agent = module('agent', ROOT / 'agent/agent.py')


class OctoCheck(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.work = Path(self.temp.name)
        self.data = self.work / 'data'
        self.patch = patch.multiple(controller, DATA=self.data, UPLOADS=self.data / 'uploads', STORE=self.data / 'state.json')
        self.patch.start()
        self.app = controller.create_app('http://127.0.0.1:8700')
        self.app.cleanup_ctx.clear()  # The UDP broadcast belongs on the exhibition LAN.
        self.client = TestClient(TestServer(self.app))
        await self.client.start_server()
        self.hub = self.app['hub']
        self.headers = {'X-Token': self.hub.store.token}

    async def asyncTearDown(self):
        await self.hub.stop_chat()
        await self.client.close()
        await asyncio.sleep(.25)  # Drain coalesced dashboard updates.
        self.patch.stop()
        self.temp.cleanup()

    async def test_install_auth_fixed_roles_and_validation(self):
        self.assertEqual((await self.client.get('/api/state')).status, 401)
        response = await self.client.get('/join')
        script = await response.text()
        self.assertEqual(response.status, 200)
        self.assertNotIn(self.hub.store.token, script)
        self.assertNotIn('__PROJECT_PY__', script)
        compile(controller.agent_source(), 'agent.py', 'exec')
        self.hub.store.device('pi1')
        master = self.hub.store.device('master')
        self.assertEqual(master['role'], 'master')
        self.assertEqual(master['project'], 'builtin:master')
        response = await self.client.post('/api/devices/pi1', headers=self.headers, json={'name': 'changed', 'role': 'master'})
        self.assertEqual(response.status, 400)
        self.assertEqual(self.hub.store.devices['pi1']['name'], 'pi1')
        response = await self.client.post('/api/settings', headers=self.headers, json={'default_key': 'test-key', 'max_seconds': 'NaN'})
        self.assertEqual(response.status, 400)
        self.assertEqual(self.hub.store.settings['default_key'], '')
        self.assertNotIn('repo:octo', [p['id'] for p in controller.list_projects()])
        self.assertNotIn('repo:Hayeon', [p['id'] for p in controller.list_projects()])

    async def test_dotted_keys_and_unsafe_characters(self):
        self.hub.store.device('pi1')
        key = 'AQ.test-key_123.abc'
        response = await self.client.post('/api/settings', headers=self.headers, json={'default_key': key})
        self.assertEqual(response.status, 200)
        self.assertEqual(self.hub.device_config('pi1')['env']['GEMINI_API_KEY'], key)
        response = await self.client.post('/api/devices/pi1', headers=self.headers, json={'key': key})
        self.assertEqual(response.status, 200)
        local = self.work / 'local-key'
        local.mkdir()
        with patch.multiple(agent, HOME=local, PROJECT=local/'project', CONFIG=local/'config.json', STATE=local/'state.json'):
            endpoint = agent.Agent()
            await endpoint.set_local_key(key)
            self.assertEqual(endpoint.effective_env()['GEMINI_API_KEY'], key)
            for bad in ('key with spaces', 'key\nother', 'key"', 'key`', 'x' * 513):
                with self.assertRaises(ValueError):
                    await endpoint.set_local_key(bad)
        for bad in ('key with spaces', 'key\nother', 'key"', 'key`', 'x' * 513):
            for path, body in (('/api/settings', {'default_key': bad}), ('/api/devices/pi1', {'key': bad})):
                response = await self.client.post(path, headers=self.headers, json=body)
                self.assertEqual(response.status, 400)
        self.assertEqual(self.hub.store.settings['default_key'], key)

    async def test_pair_and_agent_wire_protocol(self):
        ws = await self.client.ws_connect('/ws/pair?id=pi1&name=one')
        self.assertEqual((await ws.receive_json())['type'], 'pair_wait')
        response = await self.client.post('/api/pair/pi1/approve', headers=self.headers)
        self.assertEqual(response.status, 200)
        self.assertEqual((await ws.receive_json())['token'], self.hub.store.token)
        await ws.close()
        ws = await self.client.ws_connect('/ws/device?id=pi1', headers=self.headers)
        await ws.send_json({'type': 'hello', 'bridge': 1, 'state': 'running'})
        messages = [await ws.receive_json() for _ in range(3)]
        self.assertEqual(messages[0]['type'], 'config')
        self.assertEqual(messages[2]['msg']['type'], 'sleep')
        await ws.send_json({'type': 'event', 'name': 'start_chat', 'topic': 'unauthorized slave'})
        await asyncio.sleep(.02)
        self.assertEqual(self.hub.show['mode'], 'idle')
        await ws.close()

    async def test_bundle_hooks_and_immutable_selection(self):
        originals = {}
        for name in project.STUDENTS:
            folder = controller.REPO / name
            if not folder.is_dir() or not (folder / project.STUDENTS[name][0]).exists():
                continue  # This checkout includes only some original student folders.
            for p in folder.rglob('*'):
                if p.is_file(): originals[p] = p.read_bytes()
            path = controller.build_bundle(folder)
            with zipfile.ZipFile(path) as archive:
                self.assertIn('octo-student.js', archive.namelist())
                self.assertIn('octo-config.js', archive.read('index.html').decode())
                self.assertNotIn('key.js', archive.namelist())
                source = project.STUDENTS[name][0]
                self.assertIn('OctoStudent.connect', archive.read(source).decode())
                if name == 'Yunjung':
                    compile(archive.read('server.py'), 'server.py', 'exec')
                if name == 'ParkSoyeon':
                    self.assertNotIn('if (localApiKey) connectSafely(true);', archive.read('index.html').decode())
            path.unlink()
        self.assertTrue(all(p.read_bytes() == data for p, data in originals.items()))
        rec = self.hub.store.device('pi1')
        rec['project'] = 'repo:minseo'
        message = self.hub.deploy_message('pi1')
        rec['project'] = 'repo:seoyoungchae'
        response = await self.client.get(message['path'], headers=self.headers)
        self.assertEqual(response.status, 200)
        with zipfile.ZipFile(io.BytesIO(await response.read())) as archive:
            self.assertIn('말꼬리', archive.read('app.js').decode())
        rec['project'] = 'repo:minseo'
        response = await self.client.post('/api/devices/pi1/deploy', headers=self.headers)
        self.assertEqual((await response.json())['queued'], True)
        self.assertTrue(rec['deploy_pending'])

    async def test_shell_project_upload_keeps_face_and_adds_control(self):
        source = controller.REPO / 'HYOSUN' / 'HYOSUN.sh'
        original = source.read_bytes()
        # The actual upload name differs from the student's repo folder.
        folder = self.work / 'HYOSUN-sh'
        folder.mkdir()
        shutil.copy2(source, folder / source.name)
        manifest = project.guess_manifest(folder)
        self.assertEqual(manifest['student'], 'HYOSUN-shell')
        self.assertEqual(manifest['browser']['url'], 'http://localhost:8080/')
        self.assertNotIn('bash', manifest['run'][0])
        bundle = controller.build_bundle(folder, manifest)
        try:
            with zipfile.ZipFile(bundle) as archive:
                for name in ('face.js', 'pcm-recorder.js', 'octo-student.js', 'live-bridge.js'):
                    self.assertIn(name, archive.namelist())
                code = archive.read('app.js').decode()
                self.assertIn('OctoStudent.connect', code)
                self.assertIn('LiveBridge owns reconnects', code)
                self.assertNotIn('\nconnect();', code)
                self.assertIn('gemini-3.8-live', code)
                self.assertIn('octo-config.js', archive.read('index.html').decode())
                self.assertEqual(archive.read('face.js').decode(), project.shell_assets(folder)['face.js'])
                installed = self.work / 'installed'
                installed.mkdir()
                project.extract_zip(bundle, installed)
                with patch.multiple(agent, HOME=installed, PROJECT=installed, CONFIG=installed/'config.json', STATE=installed/'state.json'):
                    endpoint = agent.Agent()
                    endpoint.state.update(manifest=manifest, env={'GEMINI_API_KEY': 'test-key'})
                    endpoint.render_files()
                    self.assertIn('test-key', (installed/'key.js').read_text())
                    self.assertIn('test-key', (installed/'octo-config.js').read_text())
        finally:
            bundle.unlink()
        self.assertEqual(source.read_bytes(), original)

    async def test_student_shell_uploads_have_reachable_bridge_and_config(self):
        for name in ('eunseol', 'gaeun', 'soyeon', 'yunjung', 'minseo', 'minjeong', 'seoyoungchae'):
            with self.subTest(student=name):
                source = controller.REPO / name / (name + '.sh')
                if not source.exists():
                    source = next((controller.REPO / name).glob('*.sh'))
                original = source.read_bytes()
                folder = self.work / ('uploaded-' + name)
                folder.mkdir()
                shutil.copy2(source, folder / source.name)
                manifest = project.guess_manifest(folder)
                self.assertEqual(manifest['student'], name + '-shell')
                page = 'heol.html' if name == 'minjeong' else ''
                self.assertEqual(manifest['browser']['url'], 'http://localhost:8080/' + page)
                self.assertEqual(manifest['run'], ['python3 -m http.server 8080 --bind 127.0.0.1'])
                bundle = controller.build_bundle(folder, manifest)
                installed = self.work / ('installed-' + name)
                installed.mkdir()
                try:
                    project.extract_zip(bundle, installed)
                    with patch.multiple(agent, HOME=installed, PROJECT=installed, CONFIG=installed/'config.json', STATE=installed/'state.json'):
                        endpoint = agent.Agent()
                        endpoint.state.update(manifest=manifest, env={'GEMINI_API_KEY': 'test-key'})
                        endpoint.render_files()
                    html = (installed / 'index.html').read_text()
                    # Every script loaded by the served page exists at its root.
                    import re
                    for script in re.findall(r'<script[^>]*src=["\']([^"\']+)', html):
                        if not script.startswith(('https:', 'http:')):
                            self.assertTrue((installed / script).is_file(), script)
                    self.assertLess(html.index('octo-student.js'), html.index('</head>'))
                    config = (installed / 'octo-config.js').read_text()
                    self.assertIn('test-key', config)
                    self.assertIn('ws://127.0.0.1:8765/bridge', config)
                    code = (installed / project.STUDENTS[manifest['student']][0]).read_text()
                    self.assertIn('OctoStudent.connect', code)
                    self.assertNotIn('reconnectTimer = setTimeout(connect', code)
                    self.assertEqual(source.read_bytes(), original)
                finally:
                    bundle.unlink()

    async def test_seoyoungchae_serves_adapted_html_instead_of_shell_copy(self):
        folder = controller.REPO / 'seoyoungchae'
        manifest = project.guess_manifest(folder)
        self.assertEqual(manifest['student'], 'seoyoungchae-shell')
        self.assertEqual(manifest['browser']['url'], 'http://localhost:8080/')
        self.assertFalse(any('bash' in command for command in manifest['run']))
        bundle = controller.build_bundle(folder, manifest)
        try:
            with zipfile.ZipFile(bundle) as archive:
                html = archive.read('index.html').decode()
                self.assertIn('OctoStudent.connect', html)
                self.assertIn('buildPersonaPrompt()', html)
                self.assertIn('await playCtx.resume()', html)
                self.assertIn('await micCtx.resume()', html)
                self.assertIn('<svg', html)
                for name in ('octo-student.js', 'live-bridge.js', 'pcm-recorder.js'):
                    self.assertIn(name, archive.namelist())
        finally:
            bundle.unlink()

    async def test_minseo_face_assets_and_minjeong_http_lifecycle(self):
        for name in ('minseo', 'minjeong'):
            folder = controller.REPO / name
            manifest = project.guess_manifest(folder)
            bundle = controller.build_bundle(folder, manifest)
            try:
                with zipfile.ZipFile(bundle) as archive:
                    html = archive.read('index.html').decode()
                    if name == 'minseo':
                        self.assertIn('FACE.mount', html)
                        self.assertEqual(archive.read('face.js').decode(), project.shell_assets(folder)['face.js'])
                    else:
                        html = archive.read('heol.html').decode()
                        self.assertEqual(html, archive.read('index.html').decode())
                        for script in ('octo-config.js', 'live-bridge.js', 'octo-student.js'):
                            self.assertLess(html.index(f'src="{script}"'), html.index('</head>'))
                        self.assertIn('await inCtx.resume(); await outCtx.resume();', html)
                        self.assertIn('micStream.getTracks().forEach(t => t.stop())', html)
                        self.assertLess(html.index('OctoStudent.connect'), html.rindex('})();'))
                        self.assertNotIn('setTimeout(start, 3000)', html)
                        self.assertNotIn('file://', manifest['browser']['url'])
            finally:
                bundle.unlink()

    async def test_show_ack_audio_fade_and_stop(self):
        class Endpoint:
            def __init__(self, id): self.id, self.messages = id, []
            async def send_json(endpoint, msg):
                endpoint.messages.append(msg)
                if msg.get('msg', {}).get('type') == 'kickoff':
                    owner, future = self.hub.pending[msg['req']]
                    self.assertEqual(owner, endpoint.id)
                    future.set_result({'ok': True})
        for id in ('master', 'pi1', 'pi2', 'pi3'):
            self.hub.store.device(id)
            self.hub.sockets[id] = Endpoint(id)
            self.hub.live[id] = {'bridge': 1}
        self.hub.store.settings.update(others_delay=0, max_seconds=10, fade_seconds=.03)
        audio = {'mimeType': 'audio/pcm;rate=16000', 'chunks': [base64.b64encode(b'\x01\x00' * 512).decode()]}
        await self.hub.start_chat('weather', target='pi1', audio=audio)
        with self.assertRaises(web.HTTPConflict): await self.hub.start_chat('another')
        await asyncio.sleep(.02)
        self.assertEqual(set(self.hub.show['active']), {'pi1', 'pi2', 'pi3'})
        kickoff = next(m['msg'] for m in self.hub.sockets['pi1'].messages if m.get('msg', {}).get('type') == 'kickoff')
        self.assertEqual(kickoff['audio'], audio)
        await self.hub.fade_chat()
        await asyncio.sleep(.08)
        self.assertEqual(self.hub.show['mode'], 'idle')
        for id in ('pi1', 'pi2', 'pi3'):
            self.assertEqual(self.hub.voice_for(id)['type'], 'sleep')
        self.assertEqual(self.hub.voice_for('master')['type'], 'wake')
        await self.hub.start_chat('restart', target='pi2')
        await self.hub.stop_chat()
        await asyncio.sleep(.03)
        self.assertEqual(self.hub.show['active'], [])
        for bad in ({'mimeType': 'audio/wav', 'chunks': []}, {'mimeType': audio['mimeType'], 'chunks': ['!!!!']}):
            with self.assertRaises(web.HTTPBadRequest): controller.validate_audio(bad)
        self.hub.sockets.clear()

    async def test_zip_safety_manifest_and_original_prompt_restore(self):
        bad = self.work / 'bad.zip'
        with zipfile.ZipFile(bad, 'w') as archive: archive.writestr('../escape', 'no')
        with self.assertRaises(ValueError): project.extract_zip(bad, self.work / 'out')
        with self.assertRaises(ValueError): project.validate_manifest({'files': {'../key.js': 'bad'}})
        local = self.work / 'endpoint'
        local.mkdir()
        art = local / 'project'
        art.mkdir()
        (art / 'persona.txt').write_text('student original')
        with patch.multiple(agent, HOME=local, PROJECT=art, CONFIG=local/'config.json', STATE=local/'state.json', SETUP_MARK=local/'setup.done'):
            endpoint = agent.Agent()
            endpoint.state.update(manifest={'prompt_file': 'persona.txt'}, prompt='edited')
            endpoint.render_files()
            self.assertEqual((art/'persona.txt').read_text(), 'edited')
            endpoint.state['prompt'] = None
            endpoint.render_files()
            self.assertEqual((art/'persona.txt').read_text(), 'student original')

    async def test_failed_setup_restores_previous_project(self):
        local = self.work / 'endpoint'
        local.mkdir()
        art = local/'project'
        art.mkdir()
        (art/'old.txt').write_text('keep me')
        new = io.BytesIO()
        with zipfile.ZipFile(new, 'w') as archive: archive.writestr('new.txt', 'new')
        download = web.Application()
        download.router.add_get('/new.zip', lambda _: web.Response(body=new.getvalue()))
        server = TestServer(download)
        await server.start_server()
        try:
            with patch.multiple(agent, HOME=local, PROJECT=art, CONFIG=local/'config.json', STATE=local/'state.json', SETUP_MARK=local/'setup.done'):
                endpoint = agent.Agent()
                endpoint.config['token'] = 'test'
                endpoint.base = str(server.make_url('/')).rstrip('/')
                endpoint.state.update(project='old', manifest={'run': []}, running=True)
                endpoint.start = AsyncMock(side_effect=[RuntimeError('failed setup'), None])
                with self.assertRaisesRegex(RuntimeError, 'failed setup'):
                    await endpoint.deploy({'project': 'new', 'path': '/new.zip', 'manifest': {'run': []}})
                self.assertEqual(endpoint.state['project'], 'old')
                self.assertEqual((art/'old.txt').read_text(), 'keep me')
                self.assertFalse((art/'new.txt').exists())
                self.assertEqual(endpoint.start.await_count, 2)
        finally:
            await server.close()


if __name__ == '__main__':
    unittest.main()
