import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import vm from 'node:vm';

const source = await readFile(new URL('../bridge/octo-student.js', import.meta.url), 'utf8');

export async function runAdapterChecks() {
  let count = 0;
  for (const prompt of [null, '', '   ', '중앙에서 수정한 성격']) {
    let handlers, ws, ready = false;
    const packets = [];
    const listeners = {};
    const bridge = { connect(h) { handlers = h; }, on() {}, speaking() {}, ended() {}, log() {} };
    class Socket {
      static CLOSED = 3;
      static CLOSING = 2;
      readyState = 1;
      send(packet) { packets.push(JSON.parse(packet)); }
      addEventListener(name, fn) { listeners[name] = fn; }
    }
    const context = vm.createContext({
      window: { OCTO_CONFIG: { key: 'test-key', prompt }, LiveBridge: bridge },
      WebSocket: Socket, setTimeout, setInterval() {}, Date,
    });
    vm.runInContext(source, context);
    context.window.OctoStudent.connect({
      async start() {
        ws = new Socket();
        setTimeout(() => {
          ws.send(JSON.stringify({ setup: { systemInstruction: { parts: [{ text: '원래 학생 성격' }] } } }));
          ready = true;
        }, 0);
      },
      stop() {}, socket: () => ws, ready: () => ready,
      speaking: () => false, prompt: async () => '원래 학생 성격',
    });
    await handlers.start();
    assert.equal(packets[0].setup.systemInstruction.parts[0].text, prompt?.trim() ? prompt : '원래 학생 성격');
    count++;
  }
  let handlers, ws;
  class ClosedSocket {
    static CLOSED = 3;
    readyState = 1;
    send() {}
    addEventListener(name, fn) {
      if (name === 'close') setTimeout(() => {
        this.readyState = 3;
        fn({ code: 1007, reason: 'API key not valid' });
      }, 0);
    }
  }
  const context = vm.createContext({
    window: { OCTO_CONFIG: { key: 'test-key', prompt: null }, LiveBridge: {
      connect(h) { handlers = h; }, on() {}, speaking() {}, ended() {}, log() {},
    } },
    WebSocket: ClosedSocket, setTimeout, setInterval() {}, Date,
  });
  vm.runInContext(source, context);
  context.window.OctoStudent.connect({
    async start() { ws = new ClosedSocket(); }, stop() {}, socket: () => ws,
    ready: () => false, speaking: () => false, prompt: async () => '',
  });
  await assert.rejects(handlers.start(), /1007.*API key not valid/);
  return count + 1;
}

if (typeof process !== 'undefined' && import.meta.url === `file://${process.argv[1]}`) {
  console.log(`${await runAdapterChecks()} student adapter checks passed`);
}
