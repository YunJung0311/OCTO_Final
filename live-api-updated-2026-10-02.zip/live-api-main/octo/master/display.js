// Original pixel interpretation of the listening-orb idea. No runtime dependencies.
export class PixelDisplay {
  constructor(canvas) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d', { alpha: false });
    canvas.width = canvas.height = 96;
    this.state = 'connecting';
    this.level = 0;
    this.target = 0;
    this.lastInput = 0;
    this.lastFrame = 0;
    this.reduced = matchMedia('(prefers-reduced-motion: reduce)').matches;
    this.frame = this.frame.bind(this);
    this.raf = requestAnimationFrame(this.frame);
  }
  setState(state) {
    this.state = state;
    this.target = this.level = 0;
    this.canvas.dataset.state = state;
    const labels = { connecting: '마이크 연결 중', idle: '관람객의 말을 듣는 중', chat: '학생 에이전트 대화 중', offline: '마이크 연결 끊김' };
    this.canvas.setAttribute('aria-label', labels[state] || state);
  }
  input(rms) {
    this.lastInput = performance.now();
    this.target = Math.min(1, Math.max(0, (Number(rms) - 0.008) * 9));
    if (!Number.isFinite(this.target)) this.target = 0;
  }
  frame(now) {
    this.raf = requestAnimationFrame(this.frame);
    if (document.hidden || now - this.lastFrame < 1000 / 30) return;
    this.lastFrame = now;
    if (now - this.lastInput > 200) this.target = 0;
    this.level += (this.target - this.level) * (this.target > this.level ? 0.5 : 0.16);
    this.draw(this.reduced ? 0 : now / 1000);
  }
  draw(t) {
    const ctx = this.ctx;
    ctx.fillStyle = '#101318'; ctx.fillRect(0, 0, 96, 96);
    const active = this.state === 'idle';
    const energy = active ? this.level : 0;
    const radius = 28 + Math.round(Math.sin(t * 1.5) * 1.2 + energy * 3);
    const dot = (x, y, color, size = 2) => {
      ctx.fillStyle = color; ctx.fillRect(Math.round(x), Math.round(y), size, size);
    };
    // Stepped dotted globe. Slow breathing gives a visible idle without fake speech.
    for (let y = -radius; y <= radius; y += 4) {
      for (let x = -radius; x <= radius; x += 4) {
        const d = Math.sqrt(x*x + y*y);
        if (d > radius || d < radius - 3) continue;
        const front = Math.sin(Math.atan2(y, x) + t * .55) > -.25;
        dot(47 + x, 47 + y, this.state === 'offline' ? '#605851' : front ? '#a7bdb6' : '#364c48');
      }
    }
    if (this.state === 'offline') {
      for (let i = -5; i <= 5; i += 2) { dot(47+i,47+i,'#d49b73'); dot(47+i,47-i,'#d49b73'); }
    } else if (this.state === 'connecting') {
      for (let i = 0; i < 3; i++) dot(37+i*10,47, Math.floor(t*2)%3 === i ? '#e1edcf' : '#526358',3);
    } else if (this.state === 'chat') {
      // Eight satellites represent the student group, not measured individual status.
      for (let i=0; i<8; i++) {
        const a = i*Math.PI/4 + t*.22;
        dot(47+Math.cos(a)*18,47+Math.sin(a)*18, i === Math.floor(t*2)%8 ? '#e1edcf' : '#829c8d',3);
      }
      dot(46,46,'#e1edcf',4);
    } else {
      // RMS envelope visualization, not a frequency spectrum or transcription claim.
      for (let i = -8; i <= 8; i++) {
        const envelope = Math.pow(Math.max(0, 1 - Math.abs(i)/9), .6);
        const ripple = .4 + .6 * Math.abs(Math.sin(i*.68 - t*7));
        const height = Math.round(energy * 15 * envelope * ripple);
        for (let y = -height; y <= height; y += 3)
          dot(47+i*3,47+y, height > 2 ? '#dcebc7' : '#829c8d');
      }
    }
  }
  destroy() { cancelAnimationFrame(this.raf); }
}
