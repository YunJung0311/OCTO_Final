// Loaded only into deployment copies; the student's audio and display code still runs.
(() => {
  window.GEMINI_KEY = window.OCTO_CONFIG.key;
  window.LOCAL_CONFIG = { apiKey: window.OCTO_CONFIG.key };
  window.OctoStudent = {
    connect(hooks) {
      const bridge = window.LiveBridge;
      let initializing = false;
      let injecting = false;
      let telemetry = null;
      const send = (payload) => hooks.socket().send(JSON.stringify(payload));
      bridge.connect({
        async start() {
          initializing = true;
          try {
            await hooks.start();
            const ws = hooks.socket();
            if (!ws) throw new Error("학생 세션을 시작하지 못함 (키·마이크·로그 확인)");
            const stats = telemetry = { ws, sent: 0, received: 0, peak: 0, lastReport: Date.now(), input: "", output: "" };
            const original = ws.send.bind(ws);
            ws.send = (payload) => {
              if (typeof payload === "string") {
                const msg = JSON.parse(payload);
                if (initializing && (msg.clientContent || msg.realtimeInput?.text)) return;
                if (msg.setup && typeof window.OCTO_CONFIG.prompt === "string" && window.OCTO_CONFIG.prompt.trim()) {
                  msg.setup.systemInstruction = { parts: [{ text: window.OCTO_CONFIG.prompt }] };
                  payload = JSON.stringify(msg);
                }
                if (!injecting && msg.realtimeInput?.audio && ws.octoInjecting) return;
                const pcm = msg.realtimeInput?.audio?.data;
                if (pcm) {
                  stats.sent++;
                  const raw = atob(pcm);
                  for (let i = 0; i + 1 < raw.length; i += 64) {
                    const value = raw.charCodeAt(i) | (raw.charCodeAt(i + 1) << 8);
                    stats.peak = Math.max(stats.peak, Math.abs((value >= 32768 ? value - 65536 : value) / 32768));
                  }
                }
              } else if (!injecting && ws.octoInjecting) return;
              original(payload);
            };
            let closeError = "";
            ws.addEventListener("message", async (event) => {
              try {
                const message = JSON.parse(typeof event.data === "string" ? event.data : await event.data.text());
                if (message.error) bridge.log("API 오류:", message.error.message || JSON.stringify(message.error));
                const sc = message.serverContent;
                if (!sc) return;
                stats.input += sc.inputTranscription?.text || "";
                stats.output += sc.outputTranscription?.text || "";
                for (const part of sc.modelTurn?.parts || []) {
                  if (part.inlineData?.mimeType?.startsWith("audio/pcm") && part.inlineData.data) {
                    if (!stats.received) bridge.log("응답 오디오 수신 시작");
                    stats.received++;
                  }
                }
                if (sc.turnComplete) {
                  if (stats.input.trim()) bridge.log("인식한 말:", stats.input.trim().slice(0, 200));
                  if (stats.output.trim()) bridge.log("AI 응답:", stats.output.trim().slice(0, 300));
                  stats.input = stats.output = "";
                }
              } catch (error) { bridge.log("응답 진단 실패:", error.message); }
            });
            ws.addEventListener("close", (event) => {
              closeError = `Live 연결 종료 (${event.code}): ${event.reason || "사유 없음"}`;
              bridge.log(closeError);
              bridge.ended();
            });
            const until = Date.now() + 45000;
            while (!hooks.ready()) {
              if (ws.readyState === WebSocket.CLOSED) throw new Error(closeError || "Live 연결이 준비 전에 종료됨");
              if (Date.now() > until) throw new Error("Live 세션 준비 시간 초과 (45초)");
              await new Promise((resolve) => setTimeout(resolve, 100));
            }
            bridge.log("Live 준비 완료", JSON.stringify(hooks.audioState?.() || {}));
          } catch (error) {
            await hooks.stop();
            throw error;
          } finally {
            initializing = false;
          }
        },
        stop: () => hooks.stop(),
        async say(text, audio) {
          const ws = hooks.socket();
          ws.octoInjecting = true;
          injecting = true;
          try {
            send(hooks.relay ? { type: "text", text } : audio ? { realtimeInput: { text } } : {
              clientContent: { turns: [{ role: "user", parts: [{ text }] }], turnComplete: true },
            });
            if (audio) {
              for (const data of audio.chunks) {
                if (hooks.relay) ws.send(Uint8Array.from(atob(data), (c) => c.charCodeAt(0)));
                else send({ realtimeInput: { audio: { data, mimeType: audio.mimeType } } });
              }
              send(hooks.relay ? { type: "audioStreamEnd" } : { realtimeInput: { audioStreamEnd: true } });
            }
          } finally {
            injecting = false;
            // Keep live microphone packets out of the forwarded visitor's input turn.
            await new Promise((resolve) => setTimeout(resolve, 200));
            ws.octoInjecting = false;
          }
        },
      });
      bridge.on("connected", async () => {
        try { bridge.prompt(await hooks.prompt()); } catch (error) { bridge.log(error.message); }
      });
      let last = false;
      setInterval(() => {
        const on = hooks.ready() && hooks.speaking();
        if (on !== last) { last = on; bridge.speaking(on); }
        const stats = telemetry;
        if (hooks.ready() && stats && stats.ws === hooks.socket() && Date.now() - stats.lastReport >= 5000) {
          bridge.log(`음성 진단: 마이크 전송 ${stats.sent}프레임, 입력 peak ${stats.peak.toFixed(3)}, 응답 ${stats.received}조각, 재생 ${!!on}`,
            JSON.stringify(hooks.audioState?.() || {}));
          stats.sent = stats.received = stats.peak = 0;
          stats.lastReport = Date.now();
        }
      }, 100);
      // Built-in retry lives in LiveBridge; there is no student-specific reconnect loop.
    },
  };
})();
