"""Project packaging rules shared by the controller and installed Pi endpoint."""

import json
import re
import shlex
import shutil
import unicodedata
import zipfile
from pathlib import PurePosixPath

SKIP_DIRS = {'.git', '.venv', 'venv', '__pycache__', 'node_modules', '__MACOSX', 'octo', 'local-server'}
SKIP_FILES = {'.DS_Store', 'Thumbs.db', 'desktop.ini', 'key.js', 'config.local.js'}
LIMIT = 500 * 1024 * 1024

# Hooks execute in the student's own script scope, only in the deployment copy.
STUDENTS = {
    'minjeong-shell': ('heol.html', 'start', 'octoStop()', 'setupDone', 'ws', 'playing', 'SYSTEM_PROMPT'),
    'minseo-shell': ('app.js', 'connect', 'reconnectPending = false; disconnect(); cleanup()', 'ready', 'ws', 'isSpeaking()', 'SYSTEM_INSTRUCTION'),
    'seoyoungchae-shell': ('index.html', 'connect', 'status = "stopped"; ready = false; clearTimeout(reconnectTimer); const old = ws; ws = null; if (old) { old.onopen = old.onmessage = old.onclose = old.onerror = null; old.close(); } cleanup()', 'ready', 'ws', 'isSpeaking()', 'buildPersonaPrompt()'),
    'eunseol-shell': ('app.js', 'connect', 'manualStop = true; clearTimeout(reconnectTimer); disconnect(); cleanup()', 'ready', 'ws', 'isSpeaking()', 'SYSTEM_INSTRUCTION'),
    'gaeun-shell': ('index.html', 'startSession', 'stopSession("octo")', 'sessionReady', 'ws', 'isAgentSpeaking()', 'document.getElementById("systemPrompt").value'),
    'soyeon-shell': ('index.html', 'connectSafely', 'stopSession(); cleanupAudio()', 'sessionActive', 'ws', 'currentSources.length > 0', 'SYSTEM_INSTRUCTION'),
    'yunjung-shell': ('index.html', 'connect', 'disconnect(); cleanup()', 'ready', 'ws', 'isSpeaking()', 'PERSONA'),
    'HYOSUN-shell': ('app.js', 'connect', 'manualStop = true; clearTimeout(retryTimer); disconnect(); cleanup()', 'ready', 'ws', 'isSpeaking()', 'SYSTEM_INSTRUCTION'),
    'minseo': ('app.js', 'connect', 'disconnect(); teardown()', 'sessionActive', 'ws', 'isSpeaking()', 'sysPrompt'),
    'sunny': ('app.js', 'connect', 'disconnect(); cleanup()', 'ready', 'ws', 'isSpeaking()', 'SYSTEM_INSTRUCTION'),
    'Eunseol': ('app.js', 'connect', 'disconnect(); cleanup()', 'ready', 'ws', 'isSpeaking()', 'SYSTEM_INSTRUCTION'),
    'HuhGaeun': ('index.html', 'startSession', 'stopSession("octo")', 'sessionReady', 'ws', 'isAgentSpeaking()', 'document.getElementById("systemPrompt").value'),
    'ParkSoyeon': ('index.html', 'connectSafely', 'stopSession(); cleanupAudio()', 'sessionActive', 'ws', 'currentSources.length > 0', 'SYSTEM_INSTRUCTION'),
    'seoyoungchae': ('index.html', 'startSession', 'stopSession()', 'isReady', 'ws', 'isSpeaking()', 'buildPersonaPrompt()'),
    'Yunjung': ('app.js', 'start', 'if (current) finish(current)', 'current?.ready', 'current?.socket', 'current?.player?.speaking', '(await (await fetch("persona.txt")).text())'),
}


def shell_assets(folder):
    """Read literal embedded browser assets without executing the installer.

    Detect by content so an uploaded/renamed folder behaves like the repo copy.
    Other shell projects continue using their original launch command.
    """
    for script in sorted(folder.glob('*.sh')):
        code = script.read_text()
        assets = {name: content for name, marker, content in re.findall(
            r'^cat > "\$DIR/([^"/]+)" <<\'(\w+)\'\n(.*?)^\2\s*$', code, re.M | re.S,
        )}
        if shell_student(assets):
            return assets
    return {}


def shell_student(assets):
    app, html = assets.get('app.js', ''), assets.get('index.html', '')
    if 'const SYSTEM_PROMPT' in assets.get('heol.html', '') and 'async function start()' in assets['heol.html']:
        return 'minjeong-shell'
    if not html:
        return None
    if 'const SYSTEM_INSTRUCTION' in app and '말꼬리' in app and 'face.js' in assets:
        return 'minseo-shell'
    if 'const SYSTEM_INSTRUCTION' in app and 'function scheduleRetry' in app:
        return 'HYOSUN-shell'
    if 'const SYSTEM_INSTRUCTION' in app and 'let manualStop' in app and 'reconnectTimer' in app:
        return 'eunseol-shell'
    if 'const SYSTEM_INSTRUCTION' in app and 'reconnectPending' in app and 'face.js' in assets:
        return 'minseo-shell'
    if 'function buildPersonaPrompt()' in html and 'async function connect()' in html:
        return 'seoyoungchae-shell'
    if 'function isAgentSpeaking()' in html and 'sessionReady' in html:
        return 'gaeun-shell'
    if 'const SYSTEM_INSTRUCTION' in html and 'async function connectSafely()' in html:
        return 'soyeon-shell'
    if 'const PERSONA' in html and 'function isSpeaking()' in html:
        return 'yunjung-shell'
    return None


def safe_parts(raw):
    name = unicodedata.normalize('NFC', str(raw).replace('\\', '/'))
    parts = PurePosixPath(name).parts
    if name.startswith('/') or '..' in parts or re.match(r'^[A-Za-z]:', name):
        raise ValueError(f'폴더 밖 경로: {raw}')
    if not parts or any(p in SKIP_DIRS for p in parts) or parts[-1] in SKIP_FILES or parts[-1].startswith(('._', '.env')):
        return None
    return parts


def extract_zip(src, dest):
    with zipfile.ZipFile(src) as archive:
        infos = archive.infolist()
        if len(infos) > 10000 or sum(i.file_size for i in infos) > LIMIT:
            raise ValueError('압축을 푼 작품은 500MB / 10,000파일까지')
        for info in infos:
            name = info.filename
            if not info.flag_bits & 0x800:
                for encoding in ('utf-8', 'cp949'):
                    try:
                        name = info.filename.encode('cp437').decode(encoding)
                        break
                    except UnicodeError:
                        pass
            parts = safe_parts(name)
            if not parts or info.is_dir():
                continue
            if info.external_attr >> 16 & 0o170000 == 0o120000:
                raise ValueError('작품 zip에 심볼릭 링크를 넣을 수 없음')
            target = dest.joinpath(*parts)
            target.parent.mkdir(parents=True, exist_ok=True)
            with archive.open(info) as source, open(target, 'wb') as out:
                shutil.copyfileobj(source, out)


def validate_manifest(manifest):
    if not isinstance(manifest, dict):
        raise ValueError('live.json은 JSON 객체여야 함')
    if not isinstance(manifest.get('run', []), list) or any(not isinstance(c, str) for c in manifest.get('run', [])):
        raise ValueError('run은 명령 문자열의 배열')
    if not isinstance(manifest.get('setup', ''), str):
        raise ValueError('setup은 명령 문자열')
    browser = manifest.get('browser')
    if browser is not None and (not isinstance(browser, dict) or not isinstance(browser.get('url'), str)):
        raise ValueError('browser.url이 필요함')
    files = manifest.get('files') or {}
    if not isinstance(files, dict) or any(not isinstance(v, str) for v in files.values()):
        raise ValueError('files는 경로와 템플릿 문자열의 객체')
    for rel in [*files, *([manifest['prompt_file']] if manifest.get('prompt_file') else [])]:
        name = str(rel).replace('\\', '/')
        if not name or name.startswith('/') or '..' in PurePosixPath(name).parts or re.match(r'^[A-Za-z]:', name):
            raise ValueError(f'잘못된 manifest 경로: {rel}')
    return manifest


def guess_manifest(folder):
    live = folder / 'live.json'
    if live.exists():
        return validate_manifest(json.loads(live.read_text()))
    names = {p.name for p in folder.iterdir()}
    manifest = {'name': folder.name, 'setup': '', 'run': [], 'browser': None, 'files': {},
                'prompt_file': next((n for n in ('persona.txt', 'prompt.txt') if n in names), None)}
    if 'server.py' in names:
        python = 'python3'
        if 'requirements.txt' in names:
            manifest['setup'] = 'python3 -m venv .venv && .venv/bin/pip install -r requirements.txt'
            python = '.venv/bin/python'
        manifest['run'] = [f'{python} server.py --port 8000']
        manifest['browser'] = {'url': 'http://localhost:8000/'}
        manifest['files']['.env'] = 'GEMINI_API_KEY=${GEMINI_API_KEY}\n'
    elif (assets := shell_assets(folder)):
        manifest['student'] = shell_student(assets)
        manifest['run'] = ['python3 -m http.server 8080 --bind 127.0.0.1']
        manifest['browser'] = {'url': 'http://localhost:8080/'}
        manifest['files']['key.js'] = 'window.GEMINI_KEY = "${GEMINI_API_KEY}";\n'
        if 'config.local.js' in assets.get('index.html', assets.get('heol.html', '')):
            manifest['files']['config.local.js'] = 'window.LOCAL_CONFIG = { apiKey: "${GEMINI_API_KEY}" };\n'
        if manifest['student'] == 'minjeong-shell':
            manifest['browser']['url'] += 'heol.html'
    elif folder.name in STUDENTS and 'index.html' in names:
        # A launcher alongside HTML must not overwrite/bypass the adapted page.
        manifest['run'] = ['python3 -m http.server 8080 --bind 127.0.0.1']
        manifest['browser'] = {'url': 'http://localhost:8080/'}
    elif (scripts := sorted(n for n in names if n.endswith('.sh'))):
        manifest['run'] = [f'bash {shlex.quote(scripts[0])}']
    elif (htmls := sorted(n for n in names if n.endswith('.html'))):
        from urllib.parse import quote
        page = '' if 'index.html' in names else quote(htmls[0])
        manifest['run'] = ['python3 -m http.server 8080 --bind 127.0.0.1']
        manifest['browser'] = {'url': f'http://localhost:8080/{page}'}
    if names & {'key.example.js', 'key.js'}:
        manifest['files']['key.js'] = 'window.GEMINI_KEY = "${GEMINI_API_KEY}";\n'
    if names & {'config.example.js', 'config.local.js'}:
        manifest['files']['config.local.js'] = 'window.LOCAL_CONFIG = { apiKey: "${GEMINI_API_KEY}" };\n'
    if folder.name in STUDENTS and not manifest.get('student'):
        manifest['student'] = folder.name
    return manifest


def deployment_files(folder, student, bridge_dir):
    """Return replacements for the archive; never write to the source project."""
    if student not in STUDENTS:
        return {}
    file, start, stop, ready, socket, speaking, prompt = STUDENTS[student]
    assets = shell_assets(folder) if student.endswith('-shell') else {}
    if student.endswith('-shell') and not assets:
        raise ValueError('실행 스크립트의 내장 파일 구조를 확인하세요')
    code = assets[file] if assets else (folder / file).read_text()
    # New text-free installers retain their own character and face; only the
    # deployment copy delegates automatic session ownership to LiveBridge.
    if student == 'minseo-shell' and 'let retryTimer' in code:
        stop = 'manualStop = true; clearTimeout(retryTimer); disconnect(); cleanup()'
    if student == 'gaeun-shell' and 'const CONFIG = {' in code:
        prompt = 'CONFIG.systemInstruction'
        stop = 'disconnect()'
    if student in {'HYOSUN-shell', 'minseo-shell', 'gaeun-shell'}:
        code = code.replace('if (manualStop) return;', 'return; // LiveBridge owns reconnects', 1)
        code = re.sub(r'^\s*window.addEventListener\("load",.*setTimeout\((?:connect|startSession), 300\).*$', '', code, flags=re.M)
        code = re.sub(r'if \(!ws && !starting\) \{ manualStop = false; (?:connect|startSession)\(\); \}', '', code)
    if student == 'HYOSUN-shell':
        # The bridge owns wake/reconnect; keep the face animated in idle.
        code = code.replace('if (manualStop) return;', 'return; // LiveBridge owns reconnects', 1)
        code = re.sub(r'^connect\(\);\s*$', '// Waiting for LiveBridge wake.', code, flags=re.M)
        code = code.replace('const MODEL = "gemini-3.1-flash-live-preview";', 'const MODEL = "gemini-3.8-live";')
    if student in {'eunseol-shell', 'yunjung-shell', 'soyeon-shell', 'seoyoungchae-shell'}:
        # Only the bridge may wake a student or retry a failed Live session.
        code = re.sub(r'^\s*(?:if \(!FORCE\) )?(?:connect|connectSafely)\(\);[^\n]*$', '', code, flags=re.M)
        code = re.sub(r'reconnectTimer = setTimeout\((?:connect|connectSafely), RECONNECT_MS\);', '/* LiveBridge owns reconnects */', code)
        code = re.sub(r'if \(!ws && !reconnectTimer\) connect\(\);', '', code)
        code = re.sub(r'if \(!ws && status !== "connecting" && !FORCE\) connect\(\);', '', code)
    if student in {'seoyoungchae-shell', 'yunjung-shell'}:
        code = code.replace('playCtx = new AudioContext({ sampleRate: OUTPUT_RATE });',
                            'playCtx = new AudioContext({ sampleRate: OUTPUT_RATE }); await playCtx.resume();', 1)
        code = code.replace('micCtx = new AudioContext({ sampleRate: INPUT_RATE });',
                            'micCtx = new AudioContext({ sampleRate: INPUT_RATE }); await micCtx.resume();', 1)
    if student == 'seoyoungchae-shell':
        code = code.replace('catch (err) { log("마이크를 열 수 없음: " + err.message, "w"); }',
                            'catch (err) { throw new Error("마이크 시작 실패: " + err.message); }', 1)
        code = code.replace('catch (err) { log("마이크 처리 준비 실패: " + err.message, "w"); }',
                            'catch (err) { throw new Error("마이크 처리 준비 실패: " + err.message); }', 1)
    if student == 'gaeun-shell':
        code = code.replace('function autoStart() {', 'function autoStart() { return; // LiveBridge owns wake/reconnect\n', 1)
    if student == 'minseo-shell':
        assets['index.html'] = assets['index.html'].replace('function autoStart() {', 'function autoStart() { return; // LiveBridge owns wake/reconnect\n', 1)
    if student == 'minjeong-shell':
        # Retain audio resources so central sleep releases the microphone.
        code = code.replace('let outCtx, nextT = 0;', 'let outCtx, inCtx, micStream, micProcessor, nextT = 0;')
        code = code.replace('const stream = await navigator.mediaDevices.getUserMedia(', 'const stream = micStream = await navigator.mediaDevices.getUserMedia(', 1)
        code = code.replace('const inCtx = new AudioContext();', 'inCtx = new AudioContext(); await inCtx.resume(); await outCtx.resume();', 1)
        code = code.replace('const proc = inCtx.createScriptProcessor(', 'const proc = micProcessor = inCtx.createScriptProcessor(', 1)
        code = code.replace('setTimeout(connect, 3000);', '/* LiveBridge owns reconnects */')
        code = code.replace('setTimeout(start, 3000);', 'throw err;')
        code = code.replace('  start();\n})();', '})();')
        cleanup = '''
  async function octoStop() {
    setupDone = false;
    if (ws) { const old = ws; ws = null; old.onclose = null; old.close(); }
    if (micProcessor) { micProcessor.onaudioprocess = null; micProcessor.disconnect(); micProcessor = null; }
    if (micStream) { micStream.getTracks().forEach(t => t.stop()); micStream = null; }
    stopPlayback();
    for (const ctx of [inCtx, outCtx]) if (ctx && ctx.state !== 'closed') await ctx.close();
    inCtx = outCtx = null; nextT = 0; playing = false; setFace('idle');
  }
'''
        code = code.replace('\n})();\n</script>', cleanup + '\n})();\n</script>', 1)
    audio_state = {
        'minjeong-shell': '({ input: inCtx?.state, output: outCtx?.state })',
        'seoyoungchae-shell': '({ input: micCtx?.state, output: playCtx?.state })',
    }.get(student)
    hook = f'''\n// Octo deployment hook (student source is unchanged).
OctoStudent.connect({{
  start: async () => {{
    const key = window.OCTO_CONFIG.key;
    for (const id of ["apiKeyInput", "apiKey", "api-key"]) {{
      const input = document.getElementById(id); if (input) input.value = key;
    }}
    {"if (key) localStorage.setItem(LS_KEY, key); params.greet = false;" if student == "minseo" else ""}
    {"document.querySelector('input[name=mode][value=voice]').checked = true;" if student == "Yunjung" else ""}
    await {start}();
  }},
  stop: async () => {{ {stop}; }},
  ready: () => !!({ready}), socket: () => {socket}, speaking: () => !!({speaking}),
  prompt: async () => {prompt}, relay: {str(student == 'Yunjung').lower()},
  {f'audioState: () => {audio_state},' if audio_state else ''}
}});\n'''
    # Soyeon's original automatic connection would activate a slave microphone in idle.
    code = code.replace('if (localApiKey) connectSafely(true);', '')
    if file.endswith('.html'):
        index = code.rfind('})();') if student == 'minjeong-shell' else code.rfind('</script>')
        if index < 0:
            raise ValueError(f'{student}: 연결 코드를 넣을 script가 없음')
        code = code[:index] + hook + code[index:]
        html = code
    else:
        code += hook
        html = assets['index.html'] if assets else (folder / 'index.html').read_text()
    scripts = '<script src="octo-config.js"></script><script src="live-bridge.js"></script><script src="octo-student.js"></script>'
    html = html.replace('</head>', scripts + '</head>', 1)
    if file.endswith('.html'):
        code = html  # The manifest may serve heol.html rather than index.html.
    changed = {**assets, file: code, 'index.html': html,
               'live-bridge.js': (bridge_dir / 'live-bridge.js').read_text(),
               'octo-student.js': (bridge_dir / 'octo-student.js').read_text()}
    if student == 'Yunjung':
        server = (folder / 'server.py').read_text()
        server = server.replace("ASSETS = {", "ASSETS = {'/octo-config.js': 'octo-config.js', '/live-bridge.js': 'live-bridge.js', '/octo-student.js': 'octo-student.js', ", 1)
        server = server.replace("connect-src 'self';", "connect-src 'self' ws://127.0.0.1:8765;", 1)
        anchor = "                            if not isinstance(data, dict) or data.get('type') != 'text':"
        if anchor not in server:
            raise ValueError('Yunjung: relay의 프로토콜이 바뀜; adapter를 확인하세요')
        server = server.replace(anchor, "                            if data == {'type': 'audioStreamEnd'}:\n                                await upstream.send_json({'realtimeInput': {'audioStreamEnd': True}})\n                                continue\n" + anchor, 1)
        changed['server.py'] = server
    return changed
