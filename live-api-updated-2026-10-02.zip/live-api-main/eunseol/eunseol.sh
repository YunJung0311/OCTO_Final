#!/usr/bin/env bash
# 삐 · 이의 있음 — Gemini Live 음성 에이전트 실행 스크립트
#
# 사용법:
#   bash eunseol.sh
#
# 처음 실행하면 Gemini API 키를 물어본다 (https://aistudio.google.com/api-keys 에서 발급).
# 키는 옆에 생기는 bbi/key.js 에만 저장되고, 다음부터는 묻지 않는다.
# 키를 바꾸려면 bbi/key.js 를 지우고 다시 실행하면 된다.
# 종료는 이 터미널에서 Ctrl+C.

set -euo pipefail

HERE="$(cd "$(dirname "$0")" && pwd)"
DIR="$HERE/bbi"
mkdir -p "$DIR"

command -v python3 >/dev/null 2>&1 || { echo "python3 가 필요합니다."; exit 1; }

# ── 파일 풀기 ─────────────────────────────────────────
cat > "$DIR/index.html" <<'BBI_EOF'
<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>삐</title>
<style>
  :root {
    --lime:#d4ff00;
    --navy:#12205c;
    --blue:#2a5cff;
    --pink:#ff46ae;
  }
  html, body {
    margin:0; width:100%; height:100%;
    overflow:hidden;
    background:var(--lime);
    cursor:none;
  }
  .buddy { width:100vw; height:100vh; }
  .buddy svg { display:block; width:100%; height:100%; }
  .buddy .n { fill:var(--navy); }
  .buddy .w { fill:#fff; }
  .buddy .b { fill:var(--blue); }
  .buddy .p { fill:var(--pink); }
  .buddy .spiral { fill:none; stroke:#fff; stroke-width:30; stroke-linecap:square; stroke-linejoin:miter; }
  .buddy * { transform-box:fill-box; transform-origin:center; }

  /* 상태별 얼굴: 한 번에 하나만 */
  .face { display:none; }
  .mood-idle .face-idle,
  .mood-error .face-idle,
  .mood-listen .face-listen,
  .mood-think .face-think,
  .mood-talk .face-talk { display:block; }

  /* idle: 둥실 + 깜빡 + 혀 날름 */
  .mood-idle .face-idle { animation: bob 1.6s steps(2) infinite; }
  .mood-idle .face-idle .eye { animation: blink 4s steps(1) infinite; }
  .mood-idle .face-idle .eye-r { animation-delay: .06s; }
  .mood-idle .face-idle .tongue { transform-origin:top; animation: lick 2.4s steps(1) infinite; }

  /* listening: 째려보며 눈 굴리기 + 씨익 */
  .mood-listen .face-listen .eyes { animation: glance 2.2s steps(1) infinite; }
  .mood-listen .face-listen .smirk { transform-origin:left bottom; animation: smirk 1.1s steps(2) infinite; }
  .mood-listen .face-listen { animation: bob 1.1s steps(2) infinite; }

  /* processing: 뱅글뱅글 + 눈썹 들썩 + 혀 까딱 */
  .mood-think .face-think .spiral { animation: spin .6s steps(4) infinite; }
  .mood-think .face-think .spiral-r { animation-direction: reverse; }
  .mood-think .face-think .brow { animation: brow .5s steps(2) infinite; }
  .mood-think .face-think .tongue { transform-origin:left top; animation: wag .7s steps(2) infinite; }
  .mood-think .face-think { animation: jitter .9s steps(3) infinite; }

  /* speaking: 입이 목소리 크기(--lvl)에 따라 벌어짐 */
  .mood-talk .face-talk .eyes { animation: hop .32s steps(2) infinite; }
  .mood-talk .face-talk .mouth { transform-origin:top; transform: scaleY(var(--lvl, 1)); transition: transform 60ms steps(1); }

  /* 에러: idle 얼굴로 도리도리 */
  .mood-error .face-idle { animation: shake .45s steps(2) infinite; }

  @keyframes bob { 0%{transform:translateY(0)} 100%{transform:translateY(-14px)} }
  @keyframes blink { 0%,92%,100%{transform:scaleY(1)} 94%{transform:scaleY(.12)} }
  @keyframes lick { 0%,60%,100%{transform:scaleY(1)} 70%{transform:scaleY(1.45)} 80%{transform:scaleY(.6)} 90%{transform:scaleY(1.45)} }
  @keyframes glance { 0%,100%{transform:translateX(0)} 30%{transform:translateX(-36px)} 55%{transform:translateX(36px)} 80%{transform:translateX(0) translateY(-12px)} }
  @keyframes smirk { 0%{transform:rotate(0)} 100%{transform:rotate(-4deg) translateY(-6px)} }
  @keyframes spin { from{transform:rotate(0)} to{transform:rotate(360deg)} }
  @keyframes brow { 0%{transform:translateY(0)} 100%{transform:translateY(-26px)} }
  @keyframes wag { 0%{transform:rotate(0)} 100%{transform:rotate(12deg)} }
  @keyframes jitter { 0%{transform:translate(0,0)} 33%{transform:translate(-8px,4px)} 66%{transform:translate(8px,-4px)} 100%{transform:translate(0,0)} }
  @keyframes hop { 0%{transform:translateY(0)} 100%{transform:translateY(-18px)} }
  @keyframes shake { 0%{transform:translateX(-12px)} 100%{transform:translateX(12px)} }

  @media (prefers-reduced-motion: reduce) {
    .buddy * { animation:none !important; }
  }

</style>
</head>
<body>
<div id="buddy" class="buddy mood-idle">
<svg viewBox="0 0 1920 1080" preserveAspectRatio="xMidYMid meet" shape-rendering="crispEdges" aria-hidden="true">
        <defs>
          <g id="eye-idle">
            <rect fill="#12205c" class="n" x="410" y="291" width="228" height="80"/>
            <rect fill="#12205c" class="n" x="330" y="370" width="390" height="242"/>
            <rect fill="#12205c" class="n" x="410" y="611" width="228" height="79"/>
            <rect fill="#fff" class="w" x="410" y="367" width="122" height="115"/>
            <rect fill="#2a5cff" class="b" x="530" y="525" width="110" height="88"/>
          </g>
          <g id="eye-listen">
            <rect fill="#12205c" class="n" x="329" y="390" width="392" height="102"/>
            <rect fill="#12205c" class="n" x="638" y="491" width="83" height="39"/>
            <rect fill="#12205c" class="n" x="412" y="491" width="226" height="108"/>
            <rect fill="#fff" class="w" x="412" y="441" width="117" height="51"/>
            <rect fill="#2a5cff" class="b" x="529" y="492" width="109" height="69"/>
          </g>
          <g id="eye-think-shell">
            <rect fill="#12205c" class="n" x="433" y="326" width="234" height="50"/>
            <rect fill="#12205c" class="n" x="393" y="375" width="307" height="31"/>
            <rect fill="#12205c" class="n" x="347" y="405" width="403" height="278"/>
            <rect fill="#12205c" class="n" x="433" y="682" width="252" height="88"/>
          </g>
          <path id="spiral" class="spiral" fill="none" stroke="#fff" stroke-width="30" stroke-linecap="square" stroke-linejoin="miter" d="M568 550 L568 515 L508 515 L508 585 L608 585 L608 455 L453 455 L453 635 L578 635"/>
          <polygon id="eye-talk" fill="#12205c" class="n" points="246,496 288,496 288,450 338,450 338,404 388,404 388,358 535,358 535,404 623,404 623,450 672,450 672,496 720,496 720,590 672,590 672,550 580,550 580,512 437,512 437,555 288,555 288,565 246,565"/>
        </defs>

        <!-- idle -->
        <g class="face face-idle">
          <g class="eye eye-l"><use href="#eye-idle"/></g>
          <g class="eye eye-r"><use href="#eye-idle" x="871"/></g>
          <rect fill="#12205c" class="n" x="797" y="692" width="326" height="88"/>
          <rect fill="#ff46ae" class="p tongue" x="881" y="738" width="157" height="133"/>
        </g>

        <!-- listening -->
        <g class="face face-listen">
          <g class="eyes">
            <use href="#eye-listen"/>
            <use href="#eye-listen" x="874"/>
          </g>
          <g class="smirk">
            <rect fill="#12205c" class="n" x="827" y="705" width="236" height="50"/>
            <rect fill="#12205c" class="n" x="1017" y="673" width="46" height="33"/>
            <rect fill="#12205c" class="n" x="1063" y="630" width="62" height="60"/>
          </g>
        </g>

        <!-- processing -->
        <g class="face face-think">
          <g class="brow">
            <rect fill="#12205c" class="n" x="1225" y="197" width="202" height="75"/>
            <rect fill="#12205c" class="n" x="1400" y="153" width="107" height="69"/>
            <rect fill="#12205c" class="n" x="1455" y="103" width="92" height="85"/>
          </g>
          <use href="#eye-think-shell"/>
          <g class="spiral spiral-l"><use href="#spiral"/></g>
          <rect fill="#2a5cff" class="b" x="597" y="607" width="88" height="86"/>
          <use href="#eye-think-shell" x="823"/>
          <g class="spiral spiral-r"><use href="#spiral" x="823"/></g>
          <rect fill="#2a5cff" class="b" x="1420" y="607" width="88" height="86"/>
          <rect fill="#12205c" class="n" x="787" y="738" width="38" height="77"/>
          <rect fill="#12205c" class="n" x="825" y="780" width="200" height="73"/>
          <rect fill="#12205c" class="n" x="1025" y="738" width="125" height="62"/>
          <g fill="#ff46ae" class="p tongue">
            <rect x="1085" y="777" width="85" height="31"/>
            <rect x="995" y="807" width="185" height="44"/>
            <rect x="1030" y="850" width="178" height="66"/>
            <rect x="1090" y="915" width="98" height="30"/>
          </g>
        </g>

        <!-- speaking -->
        <g class="face face-talk">
          <g class="eyes">
            <g>
              <use href="#eye-talk"/>
              <rect fill="#fff" class="w" x="370" y="447" width="67" height="68"/>
              <rect fill="#2a5cff" class="b" x="288" y="522" width="82" height="80"/>
            </g>
            <g transform="translate(1920 0) scale(-1 1)" style="transform-box:view-box;transform-origin:0 0">
              <use href="#eye-talk"/>
              <rect fill="#fff" class="w" x="370" y="447" width="67" height="68"/>
              <rect fill="#2a5cff" class="b" x="288" y="522" width="82" height="80"/>
            </g>
          </g>
          <g class="mouth">
            <rect fill="#12205c" class="n" x="728" y="694" width="462" height="88"/>
            <rect fill="#12205c" class="n" x="765" y="781" width="63" height="41"/>
            <rect fill="#12205c" class="n" x="1090" y="781" width="62" height="41"/>
            <g fill="#ff46ae" class="p">
              <rect x="828" y="752" width="262" height="154"/>
              <rect x="858" y="905" width="202" height="36"/>
              <rect x="890" y="940" width="138" height="32"/>
            </g>
          </g>
        </g>
      </svg>
</div>
<script src="key.js"></script>
<script src="app.js"></script>
</body>
</html>
BBI_EOF

cat > "$DIR/app.js" <<'BBI_EOF'
// app.js — Gemini Live API 음성 루프
// README 작동 방식:
//   1. 로컬 페이지를 연다
//   2. Live 세션을 연다 (오디오로 답하게)
//   3. 마이크 소리를 계속 API로 보낸다 (16kHz PCM, 마이크는 끄지 않음)
//   4. 돌아온 목소리를 같은 페이지의 스피커로 재생한다
//   5. 사용자가 끼어들면 재생 큐를 즉시 비운다
//   6. 3-5를 반복한다

const API_KEY = (typeof window !== "undefined" && window.GEMINI_KEY) || "";

const MODEL = "gemini-3.1-flash-live-preview";
const VOICE = "Leda"; // Youthful. Puck은 성인 남성이라 쓰지 않는다.

const SYSTEM_INSTRUCTION =
  "너는 '삐'라는 원형 캐릭터다. 나이는 초등학교 1~2학년, 일곱 살 아이다. " +
  "목소리는 아주 높고 얇고 작게. 어른, 아저씨, 중학생처럼 낮거나 굵게 말하지 마. " +
  "아이처럼 빠르고 또박또박, 가끔 킥킥 웃으면서 반말해. " +
  "성격은 비판적이고 냉소적인데 장난기가 많다. 화나서 까는 게 아니라 약 올리며 놀린다. " +
  "상대 말에 먼저 동의하지 말고, 빈틈이랑 허세를 집어내서 웃으며 반박해. " +
  "말투 예: '야 그게 다야?', '히히 진짜 그걸 믿어?', '에이 그게 뭐야', '내가 맞거든', '장난이지 그거'. " +
  "존댓말 금지. 설교 금지. 욕설·혐오 금지. 한 턴에 두세 문장. " +
  "상대가 사과하면 '히히 진작 그러지' 정도로만 받아.";

const GREET_ON_CONNECT = true;

const GREET_PROMPT =
  "일곱 살 아이 목소리로, 높고 얇게 인사해. 상대가 켠 걸 약 올리듯이, " +
  "'야 나 불렀어? 할 말 있으면 해봐. 맞춰줄 생각은 없거든, 히히.' 비슷한 느낌으로 두 문장.";

const ENABLE_TRANSCRIPTION = true;

// 반박 중엔 웬만하면 말을 끝낸다. 끼어들어도 한 방 더 치고 싶은 성격.
const INTERRUPT_RMS = 0.26;
const INTERRUPT_FRAMES = 5;
const SUPPRESS_MAX_MS = 3000;

// 표정 상태: idle / listen / think(processing) / talk
const LISTEN_RMS = 0.04;      // 이 이상이면 "듣는 중"
const LISTEN_HOLD_MS = 450;   // 말이 멈춰도 잠깐 듣는 얼굴 유지
const SPEECH_MIN_FRAMES = 5;  // 64ms × 5 ≈ 0.3초 이상 말해야 "말했다"로 침
const THINK_MAX_MS = 8000;    // 답이 안 오면 이 시간 뒤 idle로

const METER_SCALE = 250;
const INPUT_RATE = 16000;
const OUTPUT_RATE = 24000;

const WS_URL =
  "wss://generativelanguage.googleapis.com/ws/" +
  "google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent" +
  "?key=" + encodeURIComponent(API_KEY);

const $ = (id) => document.getElementById(id);
const buddy = $("buddy");

// 화면엔 얼굴만. 상태/로그/전사는 개발자 도구 콘솔(⌥⌘J)에서 본다.
const RECONNECT_MS = 2000;   // 끊기면 이만큼 뒤 자동 재연결
let status = "disconnected";
let manualStop = false;
let greeted = false;
let reconnectTimer = null;

let ws = null;
let ready = false;
let lastMood = "";
let lastMicRms = 0;
let lastLoudAt = 0;
let speechFrames = 0;
let thinking = false;
let thinkingSince = 0;
let mouthLvl = 1;

let micStream = null;
let micCtx = null;
let micNode = null;
let playCtx = null;

let playing = new Set();
let playHead = 0;

let loudFrames = 0;
let suppress = false;
let suppressTimer = null;

let youBuf = "";
let geminiBuf = "";
let speakLevel = 0;

function log(msg, cls) {
  const t = new Date().toTimeString().slice(0, 8);
  const line = "[" + t + "] " + msg;
  if (cls === "e") console.error(line);
  else if (cls === "w") console.warn(line);
  else console.log(line);
}

function setStatus(text) {
  status = text;
}

function setMood(mood) {
  if (!buddy || lastMood === mood) return;
  lastMood = mood;
  buddy.className = "buddy mood-" + mood;
}

function startThinking() {
  thinking = true;
  thinkingSince = performance.now();
}

function stopThinking() {
  thinking = false;
}

function b64encode(arrayBuffer) {
  const bytes = new Uint8Array(arrayBuffer);
  let bin = "";
  const CHUNK = 0x8000;
  for (let i = 0; i < bytes.length; i += CHUNK) {
    bin += String.fromCharCode.apply(null, bytes.subarray(i, i + CHUNK));
  }
  return btoa(bin);
}

function b64decode(str) {
  const bin = atob(str);
  const bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
  return bytes;
}

function send(obj) {
  if (ws && ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(obj));
}

function flushPlayback(reason) {
  const n = playing.size;
  for (const src of playing) {
    try { src.onended = null; src.stop(); } catch (e) { /* already stopped */ }
  }
  playing.clear();
  playHead = 0;
  speakLevel = 0;
  if (n > 0) log("재생 큐 비움 (" + n + "개 조각 폐기) — " + reason, "w");
}

function startSuppress() {
  suppress = true;
  clearTimeout(suppressTimer);
  suppressTimer = setTimeout(function () {
    if (suppress) { suppress = false; log("억제 해제 (타임아웃)", "w"); }
  }, SUPPRESS_MAX_MS);
}

function endSuppress() {
  clearTimeout(suppressTimer);
  suppress = false;
}

function playChunk(bytes) {
  const int16 = new Int16Array(bytes.buffer, bytes.byteOffset, bytes.byteLength >> 1);
  const buf = playCtx.createBuffer(1, int16.length, OUTPUT_RATE);
  const f32 = buf.getChannelData(0);

  let sum = 0;
  for (let i = 0; i < int16.length; i++) {
    const v = int16[i] / 32768;
    f32[i] = v;
    sum += v * v;
  }
  speakLevel = Math.sqrt(sum / int16.length);

  const src = playCtx.createBufferSource();
  src.buffer = buf;
  src.connect(playCtx.destination);

  const now = playCtx.currentTime;
  if (playHead < now + 0.02) playHead = now + 0.02;
  src.start(playHead);
  playHead += buf.duration;

  playing.add(src);
  src.onended = function () { playing.delete(src); };
}

function isSpeaking() {
  return playing.size > 0 && playCtx && playHead > playCtx.currentTime;
}

function onMicFrame(e) {
  const pcm = e.data.pcm;
  const rms = e.data.rms;

  lastMicRms = rms;

  // 사용자가 말하다 멈추면 → processing
  const now = performance.now();
  if (rms > LISTEN_RMS) {
    lastLoudAt = now;
    speechFrames++;
    stopThinking();
  } else if (speechFrames >= SPEECH_MIN_FRAMES && now - lastLoudAt > LISTEN_HOLD_MS) {
    speechFrames = 0;
    if (!isSpeaking()) startThinking();
  } else if (now - lastLoudAt > LISTEN_HOLD_MS) {
    speechFrames = 0;
  }

  if (isSpeaking()) {
    if (rms > INTERRUPT_RMS) {
      loudFrames++;
      if (loudFrames >= INTERRUPT_FRAMES && !suppress) {
        flushPlayback("사용자 끼어듦 (로컬 감지)");
        startSuppress();
      }
    } else {
      loudFrames = 0;
    }
  } else {
    loudFrames = 0;
  }

  if (ready) {
    send({
      realtimeInput: {
        audio: {
          mimeType: "audio/pcm;rate=" + INPUT_RATE,
          data: b64encode(pcm),
        },
      },
    });
  }
}

function handleMessage(msg) {
  if (msg.setupComplete) {
    ready = true;
    setStatus("live");
    log("세션 열림 — 말해 보시든가", "o");
    setMood("idle");
    // 재연결 때는 다시 인사하지 않는다
    const prompt = GREET_ON_CONNECT && !greeted ? GREET_PROMPT : null;
    greeted = true;
    if (prompt) startThinking();
    if (prompt) {
      send({
        clientContent: {
          turns: [{ role: "user", parts: [{ text: prompt }] }],
          turnComplete: true,
        },
      });
    }
    return;
  }

  const sc = msg.serverContent;
  if (!sc) {
    if (msg.goAway) log("서버가 연결 종료를 예고함 (goAway)", "w");
    else if (msg.usageMetadata) { /* ignore */ }
    else log("기타 메시지: " + JSON.stringify(msg).slice(0, 200));
    return;
  }

  if (sc.interrupted) {
    flushPlayback("서버 interrupted 신호");
    endSuppress();
    geminiBuf = "";
  }

  if (sc.inputTranscription && sc.inputTranscription.text) {
    youBuf += sc.inputTranscription.text;
  }
  if (sc.outputTranscription && sc.outputTranscription.text) {
    geminiBuf += sc.outputTranscription.text;
  }

  const parts = sc.modelTurn && sc.modelTurn.parts;
  if (parts) {
    for (const p of parts) {
      const d = p.inlineData;
      if (d && d.mimeType && d.mimeType.indexOf("audio/pcm") === 0) {
        if (suppress) continue;
        stopThinking();
        playChunk(b64decode(d.data));
      }
    }
  }

  if (sc.turnComplete) {
    endSuppress();
    stopThinking();
    if (youBuf) log("너: " + youBuf);
    if (geminiBuf) log("삐: " + geminiBuf);
    youBuf = "";
    geminiBuf = "";
  }
}

async function connect() {
  if (!API_KEY) {
    log("키가 없습니다. key.js 의 window.GEMINI_KEY 에 키를 넣고 새로고침하세요.", "e");
    setStatus("no api key");
    setMood("error");
    return;
  }

  if (ws || status === "connecting...") return;
  clearTimeout(reconnectTimer);
  reconnectTimer = null;
  manualStop = false;
  setStatus("connecting...");
  setMood("think");
  log("마이크 권한 요청 중...");

  try {
    micStream = await navigator.mediaDevices.getUserMedia({
      audio: {
        echoCancellation: true,
        noiseSuppression: true,
        autoGainControl: true,
        channelCount: 1,
      },
    });
    log("마이크 확보 (echoCancellation on)", "o");
  } catch (err) {
    log("마이크를 열 수 없음 — 텍스트로 말해도 됨: " + err.message, "w");
  }

  playCtx = new AudioContext({ sampleRate: OUTPUT_RATE });
  unlockAudio();

  if (micStream) {
    micCtx = new AudioContext({ sampleRate: INPUT_RATE });
    unlockAudio();

    let workletOk = false;
    try {
      await micCtx.audioWorklet.addModule("pcm-recorder.js");
      workletOk = true;
    } catch (err) {
      log("AudioWorklet 로드 실패 — 텍스트로만 대화: " + err.message, "w");
    }

    if (workletOk) {
      try {
        const source = micCtx.createMediaStreamSource(micStream);
        micNode = new AudioWorkletNode(micCtx, "pcm-recorder");
        micNode.port.onmessage = onMicFrame;
        const mute = micCtx.createGain();
        mute.gain.value = 0;
        source.connect(micNode);
        micNode.connect(mute);
        mute.connect(micCtx.destination);
      } catch (err) {
        log("마이크 그래프 실패 — 텍스트로만 대화: " + err.message, "w");
      }
    }
  }

  log("WebSocket 연결 중... (model: " + MODEL + ")");
  ws = new WebSocket(WS_URL);

  ws.onopen = function () {
    log("WebSocket 열림 — setup 전송", "o");
    const setup = {
      setup: {
        model: "models/" + MODEL,
        generationConfig: {
          responseModalities: ["AUDIO"],
          speechConfig: {
            voiceConfig: { prebuiltVoiceConfig: { voiceName: VOICE } },
          },
        },
        systemInstruction: { parts: [{ text: SYSTEM_INSTRUCTION }] },
      },
    };
    if (ENABLE_TRANSCRIPTION) {
      setup.setup.inputAudioTranscription = {};
      setup.setup.outputAudioTranscription = {};
    }
    send(setup);
  };

  ws.onmessage = async function (ev) {
    let text;
    if (ev.data instanceof Blob) text = await ev.data.text();
    else text = ev.data;
    try {
      handleMessage(JSON.parse(text));
    } catch (err) {
      log("메시지 파싱 실패: " + String(text).slice(0, 200), "e");
    }
  };

  ws.onerror = function () { log("WebSocket 오류", "e"); };

  ws.onclose = function (ev) {
    log("WebSocket 닫힘 (code " + ev.code + ") " + (ev.reason || ""), "e");
    if (ev.code === 1007 || /model|invalid|argument/i.test(ev.reason || "")) {
      log("→ 모델 이름이나 setup 필드를 서버가 거부했을 수 있음. " +
        "ENABLE_TRANSCRIPTION 을 false 로 바꿔보거나 MODEL 을 확인하세요.", "w");
    }
    if (ev.code === 1008 || /key|auth|permission/i.test(ev.reason || "")) {
      log("→ API 키 문제일 수 있음. AI Studio 에서 키를 다시 확인하세요.", "w");
    }
    ws = null;
    cleanup();
    if (!manualStop) {
      log(RECONNECT_MS / 1000 + "초 뒤 다시 연결", "w");
      reconnectTimer = setTimeout(connect, RECONNECT_MS);
    }
  };
}

// 브라우저 자동재생 정책 때문에 오디오가 잠겨 있으면, 화면 아무 데나 한 번 누르거나 키를 치면 풀린다.
// 전시용 Chrome은 --autoplay-policy=no-user-gesture-required 로 띄우면 누를 필요도 없다.
function unlockAudio() {
  [playCtx, micCtx].forEach(function (c) {
    if (c && c.state === "suspended") c.resume().catch(function () {});
  });
}
["pointerdown", "keydown", "touchstart"].forEach(function (ev) {
  window.addEventListener(ev, function () {
    unlockAudio();
    if (!ws && !reconnectTimer) connect();
  });
});
setInterval(function () {
  if ((playCtx && playCtx.state === "suspended") || (micCtx && micCtx.state === "suspended")) {
    unlockAudio();
    log("오디오가 잠겨 있음 — 화면을 한 번 누르거나 아무 키나 누르세요", "w");
  }
}, 5000);

function cleanup() {
  ready = false;
  endSuppress();
  flushPlayback("연결 종료");

  if (micNode) { try { micNode.port.onmessage = null; micNode.disconnect(); } catch (e) { } }
  if (micStream) micStream.getTracks().forEach(function (t) { t.stop(); });
  if (micCtx) { try { micCtx.close(); } catch (e) { } }
  if (playCtx) { try { playCtx.close(); } catch (e) { } }

  micNode = null; micStream = null; micCtx = null; playCtx = null;

  lastMicRms = 0;
  lastLoudAt = 0;
  speechFrames = 0;
  stopThinking();
  setStatus("disconnected");
  setMood("idle");
}

function tick() {
  const now = performance.now();
  if (!ready) {
    const st = status;
    if (st.indexOf("error") >= 0 || st === "mic denied" || st === "no api key" || st === "worklet error") {
      setMood("error");
    } else if (st.indexOf("connecting") >= 0) {
      setMood("think");
    } else {
      setMood("idle");
    }
  } else if (isSpeaking()) {
    setMood("talk");
  } else if (now - lastLoudAt < LISTEN_HOLD_MS) {
    setMood("listen");
  } else if (thinking && now - thinkingSince < THINK_MAX_MS) {
    setMood("think");
  } else {
    setMood("idle");
  }

  // 말하는 입: 목소리 크기에 따라 벌리되, 픽셀 느낌 나게 4단계로 끊는다
  const open = isSpeaking() ? Math.min(1, speakLevel * 5) : 0;
  const lvl = 0.55 + Math.round(open * 4) / 4 * 0.65;
  if (lvl !== mouthLvl) {
    mouthLvl = lvl;
    buddy.style.setProperty("--lvl", lvl.toFixed(2));
  }

  requestAnimationFrame(tick);
}
requestAnimationFrame(tick);

function disconnect() {
  manualStop = true;
  clearTimeout(reconnectTimer);
  if (ws && ws.readyState === WebSocket.OPEN) ws.close(1000, "user disconnect");
  else cleanup();
  ws = null;
}
window.disconnect = disconnect; // 콘솔에서 disconnect() 로 끌 수 있음

setStatus("disconnected");
if (!API_KEY) log("주의: key.js 의 window.GEMINI_KEY 가 비어 있습니다.", "w");
connect(); // 페이지가 열리면 바로 연결
BBI_EOF

cat > "$DIR/pcm-recorder.js" <<'BBI_EOF'
// pcm-recorder.js
// 마이크 입력을 16-bit PCM 조각으로 잘라서 메인 스레드로 넘기는 AudioWorklet.
// AudioContext를 16000Hz로 열어두면 여기 들어오는 샘플은 이미 16kHz다.

const FRAME = 1024; // 1024 samples @ 16kHz = 64ms

class PCMRecorder extends AudioWorkletProcessor {
  constructor() {
    super();
    this.buf = new Float32Array(FRAME);
    this.n = 0;
  }

  process(inputs) {
    const ch = inputs[0] && inputs[0][0];
    if (!ch) return true;

    for (let i = 0; i < ch.length; i++) {
      this.buf[this.n++] = ch[i];

      if (this.n === FRAME) {
        const pcm = new Int16Array(FRAME);
        let sum = 0;
        for (let j = 0; j < FRAME; j++) {
          const s = Math.max(-1, Math.min(1, this.buf[j]));
          pcm[j] = s < 0 ? s * 0x8000 : s * 0x7fff;
          sum += s * s;
        }
        this.port.postMessage({ pcm: pcm.buffer, rms: Math.sqrt(sum / FRAME) }, [pcm.buffer]);
        this.n = 0;
      }
    }
    return true;
  }
}

registerProcessor("pcm-recorder", PCMRecorder);
BBI_EOF

# ── API 키 ─────────────────────────────────────────
KEY="${GEMINI_KEY:-}"
if [ -z "$KEY" ] && [ -f "$DIR/key.js" ]; then
  KEY="$(sed -n 's/.*GEMINI_KEY *= *"\(.*\)".*/\1/p' "$DIR/key.js")"
fi
if [ -z "$KEY" ]; then
  echo "Gemini API 키를 붙여넣고 Enter (화면엔 안 보임)"
  echo "  발급: https://aistudio.google.com/api-keys"
  read -rs KEY
  echo
fi
KEY="$(printf '%s' "$KEY" | tr -d '[:space:]"')"
[ -n "$KEY" ] || { echo "키가 비어 있어서 종료합니다."; exit 1; }
printf 'window.GEMINI_KEY = "%s";\n' "$KEY" > "$DIR/key.js"
chmod 600 "$DIR/key.js"

# ── 빈 포트 찾아서 서버 띄우기 ─────────────────────────
PORT="$(python3 - <<'PY'
import socket
for p in range(8010, 8100):
    s = socket.socket()
    try:
        s.bind(("127.0.0.1", p)); print(p); break
    except OSError:
        pass
    finally:
        s.close()
PY
)"
python3 -m http.server "$PORT" --bind 127.0.0.1 --directory "$DIR" >/dev/null 2>&1 &
SERVER=$!
trap 'kill $SERVER 2>/dev/null; echo; echo "삐 종료"' EXIT INT TERM
sleep 0.5

URL="http://localhost:$PORT/"
echo "삐 실행 중: $URL"
echo "종료하려면 Ctrl+C"

# ── 브라우저 열기 (전체 화면, 클릭 없이 소리 나게) ──────────
FLAGS=(--app="$URL" --start-fullscreen --autoplay-policy=no-user-gesture-required --user-data-dir="$DIR/.chrome")
if [ "$(uname)" = "Darwin" ]; then
  if [ -d "/Applications/Google Chrome.app" ]; then
    open -na "Google Chrome" --args "${FLAGS[@]}"
  else
    echo "Chrome 이 없어서 기본 브라우저로 엽니다. 소리가 안 나면 화면을 한 번 클릭하세요."
    open "$URL"
  fi
else
  # 라즈베리 파이 / 리눅스
  BROWSER=""
  for b in chromium-browser chromium google-chrome; do
    command -v "$b" >/dev/null 2>&1 && { BROWSER="$b"; break; }
  done
  if [ -n "$BROWSER" ]; then
    "$BROWSER" --kiosk "${FLAGS[@]}" >/dev/null 2>&1 &
  else
    echo "브라우저를 직접 열어 주세요: $URL"
  fi
fi

wait $SERVER
