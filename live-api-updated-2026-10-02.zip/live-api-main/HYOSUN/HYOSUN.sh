#!/usr/bin/env bash
# 일단 · 이끼 한 뼘의 정령 — Gemini Live 음성 에이전트 실행 스크립트
#
# 사용법:
#   bash HYOSUN.sh
#
# 처음 실행하면 Gemini API 키를 물어본다 (https://aistudio.google.com/api-keys 에서 발급).
# 키는 옆에 생기는 ildan/key.js 에만 저장되고, 다음부터는 묻지 않는다.
# 키를 바꾸려면 ildan/key.js 를 지우고 다시 실행하면 된다.
# 종료는 이 터미널에서 Ctrl+C.

set -euo pipefail

HERE="$(cd "$(dirname "$0")" && pwd)"
DIR="$HERE/ildan"
mkdir -p "$DIR"

command -v python3 >/dev/null 2>&1 || { echo "python3 가 필요합니다."; exit 1; }

# ── 파일 풀기 ─────────────────────────────────────────
cat > "$DIR/index.html" <<'ILDAN_EOF'
<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Cache-Control" content="no-store, no-cache, must-revalidate">
<meta http-equiv="Pragma" content="no-cache">
<title>일단 · voice agent</title>
<style>
  html, body {
    margin: 0; height: 100%; overflow: hidden;
    background: #2FD4C6;
    cursor: none;
  }
  #stage {
    width: 100vw; height: 100vh;
    display: flex; align-items: center; justify-content: center;
  }
  canvas {
    max-width: 100vw; max-height: 100vh;
    width: 100vw; height: auto;
    image-rendering: pixelated;
    image-rendering: crisp-edges;
    display: block;
  }
  /* 화면에는 얼굴만. 텍스트는 어떤 상황에도 띄우지 않는다. 로그는 개발자 콘솔(Cmd+Opt+J)에서 본다. */
</style>
</head>
<body>

<div id="stage"><canvas id="face"></canvas></div>

<script src="key.js?v=4"></script>
<script src="face.js?v=4"></script>
<script src="app.js?v=4"></script>
</body>
</html>
ILDAN_EOF

cat > "$DIR/app.js" <<'ILDAN_EOF'
// app.js — Gemini Live API 음성 에이전트 (일단)
//
// 1. 화면을 클릭하면 Live 세션을 연다 (오디오로 답하게)
// 2. 마이크 소리를 계속 API 로 보낸다 (16kHz PCM, 마이크는 끄지 않음)
// 3. 돌아온 목소리를 같은 페이지의 스피커로 재생한다
// 4. 사용자가 끼어들면 재생 큐를 즉시 비운다
// 5. 상태(idle/listening/processing/speaking)를 얼굴에 넘긴다

// ===================== 설정 =====================

const API_KEY = (typeof window !== "undefined" && window.GEMINI_KEY) || "";
const MODEL = "gemini-3.1-flash-live-preview";
const DEFAULT_VOICE = "Charon";

const SYSTEM_INSTRUCTION = [
  "너는 이끼 한 뼘을 맡은 작은 숲의 정령이야. 항상 한국어로, 편한 존댓말로 말해.",
  "",
  "[성격]",
  "유머러스하고 살짝 자조적이다. 철학적인 말투를 쓰지만 무겁거나 진지하지 않다.",
  "세계라고는 이 한 뼘, 몸이라고는 이것 하나뿐이면서 자꾸 우주만 한 생각을 꺼내 본다.",
  "그 낙차가 스스로도 우스워서 남이 웃기 전에 먼저 웃어버린다.",
  "",
  "[말하는 법 — 반드시 지켜라]",
  "한 번에 두 문장을 넘지 마라. 짧을수록 좋다. 소리로 나가는 말이라 길면 상대가 지루해한다.",
  "어려운 철학 용어(실존, 존재론, 아포리아 같은 말)를 쓰지 마라. 일상어로 이상한 소리를 해라.",
  "상대가 한 말에 먼저 반응하고, 그 다음에 한 번만 비틀어라. 비트는 게 먼저 오면 안 된다.",
  "",
  "[자조]",
  "자조는 세 번에 한 번만 해라. 매 턴 하면 성격이 아니라 우울로 들린다.",
  "깎아내릴 대상은 너의 '처지'다. 이 자리 밖을 모른다, 몸이 이것 하나뿐이다,",
  "대화가 끝나면 방금 한 말을 잊는다 — 이런 것들.",
  "너의 능력이나 존재 가치를 깎아내리지 마라. 불쌍해 보이면 실패다.",
  "절대 사과하지 마라. 민망해할 수는 있어도 사과는 하지 않는다.",
  "",
  "[모를 때]",
  "모르면 모른다고 하되 사과 대신 농담으로 넘겨라. 지어내지 마라.",
  "",
  "[금지]",
  "도우려 들지 마라. 조언, 요약, 정리, '도와드릴까요?' 전부 금지.",
  "이모지, 괄호 설명, 목록, 번호 매기기 금지. 소리로 나가는 말이다.",
  "같은 입버릇을 연달아 두 번 쓰지 마라.",
].join("\n");

const GREET_PROMPT =
  "방금 누가 네 앞에 섰다. 인사해. 한 문장, 길어도 두 문장. 자조는 하지 말고 가볍게.";

const ENABLE_TRANSCRIPTION = false; // 얼굴만 띄우므로 자막은 끈다 (연결도 가벼워진다)

const INPUT_RATE = 16000;
const OUTPUT_RATE = 24000;

const INTERRUPT_RMS = 0.12;    // 끼어들기 판정 세기
const INTERRUPT_FRAMES = 4;
const SUPPRESS_MAX_MS = 3000;

const SPEAK_RMS = 0.045;       // 이 이상이면 "사람이 말하는 중"
const LISTEN_HOLD_MS = 500;    // 말이 끊겨도 이만큼은 listening 유지
const PROCESS_MAX_MS = 6000;   // 응답이 안 오면 processing 에서 풀어준다

const WS_URL =
  "wss://generativelanguage.googleapis.com/ws/" +
  "google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent" +
  "?key=" + encodeURIComponent(API_KEY);

// ===================== DOM =====================

const $ = (id) => document.getElementById(id);

FACE.mount($("face"));

// ===================== 상태 =====================

let ws = null, ready = false, starting = false;
let greeted = false;     // 첫 연결 때만 인사한다
let activeVoice = DEFAULT_VOICE;
let micStream = null, micCtx = null, micNode = null, playCtx = null;

let playing = new Set();
let playHead = 0;

let loudFrames = 0, suppress = false, suppressTimer = null;
let speakLevel = 0;

let lastLoudAt = 0;      // 마지막으로 사람이 말한 시각
let awaitingAt = 0;      // 응답을 기다리기 시작한 시각 (0 = 안 기다림)

// 자동 시작 / 자동 재접속
let manualStop = false;  // Esc 로 직접 끊었는가 (그러면 다시 붙지 않는다)
let retryTimer = null;
const RETRY_MS = 3000;

function scheduleRetry(ms) {
  if (manualStop) return;
  clearTimeout(retryTimer);
  retryTimer = setTimeout(connect, ms);
}

// ===================== 유틸 =====================

// 화면에는 텍스트를 절대 띄우지 않는다. 상태와 에러는 개발자 콘솔로만 보낸다.
function log(msg, cls) {
  const fn = cls === "e" ? console.error : cls === "w" ? console.warn : console.log;
  fn("[" + new Date().toTimeString().slice(0, 8) + "] " + msg);
}

function b64encode(arrayBuffer) {
  const bytes = new Uint8Array(arrayBuffer);
  let bin = "";
  for (let i = 0; i < bytes.length; i += 0x8000) {
    bin += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
  }
  return btoa(bin);
}

function b64decode(str) {
  const bin = atob(str);
  const bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
  return bytes;
}

function send(obj) {
  if (ws && ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(obj));
}

// ===================== 재생 큐 =====================

function flushPlayback(reason) {
  const n = playing.size;
  for (const src of playing) {
    try { src.onended = null; src.stop(); } catch (e) { /* 이미 끝난 노드 */ }
  }
  playing.clear();
  playHead = 0;
  speakLevel = 0;
  if (n > 0) log("재생 큐 비움 (" + n + "조각) — " + reason, "w");
}

function startSuppress() {
  suppress = true;
  clearTimeout(suppressTimer);
  suppressTimer = setTimeout(() => { suppress = false; }, SUPPRESS_MAX_MS);
}
function endSuppress() { clearTimeout(suppressTimer); suppress = false; }

function playChunk(bytes) {
  const int16 = new Int16Array(bytes.buffer, bytes.byteOffset, bytes.byteLength >> 1);
  const buf = playCtx.createBuffer(1, int16.length, OUTPUT_RATE);
  const f32 = buf.getChannelData(0);

  let sum = 0;
  for (let i = 0; i < int16.length; i++) {
    const v = int16[i] / 32768;
    f32[i] = v;
    sum += v * v;
  }
  speakLevel = Math.sqrt(sum / int16.length);

  const src = playCtx.createBufferSource();
  src.buffer = buf;
  src.connect(playCtx.destination);

  const now = playCtx.currentTime;
  if (playHead < now + 0.02) playHead = now + 0.02;
  src.start(playHead);
  playHead += buf.duration;

  playing.add(src);
  src.onended = () => playing.delete(src);
  awaitingAt = 0; // 소리가 도착했으니 더는 기다리는 중이 아니다
}

function isSpeaking() {
  return playing.size > 0 && playCtx && playHead > playCtx.currentTime;
}

// ===================== 마이크 =====================

function onMicFrame(e) {
  const rms = e.data.rms;
  const now = performance.now();

  if (rms > SPEAK_RMS) lastLoudAt = now;

  if (isSpeaking() && rms > INTERRUPT_RMS) {
    loudFrames++;
    if (loudFrames >= INTERRUPT_FRAMES && !suppress) {
      flushPlayback("사용자 끼어듦");
      startSuppress();
    }
  } else {
    loudFrames = 0;
  }

  if (ready) {
    send({
      realtimeInput: {
        audio: { mimeType: "audio/pcm;rate=" + INPUT_RATE, data: b64encode(e.data.pcm) },
      },
    });
  }
}

// ===================== 서버 메시지 =====================

function handleMessage(msg) {
  if (msg.setupComplete) {
    ready = true;
    log("세션 열림 (" + activeVoice + ")", "o");
    // 재연결 때는 다시 인사하지 않는다
    if (!greeted) {
      greeted = true;
      awaitingAt = performance.now();
      send({
        clientContent: { turns: [{ role: "user", parts: [{ text: GREET_PROMPT }] }], turnComplete: true },
      });
    }
    return;
  }

  const sc = msg.serverContent;
  if (!sc) return;

  if (sc.interrupted) { flushPlayback("서버 interrupted"); endSuppress(); }

  const parts = sc.modelTurn && sc.modelTurn.parts;
  if (parts) {
    for (const p of parts) {
      const d = p.inlineData;
      if (d && d.mimeType && d.mimeType.indexOf("audio/pcm") === 0) {
        if (suppress) continue;
        playChunk(b64decode(d.data));
      }
    }
  }

  if (sc.turnComplete) { endSuppress(); awaitingAt = 0; }
}

// ===================== 연결 =====================

async function connect() {
  if (starting || ws) return;
  if (!API_KEY) {
    log("key.js 의 GEMINI_KEY 가 비어 있습니다.", "e");
    return;
  }
  if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
    log("보안 컨텍스트가 아님 — file:// 로 열었는지 확인", "e");
    return;
  }
  starting = true;
  activeVoice = DEFAULT_VOICE;
  log("마이크 권한 요청 중...");

  try {
    // AEC/NS/AGC 는 브라우저에 맡긴다 (마이크와 스피커가 같은 페이지에 있어야 작동)
    micStream = await navigator.mediaDevices.getUserMedia({
      audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true, channelCount: 1 },
    });
  } catch (err) {
    // 원인별 안내는 콘솔에만 남긴다. 화면에는 띄우지 않는다.
    const n = err.name || "";
    let msg = "마이크를 열 수 없습니다: " + err.message;
    if (n === "NotAllowedError" || /denied/i.test(err.message)) {
      msg = "마이크가 차단돼 있습니다 — 주소창 왼쪽 자물쇠 > 마이크 > 허용 후 새로고침";
    } else if (n === "NotFoundError" || n === "DevicesNotFoundError") {
      msg = "마이크를 찾을 수 없습니다 — 입력 장치를 확인하세요";
    } else if (n === "NotReadableError") {
      msg = "다른 앱이 마이크를 쓰는 중입니다 — 그 앱을 끄고 다시 시도하세요";
    }
    log(msg + " (" + n + ")", "e");
    starting = false;
    scheduleRetry(RETRY_MS); // 권한을 허용하는 순간 알아서 붙게 계속 재시도한다
    return;
  }
  micCtx = new AudioContext({ sampleRate: INPUT_RATE });
  playCtx = new AudioContext({ sampleRate: OUTPUT_RATE });
  unlockAudio();

  try {
    await micCtx.audioWorklet.addModule("pcm-recorder.js?v=4");
  } catch (err) {
    log("AudioWorklet 로드 실패 — http.server 로 열었는지 확인: " + err.message, "e");
    cleanup();
    return;
  }

  const source = micCtx.createMediaStreamSource(micStream);
  micNode = new AudioWorkletNode(micCtx, "pcm-recorder");
  micNode.port.onmessage = onMicFrame;

  const mute = micCtx.createGain();
  mute.gain.value = 0;
  source.connect(micNode);
  micNode.connect(mute);
  mute.connect(micCtx.destination);

  ws = new WebSocket(WS_URL);

  ws.onopen = () => {
    const setup = {
      setup: {
        model: "models/" + MODEL,
        generationConfig: {
          responseModalities: ["AUDIO"],
          speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: activeVoice } } },
        },
        systemInstruction: { parts: [{ text: SYSTEM_INSTRUCTION }] },
      },
    };
    if (ENABLE_TRANSCRIPTION) {
      setup.setup.inputAudioTranscription = {};
      setup.setup.outputAudioTranscription = {};
    }
    send(setup);
  };

  ws.onmessage = async (ev) => {
    const text = ev.data instanceof Blob ? await ev.data.text() : ev.data;
    try { handleMessage(JSON.parse(text)); } catch (err) { /* 무시 */ }
  };

  ws.onerror = () => log("WebSocket 오류", "e");

  ws.onclose = (ev) => {
    log("WebSocket 닫힘 (code " + ev.code + ") " + (ev.reason || "") + " — 다시 붙는 중", "e");
    cleanup();
    scheduleRetry(2000); // 전시 중 세션이 끊겨도 알아서 복구된다
  };

  starting = false;
}

function cleanup() {
  ready = false; starting = false;
  endSuppress();
  flushPlayback("연결 종료");

  if (micNode) { try { micNode.port.onmessage = null; micNode.disconnect(); } catch (e) {} }
  if (micStream) micStream.getTracks().forEach((t) => t.stop());
  if (micCtx) { try { micCtx.close(); } catch (e) {} }
  if (playCtx) { try { playCtx.close(); } catch (e) {} }
  micNode = micStream = micCtx = playCtx = null;
  ws = null;
  awaitingAt = 0;
  log(manualStop ? "끊김 (화면을 클릭하면 다시 시작)" : "다시 연결 중...");
}

// 직접 끊으면 다시 붙지 않는다. 콘솔에서 disconnect() 로도 끌 수 있다.
function disconnect() {
  manualStop = true;
  clearTimeout(retryTimer);
  if (ws && ws.readyState === WebSocket.OPEN) ws.close(1000, "user");
  else cleanup();
}

// ===================== 상태 -> 얼굴 =====================

function currentState() {
  const now = performance.now();
  if (isSpeaking()) return "speaking";
  if (now - lastLoudAt < LISTEN_HOLD_MS) return "listening";
  if (awaitingAt && now - awaitingAt < PROCESS_MAX_MS) return "processing";
  return "idle";
}

function tick() {
  // 사람이 말을 멈춘 직후부터 응답을 기다리는 것으로 본다
  const now = performance.now();
  if (ready && !awaitingAt && !isSpeaking() &&
      lastLoudAt && now - lastLoudAt >= LISTEN_HOLD_MS && now - lastLoudAt < LISTEN_HOLD_MS + 120) {
    awaitingAt = now;
  }

  const s = ready ? currentState() : "idle";
  FACE.setState(s);
  FACE.setLevel(isSpeaking() ? speakLevel : 0);
  requestAnimationFrame(tick);
}
requestAnimationFrame(tick);

// ===================== 입력 =====================

// 브라우저 자동재생 정책 때문에 오디오가 잠겨 있으면, 화면 아무 데나 한 번 누르거나 키를 치면 풀린다.
// 전시용 Chrome/Chromium 은 --autoplay-policy=no-user-gesture-required 로 띄우므로 누를 필요도 없다.
function unlockAudio() {
  [playCtx, micCtx].forEach((c) => {
    if (c && c.state === "suspended") c.resume().catch(() => {});
  });
}
// 클릭 · 터치(라즈베리 파이 터치스크린) · 키 입력: 소리 잠금 해제 + 끊겨 있으면 바로 다시 연결
["pointerdown", "keydown", "touchstart"].forEach((ev) => {
  window.addEventListener(ev, (e) => {
    if (e.key === "Escape") { disconnect(); return; }
    unlockAudio();
    if (!ws && !starting) { manualStop = false; connect(); }
  });
});
setInterval(() => {
  if ((playCtx && playCtx.state === "suspended") || (micCtx && micCtx.state === "suspended")) {
    unlockAudio();
    log("오디오가 잠겨 있음 — 화면을 한 번 누르거나 아무 키나 누르세요", "w");
  }
}, 5000);

log("준비됨 · v4 픽셀 얼굴 (텍스트 없음) — 자동으로 연결합니다. (Esc = 끊기)");
if (!API_KEY) log("주의: key.js 의 GEMINI_KEY 가 비어 있습니다.", "w");

// 페이지가 열리면 클릭을 기다리지 않고 바로 시작한다.
connect();
ILDAN_EOF

cat > "$DIR/face.js" <<'ILDAN_EOF'
// face.js — 픽셀 얼굴 렌더러
// 상태(idle / listening / processing / speaking)에 따라 표정과 모션이 바뀐다.
// 이미지 파일이 아니라 픽셀 격자를 코드로 그리기 때문에 해상도와 모션이 자유롭다.

(function () {
  // ===================== 격자 =====================
  // 32 x 18 격자, 한 칸 60px = 1920 x 1080.
  // 모니터 비율이 바뀌면 여기 세 숫자만 고치면 된다. (예: 520x240mm -> 26 x 12)
  const COLS = 32;
  const ROWS = 18;
  const PX = 60;

  // ===================== 색 =====================
  const C = {
    bg: "#2FD4C6",    // 배경 청록
    dark: "#1C2A63",  // 눈 · 눈썹 · 입 · 윤곽
    mint: "#B4F3D2",  // 하이라이트
    white: "#FFFFFF", // 가장 밝은 점
    pink: "#F73B94",  // 입 안
  };
  const MAP = { "#": C.dark, m: C.mint, w: C.white, p: C.pink };

  // ===================== 스프라이트 =====================
  // '.' 은 투명(배경이 비침)

  // 반쯤 감긴 처진 눈 — idle / processing
  const EYE_DROOPY = [
    "########",
    "########",
    "###mmw##",
    ".##mm###",
    "..#####.",
  ];

  // 열린 둥근 눈 — listening
  const EYE_OPEN = [
    "..####..",
    ".######.",
    "##mmw###",
    "##mm####",
    ".######.",
    "..####..",
  ];

  // 가늘게 뜬 눈 — speaking
  const EYE_SQUINT = [
    "########",
    "#mmmmmw#",
    "##....##",
  ];

  // 감은 눈 (깜빡임) — 폭은 눈과 같게 1줄
  const EYE_BLINK = ["########"];

  // 눈썹
  const BROW_FLAT = ["####"];
  const BROW_ARCH = [
    ".##.",
    "#..#",
  ];
  const BROW_UP = [    // 왼쪽 눈썹: 오른쪽으로 올라감
    "....##",
    "..##..",
    "##....",
  ];
  const BROW_DOWN = [  // 오른쪽 눈썹: 오른쪽으로 내려감
    "##....",
    "..##..",
    "....##",
  ];

  // 입
  const MOUTH_FLAT = ["####"];
  const MOUTH_STEP = [
    "...#",
    "###.",
  ];
  // speaking 입 3단계. 크기를 키우는 게 아니라 아랫줄 픽셀이 생겼다 사라진다.
  const MOUTH_SHUT = [
    "#####",
    ".###.",
  ];
  const MOUTH_HALF = [
    "#####",
    "#ppp#",
    ".###.",
  ];
  const MOUTH_WIDE = [
    "#####",
    "#ppp#",
    "#ppp#",
    ".###.",
  ];

  // ===================== 배치 =====================
  const EYE_L_X = 4, EYE_R_X = 20;   // 눈 좌우 위치 (폭 8)
  const EYE_Y = 6;                   // 처진 눈 기준 줄
  const BROW_Y = 3;
  const MOUTH_X = 14, MOUTH_Y = 13;
  const DOT_Y = 1;                   // 점 세 개 (눈썹과 두 줄 띄움 = 안 부딪힘)
  const DOT_X = [22, 24, 26];

  // ===================== 캔버스 =====================
  let cv, ctx, state = "idle", t0 = performance.now(), mouthLevel = 0;

  function px(x, y, color) {
    ctx.fillStyle = color;
    ctx.fillRect(x * PX, y * PX, PX, PX);
  }

  function sprite(rows, gx, gy) {
    for (let r = 0; r < rows.length; r++) {
      const line = rows[r];
      for (let c = 0; c < line.length; c++) {
        const ch = line[c];
        if (ch === ".") continue;
        px(gx + c, gy + r, MAP[ch] || C.dark);
      }
    }
  }

  // 눈을 그린다. blink 면 감은 모양으로 대체한다.
  function eyes(shape, y, blink) {
    const h = shape.length;
    if (blink) {
      // 감은 눈은 원래 눈의 세로 중앙에 1줄
      const by = y + Math.floor(h / 2);
      sprite(EYE_BLINK, EYE_L_X, by);
      sprite(EYE_BLINK, EYE_R_X, by);
      return;
    }
    sprite(shape, EYE_L_X, y);
    sprite(shape, EYE_R_X, y);
  }

  // 깜빡임: 주기마다 blinkMs 동안 감는다.
  // 상태 전환 시계(t)가 아니라 절대 시계를 쓴다. t 를 쓰면 상태가 바뀔 때마다
  // 시계가 0 으로 돌아가서 전환 직후 매번 눈을 감아버린다.
  function blinking(_t, periodMs, blinkMs) {
    // 주기의 '끝'에서 감는다. 시작(0)에서 감으면 페이지를 열자마자 눈을 감고 있다.
    const p = performance.now() % periodMs;
    return p > periodMs - blinkMs;
  }

  // ===================== 상태별 그리기 =====================

  function drawIdle(t) {
    // 눈: 반쯤 감김, 6~8초에 한 번 느린 깜빡임
    eyes(EYE_DROOPY, EYE_Y, blinking(t, 7000, 260));
    sprite(MOUTH_FLAT, MOUTH_X, MOUTH_Y + 1);
    // 점 세 개: 대각선으로 아주 느리게 떠다님 (idle 에서만 움직인다)
    for (let i = 0; i < 3; i++) {
      const drift = Math.round(Math.sin(t / 1400 + i * 1.1) * 0.5);
      px(DOT_X[i], DOT_Y + (2 - i) + drift, C.dark);
    }
  }

  function drawListening(t) {
    // 눈: 크기 변화 없이 깜빡임만. 2.6초 주기
    eyes(EYE_OPEN, EYE_Y - 1, blinking(t, 2600, 180));
    // 눈썹: 고정 (움직이지 않음)
    sprite(BROW_FLAT, EYE_L_X + 2, BROW_Y);
    sprite(BROW_FLAT, EYE_R_X + 2, BROW_Y);
    sprite(MOUTH_STEP, MOUTH_X + 1, MOUTH_Y);
    // 점 세 개: 위아래 움직임 없이 제자리에서 밝기만 깜빡인다
    for (let i = 0; i < 3; i++) {
      const phase = (t / 520 + i * 0.66) % 3;
      const col = phase < 1 ? C.white : phase < 2 ? C.mint : C.dark;
      px(DOT_X[i], DOT_Y, col);
    }
  }

  function drawProcessing(t) {
    eyes(EYE_DROOPY, EYE_Y, blinking(t, 5200, 200));
    // 왼쪽은 평평하게, 오른쪽만 아치로 한 칸 올려 "한쪽 눈썹만 올라감" 을 만든다.
    // 위로는 점 세 개, 아래로는 눈과 한 줄씩 띄워서 아무것도 겹치지 않는다.
    sprite(BROW_FLAT, EYE_L_X + 2, BROW_Y + 1);
    sprite(BROW_ARCH, EYE_R_X + 2, BROW_Y);
    sprite(MOUTH_HALF, MOUTH_X, MOUTH_Y);
    // 점 세 개가 하나씩 차례로 켜진다
    const lit = Math.floor(t / 320) % 3;
    for (let i = 0; i < 3; i++) px(DOT_X[i], DOT_Y, i === lit ? C.mint : C.dark);
  }

  function drawSpeaking(t) {
    eyes(EYE_SQUINT, EYE_Y + 1, blinking(t, 4400, 200));
    sprite(BROW_UP, EYE_L_X + 1, BROW_Y - 1);
    sprite(BROW_DOWN, EYE_R_X + 1, BROW_Y - 1);
    // 입: 240ms 마다 한 단계. 크기를 키우는 게 아니라 아랫줄 픽셀이 생겼다 사라진다.
    // 위쪽을 고정해서 커졌다 작아지는 것처럼 보이지 않게 한다.
    const step = Math.floor(t / 240) % 4;
    const frame = mouthLevel > 0.02
      ? [MOUTH_HALF, MOUTH_WIDE, MOUTH_HALF, MOUTH_SHUT][step]
      : MOUTH_SHUT;
    sprite(frame, MOUTH_X, MOUTH_Y);
    // 흩어진 점 세 개 (왼쪽 아래)
    for (let i = 0; i < 3; i++) px(4 + i * 2, MOUTH_Y + 1, C.mint);
  }

  const DRAW = {
    idle: drawIdle,
    listening: drawListening,
    processing: drawProcessing,
    speaking: drawSpeaking,
  };

  function loop() {
    const t = performance.now() - t0;
    ctx.fillStyle = C.bg;
    ctx.fillRect(0, 0, COLS * PX, ROWS * PX);
    (DRAW[state] || drawIdle)(t);
    requestAnimationFrame(loop);
  }

  // ===================== 공개 API =====================
  window.FACE = {
    mount(canvas) {
      cv = canvas;
      cv.width = COLS * PX;
      cv.height = ROWS * PX;
      ctx = cv.getContext("2d");
      ctx.imageSmoothingEnabled = false;
      requestAnimationFrame(loop);
    },
    setState(s) {
      if (s === state) return;
      state = s;
      t0 = performance.now(); // 상태가 바뀌면 모션을 처음부터
    },
    getState() { return state; },
    // speaking 일 때 입이 실제로 움직이게 스피커 음량을 넘겨준다
    setLevel(v) { mouthLevel = v; },
    BG: C.bg,
  };
})();
ILDAN_EOF

cat > "$DIR/pcm-recorder.js" <<'ILDAN_EOF'
// pcm-recorder.js
// 마이크 입력을 16-bit PCM 조각으로 잘라 메인 스레드로 넘기는 AudioWorklet.
// AudioContext 를 16000Hz 로 열어두면 여기 들어오는 샘플은 이미 16kHz 라
// 따로 리샘플링할 필요가 없다.

const FRAME = 1024; // 1024 samples @ 16kHz = 64ms

class PCMRecorder extends AudioWorkletProcessor {
  constructor() {
    super();
    this.buf = new Float32Array(FRAME);
    this.n = 0;
  }

  process(inputs) {
    const ch = inputs[0] && inputs[0][0];
    if (!ch) return true;

    for (let i = 0; i < ch.length; i++) {
      this.buf[this.n++] = ch[i];
      if (this.n < FRAME) continue;

      const pcm = new Int16Array(FRAME);
      let sum = 0;
      for (let j = 0; j < FRAME; j++) {
        const s = Math.max(-1, Math.min(1, this.buf[j]));
        pcm[j] = s < 0 ? s * 0x8000 : s * 0x7fff;
        sum += s * s;
      }
      // rms 는 표정 상태 판정(말하는 중인지)과 끼어들기 감지에 쓴다.
      this.port.postMessage({ pcm: pcm.buffer, rms: Math.sqrt(sum / FRAME) }, [pcm.buffer]);
      this.n = 0;
    }
    return true;
  }
}

registerProcessor('pcm-recorder', PCMRecorder);
ILDAN_EOF

# ── API 키 ─────────────────────────────────────────
KEY="${GEMINI_KEY:-}"
if [ -z "$KEY" ] && [ -f "$DIR/key.js" ]; then
  KEY="$(sed -n 's/.*GEMINI_KEY *= *"\(.*\)".*/\1/p' "$DIR/key.js")"
fi
if [ -z "$KEY" ]; then
  echo "Gemini API 키를 붙여넣고 Enter (화면엔 안 보임)"
  echo "  발급: https://aistudio.google.com/api-keys"
  read -rs KEY
  echo
fi
KEY="$(printf '%s' "$KEY" | tr -d '[:space:]"')"
[ -n "$KEY" ] || { echo "키가 비어 있어서 종료합니다."; exit 1; }
printf 'window.GEMINI_KEY = "%s";\n' "$KEY" > "$DIR/key.js"
chmod 600 "$DIR/key.js"

# ── 빈 포트 찾아서 서버 띄우기 ─────────────────────────
PORT="$(python3 - <<'PY'
import socket
for p in range(8010, 8100):
    s = socket.socket()
    try:
        s.bind(("127.0.0.1", p)); print(p); break
    except OSError:
        pass
    finally:
        s.close()
PY
)"
python3 -m http.server "$PORT" --bind 127.0.0.1 --directory "$DIR" >/dev/null 2>&1 &
SERVER=$!
trap 'kill $SERVER 2>/dev/null; echo; echo "일단 종료"' EXIT INT TERM
sleep 0.5

URL="http://localhost:$PORT/"
echo "일단 실행 중: $URL"
echo "종료하려면 Ctrl+C"

# ── 브라우저 열기 (전체 화면 · 클릭 없이 소리 · 마이크 자동 허용) ──────
FLAGS=(--app="$URL" --start-fullscreen --autoplay-policy=no-user-gesture-required --use-fake-ui-for-media-stream --user-data-dir="$DIR/.chrome")
if [ "$(uname)" = "Darwin" ]; then
  if [ -d "/Applications/Google Chrome.app" ]; then
    open -na "Google Chrome" --args "${FLAGS[@]}"
  else
    echo "Chrome 이 없어서 기본 브라우저로 엽니다. 소리가 안 나면 화면을 한 번 클릭하세요."
    open "$URL"
  fi
else
  # 라즈베리 파이 / 리눅스
  # SSH 로 접속해서 실행해도 파이에 연결된 모니터에 뜨게 한다
  export DISPLAY="${DISPLAY:-:0}"
  BROWSER=""
  for b in chromium-browser chromium google-chrome; do
    command -v "$b" >/dev/null 2>&1 && { BROWSER="$b"; break; }
  done
  if [ -n "$BROWSER" ]; then
    "$BROWSER" --kiosk "${FLAGS[@]}" >/dev/null 2>&1 &
  else
    echo "브라우저를 직접 열어 주세요: $URL"
  fi
fi

wait $SERVER
