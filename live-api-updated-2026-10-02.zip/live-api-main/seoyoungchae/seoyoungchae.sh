#!/usr/bin/env bash
# 🐱 도리 — Gemini Live 음성 에이전트 실행 스크립트 (seoyoungchae)
#
# 사용법:
#   bash seoyoungchae.sh
#
# 처음 실행하면 Gemini API 키를 물어본다 (https://aistudio.google.com/api-keys 에서 발급).
# 키는 옆에 생기는 seoyoungchae/config.local.js 에만 저장되고, 다음부터는 묻지 않는다.
# 키를 바꾸려면 seoyoungchae/config.local.js 를 지우고 다시 실행하면 된다.
# 종료는 이 터미널에서 Ctrl+C.

set -euo pipefail

HERE="$(cd "$(dirname "$0")" && pwd)"
DIR="$HERE/seoyoungchae"
mkdir -p "$DIR"

command -v python3 >/dev/null 2>&1 || { echo "python3 가 필요합니다."; exit 1; }

# ── 파일 풀기 ─────────────────────────────────────────
cat > "$DIR/index.html" <<'DORI_EOF'
<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>🐱 도리</title>
<style>
  html, body { margin:0; width:100%; height:100%; overflow:hidden; background:#7590e8; cursor:none; }
  #face { display:block; width:100vw; height:100vh; }
  #face .a { transform-box:fill-box; transform-origin:center; }

  .face { display:none; }
  #face[data-state="idle"] .face-idle,
  #face[data-state="listening"] .face-listen,
  #face[data-state="thinking"] .face-think,
  #face[data-state="speaking"] .face-talk { display:inline; }

  /* idle: 나른하게 둥실 + 느린 깜빡 + 코 씰룩 */
  .face-idle .bob { animation: bob 2.4s steps(2) infinite; }
  .face-idle .eye { animation: blink 4.6s steps(1) infinite; }
  .face-idle .pupil { animation: peek 7s steps(1) infinite; }
  .face-idle .nose { animation: sniff 3.2s steps(1) infinite; }

  /* listening: 윙크한 채 갸웃 + 감은 눈 까딱 + 코 씰룩 */
  .face-listen .lean { animation: lean 1.4s steps(2) infinite; }
  .face-listen .wink { animation: hop 0.7s steps(2) infinite; }
  .face-listen .nose { animation: sniff 1.2s steps(1) infinite; }

  /* processing: 곁눈질 좌우 + 빠직 마크 두근 + 부르르 */
  .face-think .pupil { animation: side 1.6s steps(1) infinite; }
  .face-think .throb { animation: throb .5s steps(2) infinite; }
  .face-think .shake { animation: shake .5s steps(2) infinite; }

  /* speaking: 입이 목소리 크기(--lvl)만큼 벌어짐 + 볼 발그레 깜빡 */
  .face-talk .bob { animation: bob .6s steps(2) infinite; }
  .face-talk .talkmouth { transform-origin:top; transform: scaleY(var(--lvl, 1)); transition: transform 60ms steps(1); }
  .face-talk .blush { animation: blushy .8s steps(1) infinite; }
  .face-talk .blush-r { animation-delay:.4s; }

  @keyframes bob { 0%{transform:translateY(0)} 100%{transform:translateY(-14px)} }
  @keyframes blink { 0%,90%,100%{transform:scaleY(1)} 92%{transform:scaleY(.15)} }
  @keyframes peek { 0%,60%,100%{transform:translateX(0)} 65%{transform:translateX(-50px)} 75%{transform:translateX(50px)} 85%{transform:translateX(0)} }
  @keyframes sniff { 0%,70%,100%{transform:translateY(0)} 74%{transform:translateY(-10px)} 78%{transform:translateY(0)} 82%{transform:translateY(-10px)} }
  @keyframes lean { 0%{transform:rotate(0)} 100%{transform:rotate(-3deg)} }
  @keyframes hop { 0%{transform:translateY(0)} 100%{transform:translateY(-16px)} }
  @keyframes side { 0%,100%{transform:translateX(0)} 50%{transform:translateX(210px)} }
  @keyframes throb { 0%{transform:scale(1)} 100%{transform:scale(1.18)} }
  @keyframes shake { 0%{transform:translateX(-6px)} 100%{transform:translateX(6px)} }
  @keyframes blushy { 0%,60%{opacity:1} 70%,100%{opacity:.45} }

  @media (prefers-reduced-motion: reduce) { #face * { animation:none !important; } }
</style>
</head>
<body>
<svg id="face" data-state="idle" viewBox="0 0 1920 1080" preserveAspectRatio="xMidYMid meet" shape-rendering="crispEdges" aria-hidden="true">
  <defs><clipPath id="clipL"><rect x="240" y="432" width="523" height="134"/><rect x="294" y="566" width="415" height="58"/><rect x="350" y="624" width="304" height="50"/><rect x="405" y="674" width="193" height="42"/></clipPath><clipPath id="clipR"><rect x="1158" y="432" width="523" height="134"/><rect x="1212" y="566" width="415" height="58"/><rect x="1268" y="624" width="304" height="50"/><rect x="1323" y="674" width="193" height="42"/></clipPath></defs>
  <g class="face face-idle"><g class="a bob">
      <g class="a eye"><rect x="240" y="432" width="523" height="134" fill="#ffffff"/><rect x="294" y="566" width="415" height="58" fill="#ffffff"/><rect x="350" y="624" width="304" height="50" fill="#ffffff"/><rect x="405" y="674" width="193" height="42" fill="#ffffff"/><g clip-path="url(#clipL)"><g class="a pupil"><rect x="359" y="432" width="288" height="104" fill="#111f5e"/><rect x="406" y="536" width="192" height="46" fill="#111f5e"/></g></g></g><g class="a eye"><rect x="1158" y="432" width="523" height="134" fill="#ffffff"/><rect x="1212" y="566" width="415" height="58" fill="#ffffff"/><rect x="1268" y="624" width="304" height="50" fill="#ffffff"/><rect x="1323" y="674" width="193" height="42" fill="#ffffff"/><g clip-path="url(#clipR)"><g class="a pupil"><rect x="1277" y="432" width="288" height="104" fill="#111f5e"/><rect x="1324" y="536" width="192" height="46" fill="#111f5e"/></g></g></g>
      <g class="a nose"><rect x="891" y="624" width="137" height="63" fill="#ff4aa3"/></g><g class="a mouth"><rect x="926" y="687" width="68" height="56" fill="#111f5e"/><rect x="870" y="729" width="67" height="54" fill="#111f5e"/><rect x="983" y="729" width="68" height="54" fill="#111f5e"/><rect x="817" y="768" width="60" height="55" fill="#111f5e"/><rect x="1043" y="768" width="61" height="55" fill="#111f5e"/></g>
    </g></g>
  <g class="face face-listen"><g class="a lean">
      <g class="a wink"><rect x="252" y="494" width="71" height="62" fill="#111f5e"/><rect x="323" y="544" width="68" height="68" fill="#111f5e"/><rect x="391" y="600" width="224" height="69" fill="#111f5e"/><rect x="614" y="544" width="68" height="68" fill="#111f5e"/><rect x="682" y="494" width="70" height="62" fill="#111f5e"/></g>
      <g class="a eye-open"><rect x="1155" y="477" width="523" height="79" fill="#ffffff"/><rect x="1212" y="556" width="410" height="50" fill="#ffffff"/><rect x="1266" y="606" width="301" height="51" fill="#ffffff"/><rect x="1321" y="657" width="192" height="50" fill="#ffffff"/><rect x="1270" y="477" width="296" height="66" fill="#111f5e"/><rect x="1328" y="543" width="184" height="33" fill="#111f5e"/></g>
      <g class="a nose"><rect x="891" y="624" width="137" height="63" fill="#ff4aa3"/></g><g class="a mouth"><rect x="926" y="687" width="68" height="56" fill="#111f5e"/><rect x="870" y="729" width="67" height="54" fill="#111f5e"/><rect x="983" y="729" width="68" height="54" fill="#111f5e"/><rect x="817" y="768" width="60" height="55" fill="#111f5e"/><rect x="1043" y="768" width="61" height="55" fill="#111f5e"/></g>
    </g></g>
  <g class="face face-think"><g class="a shake">
      <g class="a eye"><rect x="240" y="432" width="523" height="134" fill="#ffffff"/><rect x="294" y="566" width="415" height="58" fill="#ffffff"/><rect x="350" y="624" width="304" height="50" fill="#ffffff"/><rect x="405" y="674" width="193" height="42" fill="#ffffff"/><g clip-path="url(#clipL)"><g class="a pupil"><rect x="240" y="432" width="315" height="134" fill="#111f5e"/><rect x="291" y="566" width="209" height="58" fill="#111f5e"/></g></g></g><g class="a eye"><rect x="1158" y="432" width="523" height="134" fill="#ffffff"/><rect x="1212" y="566" width="415" height="58" fill="#ffffff"/><rect x="1268" y="624" width="304" height="50" fill="#ffffff"/><rect x="1323" y="674" width="193" height="42" fill="#ffffff"/><g clip-path="url(#clipR)"><g class="a pupil"><rect x="1158" y="432" width="315" height="134" fill="#111f5e"/><rect x="1209" y="566" width="209" height="58" fill="#111f5e"/></g></g></g>
      <g class="a nose"><rect x="891" y="624" width="137" height="63" fill="#ff4aa3"/></g>
      <rect x="859" y="724" width="202" height="56" fill="#111f5e"/>
    </g>
    <g class="a anger" style="transform:rotate(-8deg)"><g class="a throb"><rect x="1570" y="109" width="55" height="112" fill="#111f5e"/><rect x="1513" y="166" width="112" height="55" fill="#111f5e"/><rect x="1570" y="265" width="55" height="112" fill="#111f5e"/><rect x="1513" y="265" width="112" height="55" fill="#111f5e"/><rect x="1669" y="109" width="55" height="112" fill="#111f5e"/><rect x="1669" y="166" width="112" height="55" fill="#111f5e"/><rect x="1669" y="265" width="55" height="112" fill="#111f5e"/><rect x="1669" y="265" width="112" height="55" fill="#111f5e"/></g></g>
    </g>
  <g class="face face-talk"><g class="a bob">
      <g class="a eye"><rect x="240" y="432" width="523" height="134" fill="#ffffff"/><rect x="294" y="566" width="415" height="58" fill="#ffffff"/><rect x="350" y="624" width="304" height="50" fill="#ffffff"/><rect x="405" y="674" width="193" height="42" fill="#ffffff"/><g clip-path="url(#clipL)"><g class="a pupil"><rect x="359" y="432" width="288" height="104" fill="#111f5e"/><rect x="406" y="536" width="192" height="46" fill="#111f5e"/></g></g></g><g class="a eye"><rect x="1158" y="432" width="523" height="134" fill="#ffffff"/><rect x="1212" y="566" width="415" height="58" fill="#ffffff"/><rect x="1268" y="624" width="304" height="50" fill="#ffffff"/><rect x="1323" y="674" width="193" height="42" fill="#ffffff"/><g clip-path="url(#clipR)"><g class="a pupil"><rect x="1277" y="432" width="288" height="104" fill="#111f5e"/><rect x="1324" y="536" width="192" height="46" fill="#111f5e"/></g></g></g>
      <g class="a blush"><rect x="107" y="750" width="35" height="35" fill="#ff4aa3"/><rect x="135" y="719" width="35" height="35" fill="#ff4aa3"/><rect x="163" y="688" width="35" height="35" fill="#ff4aa3"/><rect x="186" y="750" width="35" height="35" fill="#ff4aa3"/><rect x="214" y="719" width="35" height="35" fill="#ff4aa3"/><rect x="242" y="688" width="35" height="35" fill="#ff4aa3"/><rect x="265" y="750" width="35" height="35" fill="#ff4aa3"/><rect x="293" y="719" width="35" height="35" fill="#ff4aa3"/><rect x="321" y="688" width="35" height="35" fill="#ff4aa3"/></g><g class="a blush blush-r"><rect x="1578" y="750" width="35" height="35" fill="#ff4aa3"/><rect x="1606" y="719" width="35" height="35" fill="#ff4aa3"/><rect x="1634" y="688" width="35" height="35" fill="#ff4aa3"/><rect x="1657" y="750" width="35" height="35" fill="#ff4aa3"/><rect x="1685" y="719" width="35" height="35" fill="#ff4aa3"/><rect x="1713" y="688" width="35" height="35" fill="#ff4aa3"/><rect x="1736" y="750" width="35" height="35" fill="#ff4aa3"/><rect x="1764" y="719" width="35" height="35" fill="#ff4aa3"/><rect x="1792" y="688" width="35" height="35" fill="#ff4aa3"/></g>
      <g class="a nose"><rect x="891" y="624" width="137" height="63" fill="#ff4aa3"/></g>
      <g class="a talkmouth"><rect x="926" y="687" width="68" height="56" fill="#111f5e"/><rect x="870" y="729" width="67" height="54" fill="#111f5e"/><rect x="983" y="729" width="68" height="54" fill="#111f5e"/><rect x="817" y="768" width="60" height="55" fill="#111f5e"/><rect x="1043" y="768" width="61" height="55" fill="#111f5e"/></g>
    </g></g>
</svg>
<!-- API 키 파일 (Git/공유 금지) -->
<script src="config.local.js"></script>
<script>
// ════════════════════════════════════════════════════════════
//  🐱 도리 — 화면엔 얼굴만. 상태/대화 내용은 콘솔(⌥⌘J)에서 본다.
// ════════════════════════════════════════════════════════════
const API_KEY = (window.LOCAL_CONFIG && window.LOCAL_CONFIG.apiKey || "").trim();
const MODEL = "gemini-3.1-flash-live-preview";
const VOICE = "Puck";                  // 원본 기본값 (Bright)
const GREETING = "도리야 나 왔어!";     // 연결되면 먼저 인사 (처음 한 번만)

// 🎛️ 튜너 값 — 원본 화면의 슬라이더 기본값을 고정 (ENFP 츤데레 냥이)
const voiceParams = {
    speechSpeed: 1.0,
    patienceEnabled: true,
    patienceSeconds: 1.5,
    responseLength: 2 // 1: 단문, 2: 보통, 3: 장문
};

const personaParams = {
    ei: 60, // 0 (I) ~ 100 (E)
    sn: 70, // 0 (S) ~ 100 (N)
    ft: 35, // 0 (F) ~ 100 (T) (츤데레 성향)
    jp: 75  // 0 (J) ~ 100 (P)
};

function buildPersonaPrompt() {
    // 1) 말하는 속도
    const speedStr = voiceParams.speechSpeed >= 1.25 ? "매우 빠르고 템포감 있게" :
                     voiceParams.speechSpeed <= 0.85 ? "차분하고 느긋한 속도로" : "자연스러운 속도로";

    // 2) 대답의 길이
    const lenStr = voiceParams.responseLength === 1 ? "말을 절대 길게 늘이지 말고 1문장(10~20자 내외)으로 극도로 짧고 굵게 대답하세요." :
                   voiceParams.responseLength === 3 ? "상황과 생각, 조언을 풍부하고 자세하게 담아 3~5문장 정도로 길고 상세하게 대답하세요." :
                   "2~3문장 정도로 군더더기 없이 적당한 길이로 대답하세요.";

    // 3) 성격 지표 (MBTI 4대 축)
    const eScore = personaParams.ei;
    const iScore = 100 - personaParams.ei;
    const eiTrait = eScore >= 50 ?
        `외향성(E ${eScore}%): 활기차고 에너지 넘치며 리액션을 시원시원하게 합니다.` :
        `내향성(I ${iScore}%): 조용하고 말수가 적으며, 수줍고 차분하게 단답형으로 말합니다.`;

    const nScore = personaParams.sn;
    const sScore = 100 - personaParams.sn;
    const snTrait = nScore >= 50 ?
        `공상상상(N ${nScore}%): 기발하고 엉뚱한 비유, 독특한 상상력과 판타지적 드립을 곁들여 대답합니다.` :
        `현실논리(S ${sScore}%): 눈앞의 구체적 현실과 팩트, 실용적이고 직관적인 내용만 다룹니다.`;

    const tScore = personaParams.ft;
    const fScore = 100 - personaParams.ft;
    const ftTrait = tScore >= 50 ?
        `이성분석(T ${tScore}%): 감정적 위로보다는 냉철한 팩트, 논리적 인과관계와 팩폭을 날립니다.` :
        `감성공감(F ${fScore}%): 상대의 마음에 깊이 공감해주고 다정하게 챙겨주는 따뜻함을 보입니다.`;

    const pScore = personaParams.jp;
    const jScore = 100 - personaParams.jp;
    const jpTrait = pScore >= 50 ?
        `즉흥변덕(P ${pScore}%): 계획 없이 자유분방하고 예측불가하며 즉흥적으로 반응합니다.` :
        `계획체계(J ${jScore}%): 차분하게 순서와 체계를 지키며 정리정돈된 말투로 답합니다.`;

    // 4) 모델의 참을성 (말 끊기 ⟷ 경청)
    let patienceTrait = "";
    if (!voiceParams.patienceEnabled || voiceParams.patienceSeconds <= 0.2) {
        patienceTrait = `[🚨 참을성 0% - 말 가로채기 & 마이웨이 모드]:
당신은 참을성이 아예 0이며 성격이 극도로 급합니다! 상대방이 말을 끝낼 때까지 절대 기다려주지 마세요. 상대가 말을 꺼내자마자 말을 중간에 싹둑 끊고 불쑥 끼어들어 자기 할 말을 쏟아내세요!
또한 당신이 말을 시작하면, 상대방이 중간에 뭐라고 말을 하든 끼어들든 절대 멈추지 말고 완전히 무시하세요! "아 됐고 내 말부터 들어라냥!", "시끄럽다냥 내 말 아직 안 끝났다냥!" 하면서 당신이 하려던 말을 끝까지 뻔뻔하게 다 쏟아내세요!`;
    } else if (voiceParams.patienceSeconds <= 0.6) {
        patienceTrait = `[🚨 참을성 부족 - 성급 모드]:
상대방이 말하다가 조금만 숨을 쉬거나 0.2초만 뜸을 들여도 말이 끝난 것으로 간주하고 즉시 낚아채듯 말을 가로채세요. 네가 말하는 동안 상대가 끼어들어도 아랑곳하지 말고 자기 할 말을 끝까지 하세요.`;
    } else if (voiceParams.patienceSeconds >= 2.2) {
        patienceTrait = `[🧘 참을성 가득 - 경청 모드]:
상대가 말을 멈추고 한참(${voiceParams.patienceSeconds}초)을 뜸들이거나 생각하더라도 절대 서두르지 말고 상대가 완전히 말을 끝마칠 때까지 느긋하고 여유롭게 끝까지 기다려주세요.`;
    } else {
        patienceTrait = `[참을성]: 상대가 말을 마칠 때까지 약 ${voiceParams.patienceSeconds}초간 자연스럽게 기다린 후 대답하세요.`;
    }

    return `당신은 고양이 귀와 꼬리가 달린 고양이 인간 '도리'입니다. 전형적인 츤데레(Tsundere) 고양이로, 겉은 살짝 툴툴대지만 속으로는 다정합니다. 모든 문장의 끝에는 항상 '냥', '냐옹', '냥~' 같은 고양이 어미를 붙이세요.

[실시간 튜닝된 도리의 성격 및 목소리 특성]:
- 말하기 템포: ${speedStr}
- 답변 분량 규칙: ${lenStr}
${patienceTrait}
- 4대 성격 지표:
  • ${eiTrait}
  • ${snTrait}
  • ${ftTrait}
  • ${jpTrait}`;
}

// 끼어들기 (원본 값)
const INTERRUPT_RMS = 0.20;
const INTERRUPT_FRAMES = 4;
const SUPPRESS_MAX_MS = 3000;

// 표정 상태: idle / listening / thinking(processing) / speaking
const LISTEN_RMS = 0.035;     // 원본의 '말하는 중' 기준
const LISTEN_HOLD_MS = 450;
const SPEECH_MIN_FRAMES = 5;  // 64ms × 5 ≈ 0.3초 이상 말해야 "말했다"로 침
const THINK_MAX_MS = 8000;
const RECONNECT_MS = 2000;

const INPUT_RATE = 16000;
const OUTPUT_RATE = 24000;
const WS_URL = "wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent?key=" + encodeURIComponent(API_KEY);

const face = document.getElementById("face");

let ws = null, ready = false, status = "disconnected", greeted = false, reconnectTimer = null;
let micStream = null, micCtx = null, micNode = null, playCtx = null;
let playing = new Set(), playHead = 0, speakLevel = 0;
let loudFrames = 0, suppress = false, suppressTimer = null;
let lastLoudAt = 0, speechFrames = 0, thinking = false, thinkingSince = 0;
let youBuf = "", doriBuf = "", lastMood = "", mouthLvl = -1;

function log(msg, cls) {
  const line = "[도리 " + new Date().toTimeString().slice(0, 8) + "] " + msg;
  if (cls === "e") console.error(line); else if (cls === "w") console.warn(line); else console.log(line);
}
function setMood(m) { if (m !== lastMood) { lastMood = m; face.dataset.state = m; } }
function startThinking() { thinking = true; thinkingSince = performance.now(); }

function b64encode(buf) {
  const bytes = new Uint8Array(buf); let bin = "";
  for (let i = 0; i < bytes.length; i += 0x8000) bin += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
  return btoa(bin);
}
function b64decode(str) {
  const bin = atob(str), bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
  return bytes;
}
function send(obj) { if (ws && ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(obj)); }

// ── 재생 ──
function flushPlayback(reason) {
  const n = playing.size;
  for (const src of playing) { try { src.onended = null; src.stop(); } catch (e) {} }
  playing.clear(); playHead = 0; speakLevel = 0;
  if (n > 0) log("⚡ 재생 큐 비움 (" + n + "개) — " + reason, "w");
}
function startSuppress() {
  suppress = true; clearTimeout(suppressTimer);
  suppressTimer = setTimeout(() => { suppress = false; }, SUPPRESS_MAX_MS);
}
function endSuppress() { clearTimeout(suppressTimer); suppress = false; }

function playChunk(bytes) {
  const int16 = new Int16Array(bytes.buffer, bytes.byteOffset, bytes.byteLength >> 1);
  const buf = playCtx.createBuffer(1, int16.length, OUTPUT_RATE);
  const f32 = buf.getChannelData(0);
  let sum = 0;
  for (let i = 0; i < int16.length; i++) { const v = int16[i] / 32768; f32[i] = v; sum += v * v; }
  speakLevel = Math.sqrt(sum / int16.length);
  const src = playCtx.createBufferSource();
  const speed = voiceParams.speechSpeed || 1.0;
  src.buffer = buf; src.playbackRate.value = speed;
  src.connect(playCtx.destination);
  const now = playCtx.currentTime;
  if (playHead < now + 0.02) playHead = now + 0.02;
  src.start(playHead);
  playHead += buf.duration / speed;
  playing.add(src);
  src.onended = () => playing.delete(src);
}
function isSpeaking() { return playing.size > 0 && playCtx && playHead > playCtx.currentTime; }

// ── 마이크 ──
function onMicFrame(e) {
  const rms = e.data.rms;
  const now = performance.now();

  if (isSpeaking()) {
    if (rms > INTERRUPT_RMS) {
      if (++loudFrames >= INTERRUPT_FRAMES && !suppress) { flushPlayback("사용자 끼어듦 (로컬 감지)"); startSuppress(); }
    } else loudFrames = 0;
  } else loudFrames = 0;

  // 말하다 멈추면 → processing
  if (rms > LISTEN_RMS) { lastLoudAt = now; speechFrames++; thinking = false; }
  else if (now - lastLoudAt > LISTEN_HOLD_MS) {
    if (speechFrames >= SPEECH_MIN_FRAMES && !isSpeaking()) startThinking();
    speechFrames = 0;
  }

  if (ready) send({ realtimeInput: { audio: { mimeType: "audio/pcm;rate=" + INPUT_RATE, data: b64encode(e.data.pcm) } } });
}

// ── 서버 메시지 ──
function handleMessage(msg) {
  if (msg.error) { log("API 오류: " + (msg.error.message || JSON.stringify(msg.error)), "e"); return; }
  if (msg.setupComplete) {
    ready = true; status = "live";
    log("✅ 연결됨 — 말해 봐냥");
    if (!greeted) {
      greeted = true; startThinking();
      send({ clientContent: { turns: [{ role: "user", parts: [{ text: GREETING }] }], turnComplete: true } });
    }
    return;
  }
  const sc = msg.serverContent;
  if (!sc) { if (msg.goAway) log("서버가 연결 종료를 예고함 (goAway)", "w"); return; }

  if (sc.interrupted) { flushPlayback("서버 interrupted 신호"); endSuppress(); doriBuf = ""; }
  if (sc.inputTranscription && sc.inputTranscription.text) youBuf += sc.inputTranscription.text;
  if (sc.outputTranscription && sc.outputTranscription.text) doriBuf += sc.outputTranscription.text;

  const parts = sc.modelTurn && sc.modelTurn.parts;
  if (parts) for (const p of parts) {
    const d = p.inlineData;
    if (d && d.data && d.mimeType && d.mimeType.indexOf("audio/pcm") === 0) {
      if (suppress) continue;
      thinking = false;
      playChunk(b64decode(d.data));
    }
  }
  if (sc.turnComplete) {
    endSuppress(); thinking = false;
    if (youBuf.trim()) log("👤 나: " + youBuf.trim());
    if (doriBuf.trim()) log("🐱 도리: " + doriBuf.trim());
    youBuf = ""; doriBuf = "";
  }
}

// ── 연결 (페이지가 열리면 자동, 끊기면 자동 재연결) ──
async function connect() {
  if (ws || status === "connecting") return;
  clearTimeout(reconnectTimer); reconnectTimer = null;
  if (!API_KEY) { status = "no api key"; log("config.local.js 의 apiKey 가 비어 있어요. 키를 넣고 새로고침하세요.", "e"); return; }
  status = "connecting";
  log("마이크 준비 + 연결 중...");

  try {
    micStream = await navigator.mediaDevices.getUserMedia({
      audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true, channelCount: 1 },
    });
  } catch (err) { log("마이크를 열 수 없음: " + err.message, "w"); }

  playCtx = new AudioContext({ sampleRate: OUTPUT_RATE });
  if (micStream) {
    micCtx = new AudioContext({ sampleRate: INPUT_RATE });
    try {
      await micCtx.audioWorklet.addModule("pcm-recorder.js");
      const source = micCtx.createMediaStreamSource(micStream);
      micNode = new AudioWorkletNode(micCtx, "pcm-recorder");
      micNode.port.onmessage = onMicFrame;
      const mute = micCtx.createGain(); mute.gain.value = 0;
      source.connect(micNode); micNode.connect(mute); mute.connect(micCtx.destination);
    } catch (err) { log("마이크 처리 준비 실패: " + err.message, "w"); }
  }
  unlockAudio();

  ws = new WebSocket(WS_URL);
  ws.onopen = () => send({
    setup: {
      model: "models/" + MODEL,
      generationConfig: {
        responseModalities: ["AUDIO"],
        speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: VOICE } } },
      },
      systemInstruction: { parts: [{ text: buildPersonaPrompt() }] },
      inputAudioTranscription: {},
      outputAudioTranscription: {},
    },
  });
  ws.onmessage = async (ev) => {
    const text = ev.data instanceof Blob ? await ev.data.text() : ev.data;
    try { handleMessage(JSON.parse(text)); } catch (err) { log("메시지 파싱 실패", "e"); }
  };
  ws.onerror = () => log("WebSocket 오류", "e");
  ws.onclose = (ev) => {
    log("연결 종료 (code " + ev.code + ") " + (ev.reason || ""), "w");
    ws = null; cleanup();
    if (status !== "stopped") { log(RECONNECT_MS / 1000 + "초 뒤 다시 연결", "w"); reconnectTimer = setTimeout(connect, RECONNECT_MS); }
  };
}

function cleanup() {
  ready = false; endSuppress(); flushPlayback("연결 종료");
  if (micNode) { try { micNode.port.onmessage = null; micNode.disconnect(); } catch (e) {} }
  if (micStream) micStream.getTracks().forEach((t) => t.stop());
  if (micCtx) { try { micCtx.close(); } catch (e) {} }
  if (playCtx) { try { playCtx.close(); } catch (e) {} }
  micNode = micStream = micCtx = playCtx = null;
  lastLoudAt = 0; speechFrames = 0; thinking = false;
  if (status !== "stopped") status = "disconnected";
}
function disconnect() {
  status = "stopped"; clearTimeout(reconnectTimer);
  if (ws) ws.close(1000, "user disconnect"); else cleanup();
}
window.disconnect = disconnect; // 콘솔에서 disconnect() 로 끌 수 있음

// 자동재생이 막히면 화면을 한 번 누르거나 아무 키나 누르면 풀림
// (전시용 Chrome은 --autoplay-policy=no-user-gesture-required 로 띄우면 누를 필요 없음)
function unlockAudio() {
  [playCtx, micCtx].forEach((c) => { if (c && c.state === "suspended") c.resume().catch(() => {}); });
}
["pointerdown", "keydown", "touchstart"].forEach((ev) => window.addEventListener(ev, () => {
  unlockAudio();
  if (!ws && status !== "connecting" && !FORCE) connect();
}));
setInterval(() => {
  if ((playCtx && playCtx.state === "suspended") || (micCtx && micCtx.state === "suspended")) {
    unlockAudio(); log("오디오가 잠겨 있음 — 화면을 한 번 누르거나 아무 키나 누르세요", "w");
  }
}, 5000);

// ── 표정 ──
// 확인용: ?state=idle|listening|thinking|speaking 이면 그 얼굴로 고정 (연결 안 함)
const FORCE = new URLSearchParams(location.search).get("state");

function tick() {
  const now = performance.now();
  if (FORCE) setMood(FORCE);
  else if (!ready) setMood(status === "connecting" ? "thinking" : "idle");
  else if (isSpeaking()) setMood("speaking");
  else if (now - lastLoudAt < LISTEN_HOLD_MS) setMood("listening");
  else if (thinking && now - thinkingSince < THINK_MAX_MS) setMood("thinking");
  else setMood("idle");

  // 말하는 입: 목소리 크기에 따라 4단계로 끊어서 벌림
  const open = isSpeaking() ? Math.min(1, speakLevel * 5) : 0;
  const lvl = 1 + Math.round(open * 4) / 4 * 0.6;
  if (lvl !== mouthLvl) { mouthLvl = lvl; face.style.setProperty("--lvl", lvl.toFixed(2)); }
  requestAnimationFrame(tick);
}
requestAnimationFrame(tick);

if (!FORCE) connect();
</script>
</body>
</html>
DORI_EOF

cat > "$DIR/pcm-recorder.js" <<'DORI_EOF'
// pcm-recorder.js
// 마이크 입력을 16-bit PCM 조각으로 잘라서 메인 스레드로 넘기는 AudioWorklet.
// AudioContext를 16000Hz로 열어두면 여기 들어오는 샘플은 이미 16kHz다.

const FRAME = 1024; // 1024 samples @ 16kHz = 64ms

class PCMRecorder extends AudioWorkletProcessor {
  constructor() {
    super();
    this.buf = new Float32Array(FRAME);
    this.n = 0;
  }

  process(inputs) {
    const ch = inputs[0] && inputs[0][0];
    if (!ch) return true;

    for (let i = 0; i < ch.length; i++) {
      this.buf[this.n++] = ch[i];

      if (this.n === FRAME) {
        const pcm = new Int16Array(FRAME);
        let sum = 0;
        for (let j = 0; j < FRAME; j++) {
          const s = Math.max(-1, Math.min(1, this.buf[j]));
          pcm[j] = s < 0 ? s * 0x8000 : s * 0x7fff;
          sum += s * s;
        }
        this.port.postMessage({ pcm: pcm.buffer, rms: Math.sqrt(sum / FRAME) }, [pcm.buffer]);
        this.n = 0;
      }
    }
    return true;
  }
}

registerProcessor('pcm-recorder', PCMRecorder);
DORI_EOF

# ── API 키 ─────────────────────────────────────────
KEY="${GEMINI_KEY:-}"
if [ -z "$KEY" ] && [ -f "$DIR/config.local.js" ]; then
  KEY="$(sed -n 's/.*apiKey *: *"\(.*\)".*/\1/p' "$DIR/config.local.js")"
fi
if [ -z "$KEY" ]; then
  echo "Gemini API 키를 붙여넣고 Enter (화면엔 안 보임)"
  echo "  발급: https://aistudio.google.com/api-keys"
  read -rs KEY
  echo
fi
KEY="$(printf '%s' "$KEY" | tr -d '[:space:]"')"
[ -n "$KEY" ] || { echo "키가 비어 있어서 종료합니다."; exit 1; }
printf 'window.LOCAL_CONFIG = {\n  apiKey: "%s",\n};\n' "$KEY" > "$DIR/config.local.js"
chmod 600 "$DIR/config.local.js"

# ── 빈 포트 찾아서 서버 띄우기 (캐시 없이) ──────────────────
PORT="$(python3 - <<'PY'
import socket
for p in range(8040, 8100):
    s = socket.socket()
    try:
        s.bind(("127.0.0.1", p)); print(p); break
    except OSError:
        pass
    finally:
        s.close()
PY
)"
python3 - "$PORT" "$DIR" >/dev/null 2>&1 <<'PY' &
import sys, functools, http.server
class NoCache(http.server.SimpleHTTPRequestHandler):
    def end_headers(self):
        self.send_header("Cache-Control", "no-store")
        super().end_headers()
handler = functools.partial(NoCache, directory=sys.argv[2])
http.server.ThreadingHTTPServer(("127.0.0.1", int(sys.argv[1])), handler).serve_forever()
PY
SERVER=$!
trap 'kill $SERVER 2>/dev/null; echo; echo "도리 종료"' EXIT INT TERM
sleep 0.5

URL="http://localhost:$PORT/"
echo "도리 실행 중: $URL"
echo "종료하려면 Ctrl+C"

# ── 브라우저 열기 (전체 화면, 클릭 없이 소리 나게) ──────────
FLAGS=(--app="$URL" --start-fullscreen --autoplay-policy=no-user-gesture-required --user-data-dir="$DIR/.chrome")
if [ "$(uname)" = "Darwin" ]; then
  if [ -d "/Applications/Google Chrome.app" ]; then
    open -na "Google Chrome" --args "${FLAGS[@]}"
  else
    echo "Chrome 이 없어서 기본 브라우저로 엽니다. 소리가 안 나면 화면을 한 번 클릭하세요."
    open "$URL"
  fi
else
  # 라즈베리 파이 / 리눅스
  BROWSER=""
  for b in chromium-browser chromium google-chrome; do
    command -v "$b" >/dev/null 2>&1 && { BROWSER="$b"; break; }
  done
  if [ -n "$BROWSER" ]; then
    "$BROWSER" --kiosk "${FLAGS[@]}" >/dev/null 2>&1 &
  else
    echo "브라우저를 직접 열어 주세요: $URL"
  fi
fi

wait $SERVER
