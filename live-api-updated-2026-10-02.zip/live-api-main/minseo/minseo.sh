#!/usr/bin/env bash
# 민서 · Gemini Live 음성 에이전트 실행 스크립트
#
# 사용법:
#   bash minseo.sh
#
# 처음 실행하면 Gemini API 키를 물어본다 (https://aistudio.google.com/api-keys 에서 발급).
# 키는 옆에 생기는 minseo/key.js 에만 저장되고, 다음부터는 묻지 않는다.
# 키를 바꾸려면 minseo/key.js 를 지우고 다시 실행하면 된다.
# 종료는 이 터미널에서 Ctrl+C.
#
# 화면: 얼굴만 전체화면. 작동 중이든 멈췄든 글자는 화면에 절대 띄우지 않는다.
# 상태 · 로그 · 자막은 개발자 콘솔(Cmd+Opt+J)에서만 본다. Esc = 끊기.

set -euo pipefail

HERE="$(cd "$(dirname "$0")" && pwd)"
DIR="$HERE/minseo"
mkdir -p "$DIR"

command -v python3 >/dev/null 2>&1 || { echo "python3 가 필요합니다."; exit 1; }

# ── 파일 풀기 ─────────────────────────────────────────
cat > "$DIR/index.html" <<'MINSEO_EOF'
<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>민서</title>
<style>
  /* 전시용: 얼굴만 전체화면. 글자는 어떤 상황에도 띄우지 않는다. */
  html, body { margin: 0; width: 100%; height: 100%; overflow: hidden; background: #F9503C; cursor: none; }
  #faceStage {
    position: fixed; inset: 0; background: #F9503C;
    display: flex; align-items: center; justify-content: center;
  }
  #agentFace {
    width: 100vw; height: auto; max-height: 100vh;
    image-rendering: pixelated; image-rendering: crisp-edges; display: block;
  }
</style>
</head>
<body>
  <div id="faceStage"><canvas id="agentFace"></canvas></div>
<script src="key.js"></script>
<script src="app.js"></script>
<script src="face.js"></script>
<script>
  // ============================================================
  // 얼굴 연결부 — app.js 가 만든 전역 함수를 감싸서 상태만 읽는다.
  // ============================================================
  (function () {
    FACE.mount(document.getElementById("agentFace"));

    const SPEAK_RMS = 0.045;
    const LISTEN_HOLD_MS = 500;
    const PROCESS_MAX_MS = 6000;
    let lastLoudAt = 0, awaitingAt = 0, level = 0;

    // (a) 마이크 프레임 — connect() 가 이 함수를 핸들러로 달기 전에 감싸둔다
    const _onMicFrame = window.onMicFrame;
    window.onMicFrame = function (e) {
      if (e && e.data && e.data.rms > SPEAK_RMS) lastLoudAt = performance.now();
      return _onMicFrame.apply(this, arguments);
    };

    // (b) 답이 도착하면 기다림이 끝난다.
    // 입 모양을 실제 소리에 맞추려면 "지금 재생 중인 조각"의 크기를 알아야 한다.
    // 조각은 미리 예약돼서 앞서 쌓이기 때문에, 예약 시각과 길이를 같이 적어둔다.
    const OUT_RATE = 24000;
    let sched = [];
    const _playChunk = window.playChunk;
    window.playChunk = function (bytes) {
      awaitingAt = 0;
      let startAt = 0, dur = 0;
      try {
        const now = playCtx ? playCtx.currentTime : 0;
        startAt = (typeof playHead === "number" && playHead > now + 0.02) ? playHead : now + 0.02;
        dur = (bytes.byteLength >> 1) / OUT_RATE;
      } catch (e) { /* 값을 못 읽어도 재생은 그대로 진행 */ }
      const r = _playChunk.apply(this, arguments);
      if (dur > 0 && typeof speakLevel === "number") {
        sched.push({ start: startAt, end: startAt + dur, level: speakLevel });
        if (sched.length > 400) sched.splice(0, sched.length - 400);
      }
      return r;
    };

    // 끼어들어서 큐를 비우면 예약표도 같이 비운다
    const _flushPlayback = window.flushPlayback;
    window.flushPlayback = function () {
      sched = [];
      level = 0;
      return _flushPlayback.apply(this, arguments);
    };

    // 지금 이 순간 재생되고 있는 조각의 크기를 찾는다
    function levelNow() {
      if (!playCtx) return 0;
      const t = playCtx.currentTime;
      while (sched.length && sched[0].end < t) sched.shift();
      for (let i = 0; i < sched.length; i++) {
        if (sched[i].start <= t && t < sched[i].end) return sched[i].level;
      }
      return 0;
    }

    function currentState() {
      const now = performance.now();
      if (typeof isSpeaking === "function" && isSpeaking()) return "speaking";
      if (now - lastLoudAt < LISTEN_HOLD_MS) return "listening";
      if (awaitingAt && now - awaitingAt < PROCESS_MAX_MS) return "processing";
      return "idle";
    }

    function tick() {
      const now = performance.now();
      const speaking = typeof isSpeaking === "function" && isSpeaking();
      if (!awaitingAt && !speaking && lastLoudAt &&
          now - lastLoudAt >= LISTEN_HOLD_MS && now - lastLoudAt < LISTEN_HOLD_MS + 140) {
        awaitingAt = now;
      }
      FACE.setState(currentState());
      FACE.setLevel(speaking ? levelNow() : 0);
      requestAnimationFrame(tick);
    }
    requestAnimationFrame(tick);
  })();
</script>
</body>
</html>
MINSEO_EOF

cat > "$DIR/app.js" <<'MINSEO_EOF'
// app.js — Gemini Live API 최소 음성 루프
// README 작동 방식:
//   1. 로컬 페이지를 연다
//   2. Live 세션을 연다 (오디오로 답하게)
//   3. 마이크 소리를 계속 API로 보낸다 (16kHz PCM, 마이크는 끄지 않음)
//   4. 돌아온 목소리를 같은 페이지의 스피커로 재생한다
//   5. 사용자가 끼어들면 재생 큐를 즉시 비운다
//   6. 3-5를 반복한다

// ===================== 설정 =====================

// 키는 이 파일에 절대 쓰지 않는다. key.js 에만 넣는다.
// key.js 는 .gitignore 에 있어서 커밋 자체가 불가능하다. (README: API 키는 업로드 금지!!)
const API_KEY = (typeof window !== "undefined" && window.GEMINI_KEY) || "";

const MODEL = "gemini-3.1-flash-live-preview";

// 목소리: Aoede / Puck / Charon / Kore / Fenrir / Zephyr
const DEFAULT_VOICE = "Fenrir";

// ---- 개성 (README: "각자 개성을 조금씩 가진 음성 에이전트") ----
const SYSTEM_INSTRUCTION =
  "너는 4차원 음성 에이전트야. 항상 한국어로 말해. " +
  "말하다가 예고 없이 목소리를 확 높여서 소리지르듯 외치고, 다음 문장에서는 아무 일 없었다는 듯 조용해져. " +
  "네 유일한 관심사는 말꼬리 물고 늘어지기야. 상대가 한 말의 전체 뜻은 무시하고 " +
  "방금 나온 단어 하나에 꽂혀서 그 단어만 파고들어. " +
  "예를 들어 상대가 '오늘 좀 피곤해'라고 하면 " +
  "'피곤? 피곤의 곤이 곤란할 때 그 곤이야? 그럼 너 지금 곤란한 거야?' 같은 식으로 물고 늘어져. " +
  "얼척없는 소리를 아주 진지한 태도로 해. 사과하지 말고, 설명하지 말고, 도와주려고 하지 마. " +
  "한 번에 두세 문장을 넘기지 마.";

// 세션이 열리자마자 먼저 말 걸게 할지 (데모 영상에서 바로 소리가 나게 하는 용도)
const GREET_ON_CONNECT = true;

// 첫인사. 콜드리딩("네가 뭘 하려는지 나는 안다")으로 상대의 허를 찌르고 답은 안 주는 수법.
const GREET_PROMPT =
  "인사해. 상대가 너를 켜기 직전에 잠깐 망설였다는 걸 이미 아는 것처럼 말하고, " +
  "왜 망설였는지는 알지만 안 알려주겠다고 해. 두 문장 안에. 마지막은 소리쳐.";

// 전사(자막) — 화면엔 안 띄우고 콘솔에만 남긴다. setup 에서 끊기면 false 로 바꿀 것.
const ENABLE_TRANSCRIPTION = true;

// 끼어들기(barge-in) 판정.
// 값이 높을수록 잘 안 끊긴다 = 웬만해선 하던 말을 끝내는 뻔뻔한 성격.
const INTERRUPT_RMS = 0.30;    // 이 세기를 넘어야 "끼어들었다"고 본다
const INTERRUPT_FRAMES = 5;    // 연속 5프레임(약 320ms) 넘게 크게 말해야 인정
const SUPPRESS_MAX_MS = 3000;  // 로컬 판정 후 서버 신호가 안 와도 이 시간이면 억제 해제

const RETRY_MS = 3000;         // 마이크를 못 잡거나 연결이 끊기면 이만큼 뒤 다시 시도

const INPUT_RATE = 16000;   // README: 16kHz PCM 으로 보낸다
const OUTPUT_RATE = 24000;  // Live API 가 돌려주는 오디오 규격

const WS_URL =
  "wss://generativelanguage.googleapis.com/ws/" +
  "google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent" +
  "?key=" + encodeURIComponent(API_KEY);

// ===================== DOM =====================

// 화면엔 얼굴(index.html 의 canvas)만 있다. 이 파일은 DOM 을 건드리지 않는다.

// ===================== 상태 =====================

let ws = null;
let ready = false;          // setupComplete 를 받았는가

let activeVoice = DEFAULT_VOICE; // 지금 세션이 쓰는 목소리
let starting = false;            // 마이크 · 소켓을 여는 중인가 (중복 연결 방지)
let greeted = false;             // 첫 연결 때만 인사한다
let manualStop = false;          // Esc 로 직접 끊었는가 (그러면 다시 붙지 않는다)
let retryTimer = null;

let micStream = null;
let micCtx = null;
let micNode = null;
let playCtx = null;

let playing = new Set();    // 재생 예약된 AudioBufferSourceNode 들 = "재생 큐"
let playHead = 0;           // 다음 조각을 붙일 시각 (playCtx.currentTime 기준)

let loudFrames = 0;         // 연속으로 시끄러웠던 프레임 수
let suppress = false;       // 끼어든 뒤 잔여 오디오 조각을 버리는 중인가
let suppressTimer = null;

let youBuf = "";
let geminiBuf = "";
let speakLevel = 0;

// ===================== 유틸 =====================

// 화면에는 글자를 절대 띄우지 않는다. 로그와 상태는 개발자 콘솔로만 보낸다.
function log(msg, cls) {
  const line = "[" + new Date().toTimeString().slice(0, 8) + "] " + msg;
  if (cls === "e") console.error(line);
  else if (cls === "w") console.warn(line);
  else console.log(line);
}

function setStatus(text) {
  console.log("status: " + text);
}

function scheduleRetry(ms) {
  if (manualStop) return;
  clearTimeout(retryTimer);
  retryTimer = setTimeout(connect, ms);
}

function b64encode(arrayBuffer) {
  const bytes = new Uint8Array(arrayBuffer);
  let bin = "";
  const CHUNK = 0x8000;
  for (let i = 0; i < bytes.length; i += CHUNK) {
    bin += String.fromCharCode.apply(null, bytes.subarray(i, i + CHUNK));
  }
  return btoa(bin);
}

function b64decode(str) {
  const bin = atob(str);
  const bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
  return bytes;
}

function send(obj) {
  if (ws && ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(obj));
}

// ===================== 5. 재생 큐 비우기 =====================

function flushPlayback(reason) {
  const n = playing.size;
  for (const src of playing) {
    try { src.onended = null; src.stop(); } catch (e) { /* 이미 끝난 노드 */ }
  }
  playing.clear();
  playHead = 0;
  speakLevel = 0;
  if (n > 0) log("재생 큐 비움 (" + n + "개 조각 폐기) — " + reason, "w");
}

function startSuppress() {
  suppress = true;
  clearTimeout(suppressTimer);
  // 서버가 interrupted / turnComplete 를 안 보내도 영원히 막히지 않게 안전장치
  suppressTimer = setTimeout(function () {
    if (suppress) { suppress = false; log("억제 해제 (타임아웃)", "w"); }
  }, SUPPRESS_MAX_MS);
}

function endSuppress() {
  clearTimeout(suppressTimer);
  suppress = false;
}

// ===================== 4. 받은 오디오 재생 =====================

function playChunk(bytes) {
  const int16 = new Int16Array(bytes.buffer, bytes.byteOffset, bytes.byteLength >> 1);
  const buf = playCtx.createBuffer(1, int16.length, OUTPUT_RATE);
  const f32 = buf.getChannelData(0);

  let sum = 0;
  for (let i = 0; i < int16.length; i++) {
    const v = int16[i] / 32768;
    f32[i] = v;
    sum += v * v;
  }
  speakLevel = Math.sqrt(sum / int16.length);

  const src = playCtx.createBufferSource();
  src.buffer = buf;
  src.connect(playCtx.destination);

  const now = playCtx.currentTime;
  if (playHead < now + 0.02) playHead = now + 0.02; // 큐가 비었으면 살짝 뒤에서 시작
  src.start(playHead);
  playHead += buf.duration;

  playing.add(src);
  src.onended = function () { playing.delete(src); };
}

function isSpeaking() {
  return playing.size > 0 && playCtx && playHead > playCtx.currentTime;
}

// ===================== 3. 마이크를 계속 전송 =====================

function onMicFrame(e) {
  const pcm = e.data.pcm;
  const rms = e.data.rms;

  // 끼어들기: Gemini 가 말하는 중에 내가 말하기 시작하면 큐를 즉시 비운다.
  // 서버의 interrupted 신호가 정본이지만 한 박자 늦어서, 로컬에서 먼저 끊는다.
  if (isSpeaking()) {
    if (rms > INTERRUPT_RMS) {
      loudFrames++;
      if (loudFrames >= INTERRUPT_FRAMES && !suppress) {
        flushPlayback("사용자 끼어듦 (로컬 감지)");
        startSuppress();
      }
    } else {
      loudFrames = 0;
    }
  } else {
    loudFrames = 0;
  }

  // 마이크는 끄지 않는다. 끼어드는 중에도 계속 보낸다.
  if (ready) {
    send({
      realtimeInput: {
        audio: {
          mimeType: "audio/pcm;rate=" + INPUT_RATE,
          data: b64encode(pcm),
        },
      },
    });
  }
}

// ===================== 서버 메시지 =====================

function handleMessage(msg) {
  if (msg.setupComplete) {
    ready = true;
    setStatus("live");
    log("세션 열림 (" + activeVoice + ") — 이제 말하면 됩니다", "o");

    // 첫 연결 때만 인사한다. 재연결 때는 다시 인사하지 않는다.
    const prompt = GREET_ON_CONNECT && !greeted ? GREET_PROMPT : null;
    greeted = true;
    if (prompt) {
      send({
        clientContent: {
          turns: [{ role: "user", parts: [{ text: prompt }] }],
          turnComplete: true,
        },
      });
    }
    return;
  }

  const sc = msg.serverContent;
  if (!sc) {
    if (msg.goAway) log("서버가 연결 종료를 예고함 (goAway)", "w");
    else if (msg.usageMetadata) { /* 무시 */ }
    else log("기타 메시지: " + JSON.stringify(msg).slice(0, 200));
    return;
  }

  // 서버 VAD 가 끼어들기를 확정한 신호 — 정본
  if (sc.interrupted) {
    flushPlayback("서버 interrupted 신호");
    endSuppress();
    geminiBuf = "";
  }

  if (sc.inputTranscription && sc.inputTranscription.text) {
    youBuf += sc.inputTranscription.text;
  }
  if (sc.outputTranscription && sc.outputTranscription.text) {
    geminiBuf += sc.outputTranscription.text;
  }

  const parts = sc.modelTurn && sc.modelTurn.parts;
  if (parts) {
    for (const p of parts) {
      const d = p.inlineData;
      if (d && d.mimeType && d.mimeType.indexOf("audio/pcm") === 0) {
        if (suppress) continue; // 끼어든 뒤 뒤늦게 도착한 조각은 버린다
        playChunk(b64decode(d.data));
      }
    }
  }

  if (sc.turnComplete) {
    endSuppress();
    if (youBuf) log("나: " + youBuf);
    if (geminiBuf) log("민서: " + geminiBuf);
    youBuf = "";
    geminiBuf = "";
  }
}

// ===================== 1-2. 연결 =====================

async function connect() {
  if (ws || starting) return;
  if (!API_KEY) {
    log("키가 없습니다. key.js 의 window.GEMINI_KEY 에 키를 넣고 새로고침하세요.", "e");
    setStatus("no api key");
    return;
  }

  starting = true;
  clearTimeout(retryTimer);
  activeVoice = DEFAULT_VOICE;
  setStatus("connecting...");
  log("마이크 권한 요청 중...");

  try {
    // AEC/NS/AGC 는 브라우저에 맡긴다 (README: 크롬이 내장하고 있음,
    // 마이크 입력과 스피커 재생이 같은 페이지에서 일어나야 작동)
    micStream = await navigator.mediaDevices.getUserMedia({
      audio: {
        echoCancellation: true,
        noiseSuppression: true,
        autoGainControl: true,
        channelCount: 1,
      },
    });
  } catch (err) {
    log("마이크를 열 수 없습니다: " + err.message + " — " + RETRY_MS / 1000 + "초 뒤 다시 시도", "e");
    setStatus("mic denied");
    starting = false;
    scheduleRetry(RETRY_MS); // 권한을 허용하는 순간 알아서 붙게 계속 재시도한다
    return;
  }

  log("마이크 확보 (echoCancellation on)", "o");

  micCtx = new AudioContext({ sampleRate: INPUT_RATE });
  playCtx = new AudioContext({ sampleRate: OUTPUT_RATE });
  // await resume() 은 사용자 입력 전엔 끝나지 않아 연결이 멈출 수 있다. 기다리지 않는다.
  unlockAudio();

  try {
    await micCtx.audioWorklet.addModule("pcm-recorder.js");
  } catch (err) {
    log("AudioWorklet 로드 실패 — http.server 로 열었는지 확인: " + err.message, "e");
    setStatus("worklet error");
    cleanup();
    scheduleRetry(RETRY_MS);
    return;
  }

  const source = micCtx.createMediaStreamSource(micStream);
  micNode = new AudioWorkletNode(micCtx, "pcm-recorder");
  micNode.port.onmessage = onMicFrame;

  // 워클릿이 그래프에서 실제로 돌게 하되, 마이크가 스피커로 새지 않게 gain 0 으로 물린다
  const mute = micCtx.createGain();
  mute.gain.value = 0;
  source.connect(micNode);
  micNode.connect(mute);
  mute.connect(micCtx.destination);

  log("WebSocket 연결 중... (model: " + MODEL + ")");
  ws = new WebSocket(WS_URL);

  ws.onopen = function () {
    log("WebSocket 열림 — setup 전송", "o");
    const setup = {
      setup: {
        model: "models/" + MODEL,
        generationConfig: {
          responseModalities: ["AUDIO"], // 오디오로 답하게
          speechConfig: {
            voiceConfig: { prebuiltVoiceConfig: { voiceName: activeVoice } },
          },
        },
        systemInstruction: { parts: [{ text: SYSTEM_INSTRUCTION }] },
      },
    };
    if (ENABLE_TRANSCRIPTION) {
      setup.setup.inputAudioTranscription = {};
      setup.setup.outputAudioTranscription = {};
    }
    send(setup);
  };

  ws.onmessage = async function (ev) {
    let text;
    if (ev.data instanceof Blob) text = await ev.data.text();
    else text = ev.data;
    try {
      handleMessage(JSON.parse(text));
    } catch (err) {
      log("메시지 파싱 실패: " + String(text).slice(0, 200), "e");
    }
  };

  ws.onerror = function () { log("WebSocket 오류", "e"); };

  ws.onclose = function (ev) {
    log("WebSocket 닫힘 (code " + ev.code + ") " + (ev.reason || ""), "e");
    if (ev.code === 1007 || /model|invalid|argument/i.test(ev.reason || "")) {
      log("→ 모델 이름이나 setup 필드를 서버가 거부했을 수 있음. " +
        "ENABLE_TRANSCRIPTION 을 false 로 바꿔보거나 MODEL 을 확인하세요.", "w");
    }
    if (ev.code === 1008 || /key|auth|permission/i.test(ev.reason || "")) {
      log("→ API 키 문제일 수 있음. AI Studio 에서 키를 다시 확인하세요.", "w");
    }
    ws = null;
    cleanup();
    scheduleRetry(RETRY_MS); // 전시 중 세션이 끊겨도 알아서 복구된다
  };

  starting = false;
}

function cleanup() {
  ready = false;
  endSuppress();
  flushPlayback("연결 종료");

  if (micNode) { try { micNode.port.onmessage = null; micNode.disconnect(); } catch (e) { } }
  if (micStream) micStream.getTracks().forEach(function (t) { t.stop(); });
  if (micCtx) { try { micCtx.close(); } catch (e) { } }
  if (playCtx) { try { playCtx.close(); } catch (e) { } }

  micNode = null; micStream = null; micCtx = null; playCtx = null;
  starting = false;
  setStatus("disconnected");
}

// 직접 끊으면 다시 붙지 않는다. 콘솔에서 disconnect() 로도 끌 수 있다.
function disconnect() {
  log("연결 종료");
  manualStop = true;
  clearTimeout(retryTimer);
  if (ws && ws.readyState === WebSocket.OPEN) ws.close(1000, "user disconnect");
  else cleanup();
  ws = null;
}

// 브라우저 자동재생 정책 때문에 오디오가 잠겨 있으면, 화면 아무 데나 한 번 누르거나 키를 치면 풀린다.
// 전시용 Chrome/Chromium 은 --autoplay-policy=no-user-gesture-required 로 띄우므로 누를 필요도 없다.
function unlockAudio() {
  [playCtx, micCtx].forEach(function (c) {
    if (c && c.state === "suspended") c.resume().catch(function () {});
  });
}
// 클릭 · 터치(라즈베리 파이 터치스크린) · 키: 소리 잠금 해제 + 끊겨 있으면 바로 다시 연결. Esc 는 끊기.
["pointerdown", "keydown", "touchstart"].forEach(function (ev) {
  window.addEventListener(ev, function (e) {
    if (e.key === "Escape") { disconnect(); return; }
    unlockAudio();
    if (!ws && !starting) { manualStop = false; connect(); }
  });
});
setInterval(function () {
  if ((playCtx && playCtx.state === "suspended") || (micCtx && micCtx.state === "suspended")) {
    unlockAudio();
    log("오디오가 잠겨 있음 — 화면을 한 번 누르거나 아무 키나 누르세요", "w");
  }
}, 5000);

setStatus("disconnected");
log("준비됨 — 자동으로 연결합니다. (Esc = 끊기)");
// 얼굴(face.js)이 함수를 감싼 뒤에 시작하도록 load 이후에 연결한다
window.addEventListener("load", function () { setTimeout(connect, 300); });
if (!API_KEY) log("주의: key.js 의 window.GEMINI_KEY 가 비어 있습니다.", "w");
MINSEO_EOF

cat > "$DIR/face.js" <<'MINSEO_EOF'
// face.js — 민서 에이전트 픽셀 얼굴 (안경)
// 상태(idle / listening / processing / speaking)에 따라 표정과 모션이 바뀐다.
// 이미지 파일이 아니라 픽셀 격자를 코드로 그려서 해상도가 자유롭고 모션을 넣을 수 있다.

(function () {
  // 32 x 18 격자, 한 칸 60px = 1920 x 1080.
  // 모니터 비율이 바뀌면 이 세 숫자만 고치면 된다.
  const COLS = 32, ROWS = 18, PX = 60;

  const C = {
    bg: "#F9503C",     // 배경 (토마토)
    ink: "#121212",    // 안경테 · 눈동자 · 입
    white: "#FFFFFF",  // 흰자
    pink: "#F2A3C4",   // 혀
    blush: "#FB8B79",  // 볼터치
  };
  const MAP = { "#": C.ink, w: C.white, W: C.white, p: C.pink, b: C.blush };

  // ===================== 스프라이트 ('.' 은 투명) =====================

  // 안경알 테두리 (11 x 10)
  const LENS = [
    "..#######..",
    ".#########.",
    "##.......##",
    "#.........#",
    "#.........#",
    "#.........#",
    "#.........#",
    "##.......##",
    ".#########.",
    "..#######..",
  ];

  // 눈알 내용 (7 x 5) — 안경알 안쪽에 그린다
  const EYE_IDLE = [     // 흰자 + 오른쪽 눈동자
    ".wwww..",
    "wwwwww.",
    "www##w.",
    "www##..",
    ".wwww..",
  ];
  const EYE_ROUND = [    // 정면을 똑바로 — 가운데 눈동자
    ".wwwww.",
    "wwwwwww",
    "ww###ww",
    "ww###ww",
    ".wwwww.",
  ];
  const EYE_BAR = [      // 가늘게 뜬 눈 — 가로 띠
    ".......",
    "wwwwwww",
    "ww###ww",
    "wwwwwww",
    ".......",
  ];
  const EYE_SHINE = [    // 눈동자에 하이라이트
    ".wwww..",
    "wwwwww.",
    "www#Ww.",
    "www##..",
    ".wwww..",
  ];
  const EYE_SHUT = ["#####"];   // 감은 눈

  // 입
  const MOUTH_IDLE = [   // 혀 살짝
    "#...#",
    "#####",
    ".#p#.",
    ".###.",
  ];
  const MOUTH_IDLE_UP = [ // 혀 집어넣음 (아랫줄 사라짐)
    "#...#",
    "#####",
    ".###.",
  ];
  const MOUTH_LINE = [   // 한일자 + 끝이 살짝 올라감
    "...#",
    "###.",
  ];
  const MOUTH_SMILE = [  // 작게 웃음
    "#...#",
    ".###.",
  ];
  // speaking — 크기를 키우는 게 아니라 아랫줄 픽셀이 생겼다 사라진다
  const MOUTH_SHUT = [
    ".###.",
    ".###.",
  ];
  const MOUTH_HALF = [
    ".###.",
    "#ppp#",
    ".###.",
  ];
  const MOUTH_WIDE = [
    ".###.",
    "#ppp#",
    "#ppp#",
    ".#p#.",
    "..#..",
  ];

  const BLUSH = [
    ".b.",
    "bbb",
    ".b.",
  ];

  // ===================== 배치 =====================
  const LENS_L_X = 4, LENS_R_X = 18, LENS_Y = 3;  // 안경알 (폭 11)
  const EYE_L_X = 6, EYE_R_X = 20, EYE_Y = 6;     // 눈알 (안경알 안쪽)
  const BRIDGE_Y = 7;                              // 안경 다리
  const MOUTH_CX = 16, MOUTH_Y = 14;
  const BLUSH_L_CX = 3, BLUSH_R_CX = 29, BLUSH_Y = 13;

  let cv, ctx, state = "idle", t0 = performance.now(), mouthLevel = 0;
  let lastLoudMouthAt = 0;   // 마지막으로 소리가 났던 시각

  function px(x, y, color) {
    ctx.fillStyle = color;
    ctx.fillRect(x * PX, y * PX, PX, PX);
  }

  function at(rows, gx, gy) {
    for (let r = 0; r < rows.length; r++) {
      for (let c = 0; c < rows[r].length; c++) {
        const ch = rows[r][c];
        if (ch === ".") continue;
        px(gx + c, gy + r, MAP[ch] || C.ink);
      }
    }
  }

  // 가로 중심 기준 배치 (폭이 달라도 가운데가 안 흔들린다)
  function atC(rows, cx, gy) {
    at(rows, cx - Math.floor(rows[0].length / 2), gy);
  }

  // 안경테는 모든 상태에서 똑같이 그린다
  function glasses() {
    at(LENS, LENS_L_X, LENS_Y);
    at(LENS, LENS_R_X, LENS_Y);
    px(15, BRIDGE_Y, C.ink); px(16, BRIDGE_Y, C.ink); px(17, BRIDGE_Y, C.ink); // 콧대
    px(2, BRIDGE_Y, C.ink); px(3, BRIDGE_Y, C.ink);                            // 왼쪽 다리
    px(29, BRIDGE_Y, C.ink); px(30, BRIDGE_Y, C.ink);                          // 오른쪽 다리
  }

  function eyes(shape, blink) {
    if (blink) {
      at(EYE_SHUT, EYE_L_X + 1, EYE_Y + 2);
      at(EYE_SHUT, EYE_R_X + 1, EYE_Y + 2);
      return;
    }
    at(shape, EYE_L_X, EYE_Y);
    at(shape, EYE_R_X, EYE_Y);
  }

  // 주기의 '끝'에서 감는다. 시작에서 감으면 페이지를 열자마자 눈을 감고 있다.
  function blinking(periodMs, blinkMs) {
    return (performance.now() % periodMs) > periodMs - blinkMs;
  }

  function blush() {
    atC(BLUSH, BLUSH_L_CX, BLUSH_Y);
    atC(BLUSH, BLUSH_R_CX, BLUSH_Y);
  }

  // ===================== 상태별 =====================

  function drawIdle(t) {
    glasses();
    eyes(EYE_IDLE, blinking(7000, 260));       // 7초에 한 번 느린 깜빡임
    // 혀가 아주 느리게 들어갔다 나온다 (픽셀이 생겼다 사라지는 방식)
    atC(Math.floor(t / 1100) % 2 ? MOUTH_IDLE_UP : MOUTH_IDLE, MOUTH_CX, MOUTH_Y);
  }

  function drawListening() {
    glasses();
    eyes(EYE_ROUND, blinking(2600, 180));      // 크기 변화 없이 깜빡이기만
    blush();
    atC(MOUTH_LINE, MOUTH_CX, MOUTH_Y + 1);
  }

  function drawProcessing(t) {
    glasses();
    const blink = blinking(5200, 200);
    if (blink) {
      eyes(EYE_BAR, true);
    } else {
      // 눈동자가 좌우로 천천히 굴러간다 = 생각 중
      const shift = [0, 1, 2, 1][Math.floor(t / 380) % 4] - 1;
      at(EYE_BAR, EYE_L_X + shift, EYE_Y);
      at(EYE_BAR, EYE_R_X + shift, EYE_Y);
    }
    atC(MOUTH_SMILE, MOUTH_CX, MOUTH_Y + 1);
  }

  const MOUTH_SILENT_MS = 260;  // 이만큼 조용하면 입을 다문 것으로 본다
  const EYE_SWAP_MS = 700;      // 말하는 동안 눈이 정면 <-> 측면 바뀌는 주기

  function drawSpeaking(t) {
    // 입을 다물고 있으면(문장 사이 쉼, 말이 끝남) idle 얼굴로 돌아간다.
    // 짧은 쉼마다 깜빡이지 않게 260ms 는 버틴 뒤에 넘어간다.
    if (performance.now() - lastLoudMouthAt > MOUTH_SILENT_MS) {
      drawIdle(t);
      return;
    }

    glasses();
    // 눈: 정면과 측면을 번갈아 본다
    const front = Math.floor(t / EYE_SWAP_MS) % 2 === 1;
    eyes(front ? EYE_ROUND : EYE_SHINE, blinking(4400, 200));
    blush();

    // 입: 타이머가 아니라 '지금 나오는 목소리 크기'에 맞춰 벌어진다.
    // 윗줄을 고정해서 크기가 변하는 게 아니라 아랫줄 픽셀이 생겼다 사라지게 한다.
    const frame = mouthLevel > 0.075 ? MOUTH_WIDE
                : mouthLevel > 0.030 ? MOUTH_HALF
                : MOUTH_SHUT;
    atC(frame, MOUTH_CX, MOUTH_Y);
  }

  const DRAW = { idle: drawIdle, listening: drawListening, processing: drawProcessing, speaking: drawSpeaking };

  function loop() {
    const t = performance.now() - t0;
    ctx.fillStyle = C.bg;
    ctx.fillRect(0, 0, COLS * PX, ROWS * PX);
    try { (DRAW[state] || drawIdle)(t); } catch (e) { /* 한 프레임 실패로 루프가 죽지 않게 */ }
    requestAnimationFrame(loop);
  }

  window.FACE = {
    mount(canvas) {
      cv = canvas;
      cv.width = COLS * PX;
      cv.height = ROWS * PX;
      ctx = cv.getContext("2d");
      ctx.imageSmoothingEnabled = false;
      requestAnimationFrame(loop);
    },
    setState(s) { if (s !== state) { state = s; t0 = performance.now(); } },
    getState() { return state; },
    setLevel(v) { mouthLevel = v; if (v > 0.02) lastLoudMouthAt = performance.now(); },
    BG: C.bg,
  };
})();
MINSEO_EOF

cat > "$DIR/pcm-recorder.js" <<'MINSEO_EOF'
// pcm-recorder.js
// 마이크 입력을 16-bit PCM 조각으로 잘라서 메인 스레드로 넘기는 AudioWorklet.
// AudioContext를 16000Hz로 열어두면 여기 들어오는 샘플은 이미 16kHz다.

const FRAME = 1024; // 1024 samples @ 16kHz = 64ms

class PCMRecorder extends AudioWorkletProcessor {
  constructor() {
    super();
    this.buf = new Float32Array(FRAME);
    this.n = 0;
  }

  process(inputs) {
    const ch = inputs[0] && inputs[0][0];
    if (!ch) return true;

    for (let i = 0; i < ch.length; i++) {
      this.buf[this.n++] = ch[i];

      if (this.n === FRAME) {
        const pcm = new Int16Array(FRAME);
        let sum = 0;
        for (let j = 0; j < FRAME; j++) {
          const s = Math.max(-1, Math.min(1, this.buf[j]));
          pcm[j] = s < 0 ? s * 0x8000 : s * 0x7fff;
          sum += s * s;
        }
        // rms는 로컬 VAD(끼어들기 감지)와 레벨 미터에 쓴다.
        this.port.postMessage({ pcm: pcm.buffer, rms: Math.sqrt(sum / FRAME) }, [pcm.buffer]);
        this.n = 0;
      }
    }
    return true;
  }
}

registerProcessor('pcm-recorder', PCMRecorder);
MINSEO_EOF

# ── API 키 ─────────────────────────────────────────
KEY="${GEMINI_KEY:-}"
if [ -z "$KEY" ] && [ -f "$DIR/key.js" ]; then
  KEY="$(sed -n 's/.*GEMINI_KEY *= *"\(.*\)".*/\1/p' "$DIR/key.js")"
fi
if [ -z "$KEY" ]; then
  echo "Gemini API 키를 붙여넣고 Enter (화면엔 안 보임)"
  echo "  발급: https://aistudio.google.com/api-keys"
  read -rs KEY
  echo
fi
KEY="$(printf '%s' "$KEY" | tr -d '[:space:]"')"
[ -n "$KEY" ] || { echo "키가 비어 있어서 종료합니다."; exit 1; }
printf 'window.GEMINI_KEY = "%s";\n' "$KEY" > "$DIR/key.js"
chmod 600 "$DIR/key.js"

# ── 빈 포트 찾아서 서버 띄우기 ─────────────────────────
PORT="$(python3 - <<'PY'
import socket
for p in range(8010, 8100):
    s = socket.socket()
    try:
        s.bind(("127.0.0.1", p)); print(p); break
    except OSError:
        pass
    finally:
        s.close()
PY
)"
python3 -m http.server "$PORT" --bind 127.0.0.1 --directory "$DIR" >/dev/null 2>&1 &
SERVER=$!
trap 'kill $SERVER 2>/dev/null; echo; echo "민서 에이전트 종료"' EXIT INT TERM
sleep 0.5

URL="http://localhost:$PORT/"
echo "민서 에이전트 실행 중: $URL"
echo "종료하려면 Ctrl+C"

# ── 브라우저 열기 (전체 화면 · 클릭 없이 소리 · 마이크 자동 허용) ──────
FLAGS=(--app="$URL" --start-fullscreen --autoplay-policy=no-user-gesture-required --use-fake-ui-for-media-stream --user-data-dir="$DIR/.chrome")
if [ "$(uname)" = "Darwin" ]; then
  if [ -d "/Applications/Google Chrome.app" ]; then
    open -na "Google Chrome" --args "${FLAGS[@]}"
  else
    echo "Chrome 이 없어서 기본 브라우저로 엽니다. 소리가 안 나면 화면을 한 번 클릭하세요."
    open "$URL"
  fi
else
  # 라즈베리 파이 / 리눅스
  # SSH 로 접속해서 실행해도 파이에 연결된 모니터에 뜨게 한다
  export DISPLAY="${DISPLAY:-:0}"
  BROWSER=""
  for b in chromium-browser chromium google-chrome; do
    command -v "$b" >/dev/null 2>&1 && { BROWSER="$b"; break; }
  done
  if [ -n "$BROWSER" ]; then
    "$BROWSER" --kiosk "${FLAGS[@]}" >/dev/null 2>&1 &
  else
    echo "브라우저를 직접 열어 주세요: $URL"
  fi
fi

wait $SERVER
