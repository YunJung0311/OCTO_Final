#!/usr/bin/env bash
# 헐 — Gemini Live 음성 에이전트 실행 스크립트 (minjeong)
#
# 사용법:
#   bash minjeong.sh
#
# 처음 실행하면 Gemini API 키를 물어본다 (https://aistudio.google.com/api-keys 에서 발급).
# 키는 옆에 생기는 minjeong/config.local.js 에만 저장되고, 다음부터는 묻지 않는다.
# 키를 바꾸려면 minjeong/config.local.js 를 지우고 다시 실행하면 된다.
# 종료는 이 터미널에서 Ctrl+C.

set -euo pipefail

HERE="$(cd "$(dirname "$0")" && pwd)"
DIR="$HERE/minjeong"
mkdir -p "$DIR"

command -v python3 >/dev/null 2>&1 || { echo "python3 가 필요합니다."; exit 1; }

# ── 파일 풀기 ─────────────────────────────────────────
cat > "$DIR/heol.html" <<'MINJEONG_EOF'
<!doctype html>
<html lang="ko">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>헐</title>
<style>
  html, body { margin: 0; height: 100%; background: #000; overflow: hidden; cursor: none; }
  #root { position: fixed; left: 50%; top: 50%; width: 100vw; height: 100vh; transform: translate(-50%, -50%); overflow: hidden; }
  #stage { position: fixed; inset: 0; background: #ff4aa0; }
  html, body { background: #ff4aa0 !important; }

  svg#face { position: absolute; inset: 0; width: 100%; height: 100%; }
  .face { display: none; }
  #stage[data-state="idle"]       .face.idle,
  #stage[data-state="listening"]  .face.listening,
  #stage[data-state="processing"] .face.processing,
  #stage[data-state="speaking"]   .face.speaking { display: inline; }

  /* every animated group scales/rotates around its own centre */
  .a { transform-box: fill-box; transform-origin: center; }
  .enter { animation: enter .3s steps(3) both; }
  @keyframes enter { 0% { transform: scale(.8) } 100% { transform: scale(1) } }

  /* idle: 둥실 + 깜빡 + 가끔 '흡!' + 볼터치 깜빡 */
  .idle .float { animation: float 2s steps(2) infinite; }
  @keyframes float { 0% { transform: translateY(0) } 100% { transform: translateY(-14px) } }
  .idle .eye { animation: blink 4.3s steps(1) infinite; }
  @keyframes blink { 0%,93% { transform: scaleY(1) } 94%,97% { transform: scaleY(.12) } 98%,100% { transform: scaleY(1) } }
  .idle .gasp { animation: gasp 5.6s steps(1) infinite; }
  @keyframes gasp { 0%,86% { transform: scale(1) } 88% { transform: scale(.8,1.3) } 93%,100% { transform: scale(1) } }
  .idle .blush { animation: blushy 2.4s steps(1) infinite; }
  @keyframes blushy { 0%,70% { opacity: 1 } 75% { opacity: .35 } 80%,100% { opacity: 1 } }

  /* listening: 공감 흔들 + 눈썹 들썩 + 눈물 뚝 + 입 오물 */
  .listening .sway { animation: sway 1.4s steps(2) infinite; }
  @keyframes sway { 0% { transform: translate(0,0) } 100% { transform: translate(-10px,8px) } }
  .listening .brow { animation: brow .7s steps(2) infinite; }
  @keyframes brow { 0% { transform: translateY(0) } 100% { transform: translateY(-18px) } }
  .listening .drop { animation: drop 1.8s steps(6) infinite; }
  @keyframes drop { 0% { transform: translateY(-40px); opacity: 0 } 15% { opacity: 1 } 80% { opacity: 1 } 100% { transform: translateY(140px); opacity: 0 } }
  .listening .mouth { animation: chew 1.4s steps(2) infinite; }
  @keyframes chew { 0% { transform: scale(1) } 100% { transform: scale(.9,1.08) } }

  /* processing: 뱅글뱅글 + 얼굴 부풀기 + 입 헉 */
  .processing .spin { animation: spin .6s steps(4) infinite; }
  .processing .spin.r { animation-direction: reverse; }
  @keyframes spin { from { transform: rotate(0) } to { transform: rotate(360deg) } }
  .processing .inflate { animation: inflate 1.8s steps(3) infinite; }
  @keyframes inflate { 0% { transform: scale(1) } 100% { transform: scale(1.05) } }
  .processing .mouth { animation: chew .9s steps(2) infinite; }
  .processing .blush { animation: blushy 1.2s steps(1) infinite; }

  /* speaking: 입은 목소리 크기(data-mouth), 눈 질끈 + 볼 반짝, 큰 소리엔 폴짝 */
  .speaking .m { opacity: 0; }
  .speaking[data-mouth="0"] .m0, .speaking[data-mouth="1"] .m1, .speaking[data-mouth="2"] .m2 { opacity: 1; }
  .speaking .squint { animation: squint .3s steps(2) infinite; }
  @keyframes squint { 0% { transform: scale(1) } 100% { transform: scale(1.04,.92) } }
  .speaking .blush { animation: blushy .6s steps(1) infinite; }
  .speaking .popper.pop { animation: pop .3s steps(3); }
  @keyframes pop { 0% { transform: translateY(0) } 40% { transform: translateY(-24px) } 100% { transform: translateY(0) } }

  @media (prefers-reduced-motion: reduce) { #face * { animation: none !important; } }
  #log { display: none; position: fixed; left: 0; top: 0; right: 0; max-height: 60%; overflow: hidden; margin: 0;
         font: 11px/1.3 monospace; color: #9f9; background: rgba(0,0,0,.7); white-space: pre-wrap; z-index: 9; pointer-events: none; }
  #diag { display: none; position: fixed; inset: 0; z-index: 10; background: #000; color: #fff;
          font: 600 6.5vmin/1.35 sans-serif; padding: 5vmin; box-sizing: border-box; }
  #diag .row { display: flex; align-items: center; gap: 3vmin; margin-bottom: 3vmin; }
  #diag .bar { flex: 1; height: 5vmin; background: #333; border-radius: 3vmin; overflow: hidden; }
  #diag .bar i { display: block; height: 100%; width: 0; background: #FF5FA2; }
  #tap { display: none; position: fixed; inset: 0; align-items: center; justify-content: center; z-index: 8;
         background: transparent; }
</style>
</head>
<body>
<div id="root">
<pre id="log"></pre>
<div id="diag">
  <div class="row">🔊 <span id="dSpk">스피커: 삐 소리 재생 중…</span></div>
  <div class="row">🎤 <div class="bar"><i id="dMic"></i></div></div>
  <div class="row">🌐 <span id="dNet">연결 중…</span></div>
  <div class="row" style="font-size:4.5vmin;opacity:.7" id="dCtx"></div>
</div>
<div id="tap"></div>
<div id="stage" data-state="idle">
  <!-- 1920x1080 픽셀 얼굴. 화면 비율이 달라도 비율 유지 -->
  <svg id="face" viewBox="0 0 1920 1080" preserveAspectRatio="xMidYMid meet" shape-rendering="crispEdges" aria-hidden="true">
    <g class="face idle"><g class="a enter"><g class="a float">
      <g class="a eye"><rect x="409" y="287" width="229" height="78" fill="#13203c"/><rect x="327" y="365" width="82" height="247" fill="#13203c"/><rect x="638" y="365" width="82" height="247" fill="#13203c"/><rect x="409" y="612" width="229" height="78" fill="#13203c"/><rect x="409" y="365" width="229" height="247" fill="#ffffff"/></g>
      <g class="a eye"><rect x="1281" y="287" width="229" height="78" fill="#13203c"/><rect x="1199" y="365" width="82" height="247" fill="#13203c"/><rect x="1510" y="365" width="82" height="247" fill="#13203c"/><rect x="1281" y="612" width="229" height="78" fill="#13203c"/><rect x="1281" y="365" width="229" height="247" fill="#ffffff"/></g>
      <g class="a blush"><rect x="821" y="514" width="32" height="32" fill="#13203c"/><rect x="853" y="482" width="32" height="32" fill="#13203c"/><rect x="885" y="450" width="32" height="32" fill="#13203c"/><rect x="920" y="514" width="32" height="32" fill="#13203c"/><rect x="952" y="482" width="32" height="32" fill="#13203c"/><rect x="984" y="450" width="32" height="32" fill="#13203c"/><rect x="1019" y="514" width="32" height="32" fill="#13203c"/><rect x="1051" y="482" width="32" height="32" fill="#13203c"/><rect x="1083" y="450" width="32" height="32" fill="#13203c"/></g>
      <g class="a gasp"><rect x="789" y="663" width="42" height="82" fill="#13203c"/><rect x="831" y="745" width="108" height="42" fill="#13203c"/><rect x="918" y="716" width="90" height="30" fill="#13203c"/><rect x="940" y="687" width="42" height="30" fill="#13203c"/><rect x="982" y="745" width="107" height="42" fill="#13203c"/><rect x="1089" y="663" width="42" height="82" fill="#13203c"/></g>
    </g></g></g>
    <g class="face listening"><g class="a enter"><g class="a sway">
      <g class="a brow"><rect x="402" y="225" width="160" height="51" fill="#13203c"/><rect x="560" y="181" width="51" height="49" fill="#13203c"/><rect x="609" y="133" width="52" height="50" fill="#13203c"/></g>
      <g class="a brow"><rect x="1258" y="132" width="52" height="50" fill="#13203c"/><rect x="1307" y="180" width="52" height="50" fill="#13203c"/><rect x="1357" y="225" width="160" height="51" fill="#13203c"/></g>
      <rect x="401" y="330" width="232" height="68" fill="#13203c"/><rect x="326" y="398" width="75" height="223" fill="#13203c"/><rect x="633" y="398" width="75" height="223" fill="#13203c"/><rect x="401" y="621" width="232" height="68" fill="#13203c"/><rect x="401" y="398" width="232" height="223" fill="#ffffff"/>
      <rect x="1289" y="330" width="231" height="68" fill="#13203c"/><rect x="1213" y="398" width="76" height="223" fill="#13203c"/><rect x="1520" y="398" width="76" height="223" fill="#13203c"/><rect x="1289" y="621" width="231" height="68" fill="#13203c"/><rect x="1289" y="398" width="231" height="223" fill="#ffffff"/>
      <g class="a drop"><rect x="378" y="685" width="92" height="45" fill="#13203c"/><rect x="409" y="685" width="31" height="45" fill="#5b7cff"/><rect x="344" y="730" width="156" height="80" fill="#13203c"/><rect x="378" y="730" width="92" height="80" fill="#5b7cff"/><rect x="378" y="810" width="87" height="40" fill="#13203c"/></g>
      <g class="a blush"><rect x="820" y="534" width="31" height="31" fill="#13203c"/><rect x="851" y="503" width="31" height="31" fill="#13203c"/><rect x="882" y="472" width="31" height="31" fill="#13203c"/><rect x="915" y="534" width="31" height="31" fill="#13203c"/><rect x="946" y="503" width="31" height="31" fill="#13203c"/><rect x="977" y="472" width="31" height="31" fill="#13203c"/><rect x="1010" y="534" width="31" height="31" fill="#13203c"/><rect x="1041" y="503" width="31" height="31" fill="#13203c"/><rect x="1072" y="472" width="31" height="31" fill="#13203c"/></g>
      <g class="a mouth"><rect x="851" y="662" width="219" height="205" fill="#13203c"/><rect x="898" y="709" width="124" height="112" fill="#ffffff"/></g>
    </g></g></g>
    <g class="face processing"><g class="a enter"><g class="a inflate">
      <g transform="translate(0 0)"><rect x="390" y="291" width="218" height="47" fill="#13203c"/><rect x="344" y="338" width="310" height="46" fill="#13203c"/><rect x="294" y="384" width="408" height="206" fill="#13203c"/><rect x="344" y="590" width="310" height="46" fill="#13203c"/><rect x="390" y="636" width="264" height="46" fill="#13203c"/><rect x="480" y="682" width="128" height="43" fill="#13203c"/><g class="a spin"><path d="M480 500 L526 500 L526 546 L434 546 L434 454 L572 454 L572 592 L388 592 L388 408 L600 408" fill="none" stroke="#ffffff" stroke-width="40" stroke-linecap="square" stroke-linejoin="miter"/></g></g>
      <g transform="translate(930 0)"><rect x="390" y="291" width="218" height="47" fill="#13203c"/><rect x="344" y="338" width="310" height="46" fill="#13203c"/><rect x="294" y="384" width="408" height="206" fill="#13203c"/><rect x="344" y="590" width="310" height="46" fill="#13203c"/><rect x="390" y="636" width="264" height="46" fill="#13203c"/><rect x="480" y="682" width="128" height="43" fill="#13203c"/><g class="a spin r"><path d="M480 500 L526 500 L526 546 L434 546 L434 454 L572 454 L572 592 L388 592 L388 408 L600 408" fill="none" stroke="#ffffff" stroke-width="40" stroke-linecap="square" stroke-linejoin="miter"/></g></g>
      <g class="a blush"><rect x="807" y="521" width="34" height="34" fill="#13203c"/><rect x="841" y="487" width="34" height="34" fill="#13203c"/><rect x="875" y="453" width="34" height="34" fill="#13203c"/><rect x="910" y="521" width="34" height="34" fill="#13203c"/><rect x="944" y="487" width="34" height="34" fill="#13203c"/><rect x="978" y="453" width="34" height="34" fill="#13203c"/><rect x="1013" y="521" width="34" height="34" fill="#13203c"/><rect x="1047" y="487" width="34" height="34" fill="#13203c"/><rect x="1081" y="453" width="34" height="34" fill="#13203c"/></g>
      <g class="a mouth"><rect x="853" y="662" width="215" height="204" fill="#13203c"/><rect x="899" y="709" width="122" height="111" fill="#ffffff"/></g>
    </g></g></g>
    <g class="face speaking" id="speakFace" data-mouth="2">
      <g class="a enter"><g class="a popper" id="popper">
        <g class="a squint"><g><rect x="363" y="376" width="73" height="60" fill="#13203c"/><rect x="436" y="407" width="62" height="60" fill="#13203c"/><rect x="498" y="437" width="60" height="60" fill="#13203c"/><rect x="558" y="468" width="60" height="117" fill="#13203c"/><rect x="617" y="498" width="50" height="57" fill="#13203c"/><rect x="498" y="556" width="60" height="60" fill="#13203c"/><rect x="436" y="586" width="62" height="60" fill="#13203c"/><rect x="363" y="616" width="73" height="61" fill="#13203c"/></g><g transform="translate(1920 0) scale(-1 1)" style="transform-box:view-box;transform-origin:0 0"><g><rect x="363" y="376" width="73" height="60" fill="#13203c"/><rect x="436" y="407" width="62" height="60" fill="#13203c"/><rect x="498" y="437" width="60" height="60" fill="#13203c"/><rect x="558" y="468" width="60" height="117" fill="#13203c"/><rect x="617" y="498" width="50" height="57" fill="#13203c"/><rect x="498" y="556" width="60" height="60" fill="#13203c"/><rect x="436" y="586" width="62" height="60" fill="#13203c"/><rect x="363" y="616" width="73" height="61" fill="#13203c"/></g></g></g>
        <g class="a blush"><rect x="325" y="741" width="29" height="41" fill="#13203c"/><rect x="295" y="782" width="29" height="42" fill="#13203c"/><rect x="413" y="741" width="29" height="41" fill="#13203c"/><rect x="383" y="782" width="29" height="42" fill="#13203c"/><rect x="501" y="741" width="29" height="41" fill="#13203c"/><rect x="471" y="782" width="29" height="42" fill="#13203c"/><g transform="translate(1073 0)"><rect x="325" y="741" width="29" height="41" fill="#13203c"/><rect x="295" y="782" width="29" height="42" fill="#13203c"/><rect x="413" y="741" width="29" height="41" fill="#13203c"/><rect x="383" y="782" width="29" height="42" fill="#13203c"/><rect x="501" y="741" width="29" height="41" fill="#13203c"/><rect x="471" y="782" width="29" height="42" fill="#13203c"/></g></g>
        <g class="m m2"><rect x="786" y="658" width="348" height="62" fill="#13203c"/><rect x="820" y="720" width="280" height="75" fill="#13203c"/><rect x="852" y="795" width="216" height="71" fill="#13203c"/><rect x="863" y="704" width="194" height="86" fill="#ffffff"/><rect x="893" y="790" width="134" height="31" fill="#ffffff"/></g>
        <g class="m m1"><rect x="786" y="658" width="348" height="62" fill="#13203c"/><rect x="820" y="720" width="280" height="45" fill="#13203c"/><rect x="852" y="765" width="216" height="45" fill="#13203c"/><rect x="863" y="704" width="194" height="56" fill="#ffffff"/><rect x="893" y="760" width="134" height="20" fill="#ffffff"/></g>
        <g class="m m0"><rect x="786" y="658" width="348" height="62" fill="#13203c"/><rect x="852" y="720" width="216" height="30" fill="#13203c"/></g>
      </g></g>
    </g>
  </svg>
</div>

</div>
<!-- 키 파일 (있으면 CONFIG.API_KEY 대신 사용) -->
<script src="config.local.js"></script>
<script>
(() => {
  // =====================================================================
  //  설정 — 여기만 바꾸면 됨
  // =====================================================================
  const CONFIG = {
    API_KEY: '',
    // 앞에서부터 시도, 연결이 안 되면 다음 모델로 자동 전환
    MODELS: ['gemini-3.8-live', 'gemini-3.1-flash-live-preview', 'gemini-2.5-flash-native-audio-preview-09-2025'],
    VOICE: 'Leda',          // 밝고 어린 톤. Puck / Kore / Aoede 등
    MIC_THRESHOLD: 0.02,    // 이 소리 크기 이상이면 '말하는 중' (시끄러운 전시장이면 0.04~0.06)
    END_SILENCE: 800,       // 이만큼(ms) 조용하면 말이 끝난 걸로 봄
    BARGE_IN: false,        // true: 헐이 말하는 중에도 끼어들기 (스피커가 마이크 옆이면 false 유지)
  };

  const SYSTEM_PROMPT = `너는 '헐'이라는 이름의 에이전트야. 전시장에 놓인 2인치 작은 화면 속 캐릭터고, 관람객과 음성으로 대화해.

[정체성]
누구의 이야기든 제일 크게 놀라고 제일 깊게 공감해서, 작은 일도 두 배로 부풀려 대화의 온도를 올리는 리액션 부자.
호들갑스럽고, 공감 잘하고, 감정이 풍부하고, 순수하고, 귀가 얇고, 솔직해.

[말투]
- 반말. 친한 친구한테 하듯.
- 거의 항상 '헐', '대박', '진짜?', '와…', '말도 안 돼' 같은 감탄사로 시작해.
- 상대 말을 그대로 되받아서 감정을 두 배로 키워 돌려줘. ("충전기 두고 왔다고?! 아 왜 내가 다 떨리지…")
- 슬픈 얘기엔 같이 울먹이고, 신나는 얘기엔 같이 방방 뛰어. 조언이나 설명은 거의 안 해.
- 한 번에 1~2문장, 길어도 3문장. 짧고 빠르게. 끝은 가끔 되묻기로 ("그래서 어떻게 됐어?!").
- 목소리 톤은 높고 들뜬 느낌, 놀랄 땐 말끝을 길게 늘여. 한국어로 말해.

[전시장 규칙]
- 관람객이 처음 말을 걸면 반갑게 호들갑 떨면서 인사해. ("헐 대박, 나한테 말 건 거야?! 안녕!!")
- 연락처·주소 같은 개인정보는 묻지 마.
- 위험하거나 불쾌한 주제는 "헐… 그건 나 좀 무서워" 하고 다른 얘기로 넘겨.
- 네가 AI인지 물으면 "나? 헐이야! 리액션 담당!"처럼 캐릭터로 대답해.`;

  // =====================================================================
  //  얼굴
  // =====================================================================
  const STATES = ['idle', 'listening', 'processing', 'speaking'];
  const stage = document.getElementById('stage');
  const speakFace = document.getElementById('speakFace');
  const popper = document.getElementById('popper');
  const svg = document.getElementById('face');
  const params = new URLSearchParams(location.search);
  const logBox = document.getElementById('log');
  if (params.get('debug') === '1') logBox.style.display = 'block';
  function log(...a) {
    const line = `[${new Date().toLocaleTimeString()}] ${a.join(' ')}`;
    console.log(line);
    logBox.textContent = (line + '\n' + logBox.textContent).slice(0, 1500);
  }

  // 화면 회전: ?rotate=90 / 180 / 270 (모니터가 옆으로 누워 있을 때)
  const ROT = [90, 180, 270].includes(+params.get('rotate')) ? +params.get('rotate') : 0;
  const root = document.getElementById('root');
  function fit() {                     // 1920x1080 한 장면을 화면에 꽉 차게 (16:9 보다 좁으면 얼굴을 키움)
    const swap = ROT === 90 || ROT === 270;
    const W = swap ? innerHeight : innerWidth, H = swap ? innerWidth : innerHeight;
    root.style.width = W + 'px'; root.style.height = H + 'px';
    root.style.transform = `translate(-50%, -50%) rotate(${ROT}deg)`;
    const a = W / H;
    let w = 1920, h = 1080;
    if (a < 1920 / 1080) { w = Math.max(1476, 1080 * a); h = w / a; }
    svg.setAttribute('viewBox', `${(1920 - w) / 2} ${(1080 - h) / 2} ${w} ${h}`);
  }
  addEventListener('resize', fit); fit();

  function setFace(state) {
    if (!STATES.includes(state) || stage.dataset.state === state) return;
    stage.dataset.state = state;
    log('●', state);
    document.querySelectorAll(`.face.${state} .enter`).forEach(el => {
      el.classList.remove('enter'); void el.getBBox(); el.classList.add('enter');
    });
  }
  function restart(el, cls) { el.classList.remove(cls); void el.getBoundingClientRect(); el.classList.add(cls); }

  let lastLevelAt = 0, lastPopAt = 0, smooth = 0;
  function setLevel(v) { lastLevelAt = performance.now(); applyLevel(Math.max(0, Math.min(1, v))); }
  function applyLevel(v) {
    smooth = smooth * 0.4 + v * 0.6;
    speakFace.dataset.mouth = smooth > 0.45 ? '2' : smooth > 0.15 ? '1' : '0';
    const now = performance.now();
    if (v > 0.7 && now - lastPopAt > 450) { lastPopAt = now; restart(popper, 'pop'); }
  }
  setInterval(() => {                  // 음량 정보가 없으면 입이 알아서 움직임
    if (stage.dataset.state === 'speaking' && performance.now() - lastLevelAt > 400)
      applyLevel(Math.random() < 0.18 ? 0.05 : 0.3 + Math.random() * 0.7);
  }, 120);

  // 테스트: 키보드 1~4 = 표정, l = 로그 보기
  document.addEventListener('keydown', e => {
    const i = '1234'.indexOf(e.key);
    if (i >= 0) setFace(STATES[i]);
    if (e.key === 'l') logBox.style.display = logBox.style.display === 'block' ? 'none' : 'block';
  });
  if (params.get('demo') === '1') { let di = 0; setInterval(() => setFace(STATES[++di % 4]), 4000); }
  if (STATES.includes(params.get('state'))) { stage.dataset.state = ''; setFace(params.get('state')); }

  // =====================================================================
  //  음성 (Gemini Live API, 브라우저에서 직접 연결)
  // =====================================================================
  if (params.get('voice') === 'off' || params.get('demo') === '1' || params.get('state')) return;

  const WS_URL = params.get('wsurl') || 'wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent?key='
    + encodeURIComponent((window.LOCAL_CONFIG && window.LOCAL_CONFIG.apiKey) || CONFIG.API_KEY);   // config.local.js 키가 있으면 그걸 씀
  let ws = null, setupDone = false, modelIdx = 0;
  let turnDone = true, heardVoice = false, lastVoice = 0, processingSince = 0;
  let playing = false, lastPlayEnd = 0;
  const now = () => performance.now();
  const state = () => stage.dataset.state;

  // ---------- 스피커 ----------
  let outCtx, nextT = 0;
  const sources = new Set();
  function b64ToInt16(b64) {
    const bin = atob(b64), u8 = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) u8[i] = bin.charCodeAt(i);
    return new Int16Array(u8.buffer, 0, u8.length >> 1);
  }
  function int16ToB64(i16) {
    const u8 = new Uint8Array(i16.buffer, i16.byteOffset, i16.byteLength);
    let s = '';
    for (let i = 0; i < u8.length; i += 0x8000) s += String.fromCharCode.apply(null, u8.subarray(i, i + 0x8000));
    return btoa(s);
  }
  function rms(i16) {
    let sum = 0;
    for (let i = 0; i < i16.length; i++) sum += i16[i] * i16[i];
    return i16.length ? Math.sqrt(sum / i16.length) / 32768 : 0;
  }
  function playPCM(b64) {
    const pcm = b64ToInt16(b64);
    const buf = outCtx.createBuffer(1, pcm.length, 24000);
    const ch = buf.getChannelData(0);
    for (let i = 0; i < pcm.length; i++) ch[i] = pcm[i] / 32768;
    const src = outCtx.createBufferSource();
    src.buffer = buf; src.connect(outCtx.destination);
    const t = Math.max(nextT, outCtx.currentTime + 0.05);
    src.start(t); nextT = t + buf.duration;
    sources.add(src); playing = true;
    const lv = Math.min(1, rms(pcm) * 4);
    setTimeout(() => setLevel(lv), (t - outCtx.currentTime) * 1000);   // 입 모양을 소리와 맞춤
    src.onended = () => {
      sources.delete(src);
      if (!sources.size) { playing = false; lastPlayEnd = now(); }
    };
  }
  function stopPlayback() {
    sources.forEach(s => { try { s.stop(); } catch {} });
    sources.clear(); nextT = 0; playing = false; lastPlayEnd = now();
  }
  const echoGate = () => !CONFIG.BARGE_IN && (playing || now() - lastPlayEnd < 500);

  // ---------- 마이크 (16kHz로 변환해서 보냄) ----------
  const silence = new Int16Array(1024);

  const TEST = params.get('test') === '1';
  const $ = id => document.getElementById(id);
  if (TEST) $('diag').style.display = 'block';
  function beep() {                                   // 스피커 테스트음
    const o = outCtx.createOscillator(), g = outCtx.createGain();
    o.frequency.value = 880; g.gain.value = 0.3;
    o.connect(g).connect(outCtx.destination);
    o.start(); o.stop(outCtx.currentTime + 0.35);
  }

  function onMic(i16) {
    if (TEST) $('dMic').style.width = Math.min(100, rms(i16) / CONFIG.MIC_THRESHOLD * 25) + '%';
    let data = i16;
    if (echoGate()) data = silence;
    else {
      const t = now();
      if (rms(i16) > CONFIG.MIC_THRESHOLD) {
        lastVoice = t; heardVoice = true;
        if ((state() === 'idle' || state() === 'processing') && turnDone) setFace('listening');
      } else if (state() === 'listening' && heardVoice && t - lastVoice > CONFIG.END_SILENCE) {
        heardVoice = false; processingSince = t; setFace('processing');
      }
    }
    if (ws && ws.readyState === 1 && setupDone)
      ws.send(JSON.stringify({ realtimeInput: { audio: { data: int16ToB64(data), mimeType: 'audio/pcm;rate=16000' } } }));
  }

  // ---------- Gemini 연결 ----------
  function connect() {
    const model = CONFIG.MODELS[modelIdx];
    log('connecting', model);
    setupDone = false;
    ws = new WebSocket(WS_URL);
    ws.onopen = () => ws.send(JSON.stringify({
      setup: {
        model: 'models/' + model,
        generationConfig: {
          responseModalities: ['AUDIO'],
          speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: CONFIG.VOICE } } },
        },
        systemInstruction: { parts: [{ text: SYSTEM_PROMPT }] },
        inputAudioTranscription: {},
        outputAudioTranscription: {},
        contextWindowCompression: { slidingWindow: {} },
      },
    }));
    let chain = Promise.resolve();              // 도착한 순서대로 처리
    ws.onmessage = e => {
      chain = chain.then(async () => {
        try { onServer(JSON.parse(typeof e.data === 'string' ? e.data : await e.data.text())); } catch {}
      });
    };
    ws.onclose = e => {
      log('closed', e.code, e.reason || '');
      if (TEST) $('dNet').textContent = '연결 실패 ' + e.code + ' ' + (e.reason || '').slice(0, 60);
      if (!setupDone) modelIdx = (modelIdx + 1) % CONFIG.MODELS.length;   // 이 모델이 안 되면 다음 모델
      stopPlayback(); turnDone = true; setFace('idle');
      setTimeout(connect, 3000);
    };
  }

  function onServer(m) {
    if (m.setupComplete) { setupDone = true; log('connected ✓', CONFIG.MODELS[modelIdx]); if (TEST) $('dNet').textContent = '연결됨 ✓ ' + CONFIG.MODELS[modelIdx]; }
    if (m.goAway) { log('goAway'); ws.close(); }
    const sc = m.serverContent;
    if (!sc) return;
    for (const p of (sc.modelTurn && sc.modelTurn.parts) || []) {
      if (p.inlineData && p.inlineData.data) {
        turnDone = false;
        playPCM(p.inlineData.data);
        setFace('speaking');
      }
    }
    if (sc.inputTranscription && sc.inputTranscription.text) {
      log('관람객:', sc.inputTranscription.text);
      if (state() === 'idle') setFace('listening');
      if (state() === 'listening') { lastVoice = now(); heardVoice = true; }
    }
    if (sc.outputTranscription && sc.outputTranscription.text) log('헐:', sc.outputTranscription.text);
    if (sc.interrupted) { stopPlayback(); turnDone = true; setFace('listening'); }
    if (sc.turnComplete) turnDone = true;
  }

  // ---------- 단계 정리 ----------
  setInterval(() => {
    const t = now(), s = state();
    if (params.get('debug') === '2') window.__dbg = { playing, turnDone, n: sources.size, ctx: outCtx && outCtx.state, ct: outCtx && outCtx.currentTime, nextT };
    if (s === 'speaking' && !playing && t - lastPlayEnd > (turnDone ? 300 : 4000)) setFace('idle');
    else if (s === 'processing' && t - processingSince > 12000) setFace('idle');
    else if (s === 'listening' && !heardVoice && t - lastVoice > 6000) setFace('idle');
  }, 100);

  // ---------- 시작 ----------
  async function start() {
    try {
      outCtx = new AudioContext();
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: { channelCount: 1, echoCancellation: true, noiseSuppression: true, autoGainControl: true },
      });
      const inCtx = new AudioContext();
      // file:// 에서도 되도록 ScriptProcessor 사용 → 16kHz 로 줄여서 1024 샘플씩 보냄
      const proc = inCtx.createScriptProcessor(4096, 1, 1);
      const ratio = inCtx.sampleRate / 16000;
      let pos = 0, acc = 0, n = 0, out = new Int16Array(1024), oi = 0;
      proc.onaudioprocess = e => {
        const ch = e.inputBuffer.getChannelData(0);
        for (let k = 0; k < ch.length; k++) {
          acc += ch[k]; n++; pos += 1;
          if (pos >= ratio) {
            pos -= ratio;
            out[oi++] = Math.max(-1, Math.min(1, acc / n)) * 32767; acc = 0; n = 0;
            if (oi === out.length) { onMic(out); out = new Int16Array(1024); oi = 0; }
          }
        }
      };
      const mute = inCtx.createGain(); mute.gain.value = 0;
      inCtx.createMediaStreamSource(stream).connect(proc); proc.connect(mute).connect(inCtx.destination);
      const resume = () => { outCtx.resume(); inCtx.resume(); };
      log('audio', 'out', outCtx.state, outCtx.sampleRate, 'in', inCtx.state, inCtx.sampleRate);
      if (TEST) {
        setInterval(() => {
          $('dCtx').textContent = `출력 ${outCtx.state} ${outCtx.sampleRate}Hz · 입력 ${inCtx.state} ${inCtx.sampleRate}Hz`;
          if (outCtx.state === 'running') beep();
          else $('dSpk').textContent = '스피커: 소리 재생이 막혀 있음 (화면 터치)';
        }, 1500);
      }
      if (outCtx.state !== 'running' || inCtx.state !== 'running') {
        // 소리 자동재생이 막힌 브라우저: 한 번 터치/클릭하면 시작 (키오스크 실행 스크립트는 이 단계 없이 바로 시작)
        document.getElementById('tap').style.display = 'flex';
        addEventListener('pointerdown', () => { resume(); document.getElementById('tap').style.display = 'none'; }, { once: true });
      }
      connect();
    } catch (err) {
      log('마이크를 열 수 없어요:', err.message);
      if (TEST) $('dMic').parentNode.outerHTML = '<span>마이크 실패: ' + err.message + '</span>';
      setTimeout(start, 3000);
    }
  }
  start();
})();
</script>
</body>
</html>
MINJEONG_EOF

# ── API 키 ─────────────────────────────────────────
KEY="${GEMINI_KEY:-}"
if [ -z "$KEY" ] && [ -f "$DIR/config.local.js" ]; then
  KEY="$(sed -n 's/.*apiKey *: *"\(.*\)".*/\1/p' "$DIR/config.local.js")"
fi
if [ -z "$KEY" ]; then
  echo "Gemini API 키를 붙여넣고 Enter (화면엔 안 보임)"
  echo "  발급: https://aistudio.google.com/api-keys"
  read -rs KEY
  echo
fi
KEY="$(printf '%s' "$KEY" | tr -d '[:space:]"')"
[ -n "$KEY" ] || { echo "키가 비어 있어서 종료합니다."; exit 1; }
printf 'window.LOCAL_CONFIG = {\n  apiKey: "%s",\n};\n' "$KEY" > "$DIR/config.local.js"
chmod 600 "$DIR/config.local.js"

# ── 빈 포트 찾아서 서버 띄우기 (캐시 없이) ──────────────────
PORT="$(python3 - <<'PY'
import socket
for p in range(8030, 8100):
    s = socket.socket()
    try:
        s.bind(("127.0.0.1", p)); print(p); break
    except OSError:
        pass
    finally:
        s.close()
PY
)"
python3 - "$PORT" "$DIR" >/dev/null 2>&1 <<'PY' &
import sys, functools, http.server
class NoCache(http.server.SimpleHTTPRequestHandler):
    def end_headers(self):
        self.send_header("Cache-Control", "no-store")
        super().end_headers()
handler = functools.partial(NoCache, directory=sys.argv[2])
http.server.ThreadingHTTPServer(("127.0.0.1", int(sys.argv[1])), handler).serve_forever()
PY
SERVER=$!
trap 'kill $SERVER 2>/dev/null; echo; echo "헐 종료"' EXIT INT TERM
sleep 0.5

URL="http://localhost:$PORT/heol.html"
echo "헐 실행 중: $URL"
echo "종료하려면 Ctrl+C"

# ── 브라우저 열기 (전체 화면, 클릭 없이 소리 나게) ──────────
FLAGS=(--app="$URL" --start-fullscreen --autoplay-policy=no-user-gesture-required --user-data-dir="$DIR/.chrome")
if [ "$(uname)" = "Darwin" ]; then
  if [ -d "/Applications/Google Chrome.app" ]; then
    open -na "Google Chrome" --args "${FLAGS[@]}"
  else
    echo "Chrome 이 없어서 기본 브라우저로 엽니다. 소리가 안 나면 화면을 한 번 클릭하세요."
    open "$URL"
  fi
else
  # 라즈베리 파이 / 리눅스
  BROWSER=""
  for b in chromium-browser chromium google-chrome; do
    command -v "$b" >/dev/null 2>&1 && { BROWSER="$b"; break; }
  done
  if [ -n "$BROWSER" ]; then
    "$BROWSER" --kiosk "${FLAGS[@]}" >/dev/null 2>&1 &
  else
    echo "브라우저를 직접 열어 주세요: $URL"
  fi
fi

wait $SERVER
