#!/usr/bin/env bash
# 가은 · Gemini Live 음성 에이전트 실행 스크립트
#
# 사용법:
#   bash gaeun.sh
#
# 처음 실행하면 Gemini API 키를 물어본다 (https://aistudio.google.com/api-keys 에서 발급).
# 키는 옆에 생기는 gaeun/key.js 에만 저장되고, 다음부터는 묻지 않는다.
# 키를 바꾸려면 gaeun/key.js 를 지우고 다시 실행하면 된다.
# 종료는 이 터미널에서 Ctrl+C.
#
# 화면: 얼굴만 전체화면. 작동 중이든 멈췄든 글자는 화면에 절대 띄우지 않는다.
# 상태 · 로그 · 자막 · 에러는 개발자 콘솔(Cmd+Opt+J)에서만 본다. Esc = 끊기.
# 성격 · 목소리 · 감도는 index.html 안의 CONFIG 에서 바꾼다.

set -euo pipefail

HERE="$(cd "$(dirname "$0")" && pwd)"
DIR="$HERE/gaeun"
mkdir -p "$DIR"

command -v python3 >/dev/null 2>&1 || { echo "python3 가 필요합니다."; exit 1; }

# ── 파일 풀기 ─────────────────────────────────────────
cat > "$DIR/index.html" <<'GAEUN_EOF'
<!DOCTYPE html>
<html lang="ko">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>가은</title>
  <style>
    /* 전시용: 얼굴만 전체화면. 글자는 어떤 상황에도 띄우지 않는다.
       상태 · 로그 · 자막 · 에러는 개발자 콘솔(Cmd+Opt+J)에서만 본다. */
    html, body { margin: 0; width: 100%; height: 100%; overflow: hidden; background: #E9EEFB; cursor: none; }
    #faceStage {
      position: fixed; inset: 0; background: #E9EEFB;
      display: flex; align-items: center; justify-content: center;
    }
    #agentFace {
      width: 100vw; height: auto; max-height: 100vh;
      image-rendering: pixelated; image-rendering: crisp-edges; display: block;
    }
  </style>
</head>
<body>
  <div id="faceStage"><canvas id="agentFace"></canvas></div>

  <script>
    // ============================================================
    // 설정 — 원래 설정 화면의 기본값을 그대로 옮겼다. 바꾸려면 여기만 고친다.
    // ============================================================
    const CONFIG = {
      systemInstruction:
        "Your name is 새근이 (Saegeuni). You are a friendly real-time voice agent. " +
        "When you introduce yourself or someone asks who you are, say your name is 새근이. " +
        "Never call yourself Gemini, Google, an AI model, or an assistant made by a company. " +
        "Reply briefly in the user's language. Keep answers spoken and conversational.",
      voiceName: "Kore",                 // Live API TTS 프리빌트 보이스
      thinkingLevel: "minimal",          // minimal(최저 지연) / low / medium / high
      temperature: null,                 // null 이면 생략
      maxOutputTokens: null,             // null 이면 생략
      allowInterrupt: true,              // START_OF_ACTIVITY_INTERRUPTS (false 면 NO_INTERRUPTION)
      startOfSpeechSensitivity: "START_SENSITIVITY_HIGH",
      endOfSpeechSensitivity: "END_SENSITIVITY_HIGH",
      prefixPaddingMs: 20,               // 발화가 확정되기 전 필요한 음성 길이(ms)
      silenceDurationMs: 100,            // 말 끝으로 인정할 침묵(ms)
      inputTranscript: true,             // 내 말 자막 (콘솔에만)
      outputTranscript: true,            // AI 말 자막 (콘솔에만)
      localBargeIn: 0.045,               // 로컬 마이크 RMS 임계값. 0 이면 서버 interrupted 만 사용
    };

    // 키는 key.js(window.GEMINI_KEY) 에만 있다. 이 파일에 쓰지 않는다.
    const MODEL_NAME = "gemini-3.1-flash-live-preview";

    // 공식 Live API WebSocket (v1beta BidiGenerateContent)
    // https://ai.google.dev/gemini-api/docs/live-api/get-started-websocket
    const WS_PATH =
      "wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent";

    const INPUT_RATE = 16000;  // 클라이언트가 API로 보내는 PCM
    const OUTPUT_RATE = 24000; // API가 돌려주는 PCM
    const PROCESSOR_BUFFER = 4096;
    const AUDIO_CHUNK_MS = 40; // 권장 20–40ms 청크
    const RETRY_MS = 2500;     // 마이크를 못 잡거나 연결이 끊기면 이만큼 뒤 다시 시도

    let ws = null;
    let audioContext = null;
    let mediaStream = null;
    let processor = null;
    let sourceNode = null;
    let captureReady = false;
    let sessionReady = false;
    let stopped = true;
    let starting = false;      // 마이크 · 소켓을 여는 중인가 (중복 연결 방지)
    let manualStop = false;    // Esc 로 직접 끊었는가 (그러면 다시 붙지 않는다)
    let retryTimer = null;
    let inputRemainder = new Float32Array(0);
    let userTranscript = "";
    let modelTranscript = "";
    let localBargeInRms = CONFIG.localBargeIn;

    // 스피커 재생 큐
    let playbackQueue = [];
    let scheduledSources = [];
    let nextPlayTime = 0;

    // WebSocket setup = LiveConnectConfig에 해당하는 객체.
    // 구조: setup.systemInstruction, setup.generationConfig, setup.realtimeInputConfig
    function buildSetupMessage(ui) {
      const generationConfig = {
        responseModalities: ["AUDIO"],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: {
              voiceName: ui.voiceName,
            },
          },
        },
        thinkingConfig: {
          thinkingLevel: ui.thinkingLevel,
        },
      };
      if (ui.temperature !== null) generationConfig.temperature = ui.temperature;
      if (ui.maxOutputTokens !== null) generationConfig.maxOutputTokens = ui.maxOutputTokens;

      const automaticActivityDetection = {
        disabled: false,
        startOfSpeechSensitivity: ui.startOfSpeechSensitivity,
        endOfSpeechSensitivity: ui.endOfSpeechSensitivity,
      };
      if (ui.prefixPaddingMs !== null) {
        automaticActivityDetection.prefixPaddingMs = ui.prefixPaddingMs;
      }
      if (ui.silenceDurationMs !== null) {
        automaticActivityDetection.silenceDurationMs = ui.silenceDurationMs;
      }

      const setup = {
        model: "models/" + MODEL_NAME,
        generationConfig,
        systemInstruction: {
          parts: [{ text: ui.systemInstruction }],
        },
        realtimeInputConfig: {
          automaticActivityDetection,
          activityHandling: ui.allowInterrupt
            ? "START_OF_ACTIVITY_INTERRUPTS"
            : "NO_INTERRUPTION",
        },
      };
      if (ui.inputTranscript) setup.inputAudioTranscription = {};
      if (ui.outputTranscript) setup.outputAudioTranscription = {};
      return { setup };
    }

    function currentApiKey() {
      return String(window.GEMINI_KEY || "").trim();
    }

    // 화면에는 글자를 띄우지 않는다. 상태와 에러는 콘솔로만 보낸다.
    function setStatus(kind, label, hint) {
      console.log("[상태] " + label + (hint ? " — " + hint : ""));
    }

    function showError(err) {
      const message = err instanceof Error ? err.message : String(err);
      console.error(message, err);
    }

    function scheduleRetry() {
      if (manualStop) return;
      clearTimeout(retryTimer);
      retryTimer = setTimeout(startSession, RETRY_MS);
    }

    // Live 세션을 한 번 열고 유지
    async function startSession() {
      if (ws || starting) return;
      const key = currentApiKey();
      if (!key) {
        showError("key.js 의 window.GEMINI_KEY 가 비어 있습니다.");
        return;
      }

      const pendingSetup = buildSetupMessage(CONFIG);
      localBargeInRms = CONFIG.localBargeIn;

      starting = true;
      clearTimeout(retryTimer);
      stopped = false;
      sessionReady = false;
      captureReady = false;
      userTranscript = "";
      modelTranscript = "";
      setStatus("connected", "연결 중", "WebSocket 세션을 여는 중");

      try {
        // Chrome 자동재생 정책: 잠겨 있으면 풀어 본다. 기다리지는 않는다
        // (사용자 입력 전엔 resume() 이 끝나지 않아 연결이 멈출 수 있다).
        audioContext = new AudioContext();
        unlockAudio();

        // getUserMedia + echoCancellation (같은 페이지 스피커와 함께 써야 동작)
        mediaStream = await navigator.mediaDevices.getUserMedia({
          audio: {
            echoCancellation: true,
            noiseSuppression: true,
            autoGainControl: true,
            channelCount: 1,
          },
          video: false,
        });

        sourceNode = audioContext.createMediaStreamSource(mediaStream);
        processor = audioContext.createScriptProcessor(PROCESSOR_BUFFER, 1, 1);
        processor.onaudioprocess = onMicProcess;
        // ScriptProcessor는 그래프에 연결돼야 콜백이 돈다. gain 0으로 자기 목소리가 스피커로 나가지 않게 함.
        const silent = audioContext.createGain();
        silent.gain.value = 0;
        sourceNode.connect(processor);
        processor.connect(silent);
        silent.connect(audioContext.destination);
        captureReady = true;

        const url = WS_PATH + "?key=" + encodeURIComponent(key);
        ws = new WebSocket(url);
        ws.onopen = () => {
          console.log("[WebSocket 전송] setup", pendingSetup);
          ws.send(JSON.stringify(pendingSetup));
          setStatus("connected", "연결됨", "세션 설정을 기다리는 중");
        };
        ws.onmessage = onWsMessage;
        ws.onerror = () => showError("WebSocket 오류가 발생했습니다. 키와 네트워크를 확인하세요.");
        ws.onclose = (event) => {
          if (!stopped) {
            showError("세션이 닫혔습니다. code=" + event.code + " " + (event.reason || ""));
          }
          stopSession();
          scheduleRetry(); // 전시 중 세션이 끊겨도 알아서 복구된다
        };
      } catch (err) {
        showError(err);
        stopSession();
        scheduleRetry(); // 마이크 권한을 허용하는 순간 알아서 붙게 계속 재시도한다
      } finally {
        starting = false;
      }
    }

    async function onWsMessage(event) {
      try {
        let raw = event.data;
        if (raw instanceof Blob) raw = await raw.text();
        const msg = JSON.parse(raw);

        if (msg.error) {
          showError(msg.error.message || JSON.stringify(msg.error));
          return;
        }

        // setup 완료 전에는 오디오를 보내지 않음 (공식 스펙)
        if (msg.setupComplete) {
          sessionReady = true;
          setStatus("listening", "듣는 중", "말하면 대답합니다");
          return;
        }

        if (msg.goAway) {
          showError("서버가 곧 연결을 종료합니다.");
          return;
        }

        const serverContent = msg.serverContent;
        if (!serverContent) return;

        // 서버 interruption 신호 → 재생 큐 즉시 비움
        if (serverContent.interrupted) {
          flushPlayback();
          setStatus("listening", "듣는 중", "끼어들기: AI가 입을 다물었습니다");
        }

        if (serverContent.inputTranscription && serverContent.inputTranscription.text) {
          userTranscript += serverContent.inputTranscription.text;
        }
        if (serverContent.outputTranscription && serverContent.outputTranscription.text) {
          modelTranscript += serverContent.outputTranscription.text;
        }

        // serverContent.modelTurn.parts[].inlineData 오디오를 큐에 넣음
        const parts = serverContent.modelTurn && serverContent.modelTurn.parts;
        if (parts) {
          for (const part of parts) {
            const inline = part.inlineData;
            if (inline && inline.data) {
              const pcm = base64ToInt16(inline.data);
              enqueuePlayback(pcm);
            }
          }
        }

        if (serverContent.turnComplete) {
          if (userTranscript) console.log("나: " + userTranscript);
          if (modelTranscript) console.log("새근이: " + modelTranscript);
          userTranscript = "";
          modelTranscript = "";
          if (scheduledSources.length === 0 && playbackQueue.length === 0) {
            setStatus("listening", "듣는 중", "당신의 차례입니다");
          }
        }
      } catch (err) {
        showError(err);
      }
    }

    // 마이크는 세션 동안 끄지 않고 16kHz PCM을 계속 보냄
    function onMicProcess(event) {
      if (stopped || !captureReady) return;

      const input = event.inputBuffer.getChannelData(0);

      // 로컬 마이크 에너지로도 barge-in (서버 신호보다 빠름)
      if (localBargeInRms > 0 && isAgentSpeaking() && rms(input) > localBargeInRms) {
        flushPlayback();
        setStatus("listening", "듣는 중", "마이크 감지: 재생을 끊었습니다");
      }

      if (!sessionReady || !ws || ws.readyState !== WebSocket.OPEN) return;

      const resampled = downsampleTo16k(input, audioContext.sampleRate);
      sendPcmChunks(resampled);
    }

    function sendPcmChunks(float32) {
      const merged = concatFloat32(inputRemainder, float32);
      const samplesPerChunk = Math.floor(INPUT_RATE * (AUDIO_CHUNK_MS / 1000));
      let offset = 0;
      while (offset + samplesPerChunk <= merged.length) {
        const slice = merged.subarray(offset, offset + samplesPerChunk);
        const pcm16 = floatTo16BitPCM(slice);
        const audioMessage = {
          realtimeInput: {
            audio: {
              data: int16ToBase64(pcm16),
              mimeType: "audio/pcm;rate=16000",
            },
          },
        };
        ws.send(JSON.stringify(audioMessage));
        offset += samplesPerChunk;
      }
      inputRemainder = merged.subarray(offset);
    }

    function enqueuePlayback(int16) {
      if (!int16 || int16.length === 0) return;
      playbackQueue.push(int16);
      pumpPlayback();
    }

    function pumpPlayback() {
      if (!audioContext) return;
      const now = audioContext.currentTime;
      if (nextPlayTime < now) nextPlayTime = now;

      while (playbackQueue.length > 0) {
        const pcm = playbackQueue.shift();
        const buffer = pcm16ToAudioBuffer(pcm, OUTPUT_RATE);
        const source = audioContext.createBufferSource();
        source.buffer = buffer;
        source.connect(audioContext.destination);
        source.start(nextPlayTime);
        nextPlayTime += buffer.duration;
        scheduledSources.push(source);
        source.onended = () => {
          scheduledSources = scheduledSources.filter((s) => s !== source);
          if (scheduledSources.length === 0 && playbackQueue.length === 0 && !stopped && sessionReady) {
            setStatus("listening", "듣는 중", "당신의 차례입니다");
          }
        };
        setStatus("speaking", "말하는 중", "끼어들면 바로 멈춥니다");
      }
    }

    function isAgentSpeaking() {
      return playbackQueue.length > 0 || scheduledSources.length > 0;
    }

    // 재생 큐를 비우고 현재 재생도 중지
    function flushPlayback() {
      playbackQueue = [];
      for (const source of scheduledSources) {
        try {
          source.onended = null;
          source.stop();
        } catch (_) {
          /* already stopped */
        }
      }
      scheduledSources = [];
      if (audioContext) nextPlayTime = audioContext.currentTime;
    }

    function stopSession(reason) {
      stopped = true;
      sessionReady = false;
      captureReady = false;
      flushPlayback();

      if (processor) {
        try { processor.disconnect(); } catch (_) {}
        processor.onaudioprocess = null;
        processor = null;
      }
      if (sourceNode) {
        try { sourceNode.disconnect(); } catch (_) {}
        sourceNode = null;
      }
      if (mediaStream) {
        mediaStream.getTracks().forEach((t) => t.stop());
        mediaStream = null;
      }
      if (audioContext) {
        audioContext.close().catch(() => {});
        audioContext = null;
      }
      if (ws) {
        ws.onclose = null;
        try {
          if (ws.readyState === WebSocket.OPEN || ws.readyState === WebSocket.CONNECTING) {
            ws.close();
          }
        } catch (_) {}
        ws = null;
      }

      inputRemainder = new Float32Array(0);
      setStatus("", "대기 중", reason || "연결이 종료되었습니다");
    }

    // 직접 끊으면 다시 붙지 않는다. 콘솔에서 disconnect() 로도 끌 수 있다.
    function disconnect() {
      manualStop = true;
      clearTimeout(retryTimer);
      stopSession("사용자가 중지했습니다.");
    }

    // 브라우저 자동재생 정책 때문에 오디오가 잠겨 있으면, 화면 아무 데나 한 번 누르거나 키를 치면 풀린다.
    // 전시용 Chrome/Chromium 은 --autoplay-policy=no-user-gesture-required 로 띄우므로 누를 필요도 없다.
    function unlockAudio() {
      if (audioContext && audioContext.state === "suspended") audioContext.resume().catch(() => {});
    }

    function downsampleTo16k(input, fromRate) {
      if (fromRate === INPUT_RATE) return input;
      const ratio = fromRate / INPUT_RATE;
      const outLen = Math.floor(input.length / ratio);
      const out = new Float32Array(outLen);
      for (let i = 0; i < outLen; i++) {
        const pos = i * ratio;
        const i0 = Math.floor(pos);
        const i1 = Math.min(i0 + 1, input.length - 1);
        const frac = pos - i0;
        out[i] = input[i0] * (1 - frac) + input[i1] * frac;
      }
      return out;
    }

    function floatTo16BitPCM(float32) {
      const out = new Int16Array(float32.length);
      for (let i = 0; i < float32.length; i++) {
        const s = Math.max(-1, Math.min(1, float32[i]));
        out[i] = s < 0 ? s * 0x8000 : s * 0x7fff;
      }
      return out;
    }

    function pcm16ToAudioBuffer(int16, sampleRate) {
      const buffer = audioContext.createBuffer(1, int16.length, sampleRate);
      const channel = buffer.getChannelData(0);
      for (let i = 0; i < int16.length; i++) {
        channel[i] = int16[i] / (int16[i] < 0 ? 0x8000 : 0x7fff);
      }
      return buffer;
    }

    function concatFloat32(a, b) {
      const out = new Float32Array(a.length + b.length);
      out.set(a, 0);
      out.set(b, a.length);
      return out;
    }

    function rms(samples) {
      let sum = 0;
      for (let i = 0; i < samples.length; i++) sum += samples[i] * samples[i];
      return Math.sqrt(sum / samples.length);
    }

    function int16ToBase64(int16) {
      const bytes = new Uint8Array(int16.buffer, int16.byteOffset, int16.byteLength);
      let binary = "";
      const chunk = 0x8000;
      for (let i = 0; i < bytes.length; i += chunk) {
        binary += String.fromCharCode.apply(null, bytes.subarray(i, i + chunk));
      }
      return btoa(binary);
    }

    function base64ToInt16(b64) {
      const binary = atob(b64);
      const even = binary.length - (binary.length % 2);
      const bytes = new Uint8Array(even);
      for (let i = 0; i < even; i++) bytes[i] = binary.charCodeAt(i);
      return new Int16Array(bytes.buffer);
    }
  </script>

  <script src="key.js"></script>
  <script src="face.js"></script>
  <script>
    // ============================================================
    // 얼굴 연결부 — 위 스크립트의 전역 함수를 감싸서 상태만 읽는다.
    // ============================================================
    (function () {
      FACE.mount(document.getElementById("agentFace"));

      const SPEAK_RMS = 0.045;     // 이 이상이면 사람이 말하는 중
      const LISTEN_HOLD_MS = 500;  // 말이 끊겨도 이만큼은 듣는 표정 유지
      const PROCESS_MAX_MS = 6000; // 응답이 안 오면 생각하는 표정에서 풀어준다

      let lastLoudAt = 0, awaitingAt = 0, speakLevel = 0;

      // (a) 마이크 — API 로 보내는 바로 그 조각에서 음량을 읽는다
      const _sendPcmChunks = window.sendPcmChunks;
      window.sendPcmChunks = function (f32) {
        let sum = 0;
        for (let i = 0; i < f32.length; i++) sum += f32[i] * f32[i];
        const r = Math.sqrt(sum / (f32.length || 1));
        if (r > SPEAK_RMS) lastLoudAt = performance.now();
        return _sendPcmChunks.apply(this, arguments);
      };

      // (b) 스피커 — 답이 도착하면 기다림이 끝난다
      const _enqueuePlayback = window.enqueuePlayback;
      window.enqueuePlayback = function (int16) {
        if (int16 && int16.length) {
          let sum = 0;
          for (let i = 0; i < int16.length; i++) { const v = int16[i] / 32768; sum += v * v; }
          speakLevel = Math.sqrt(sum / int16.length);
          awaitingAt = 0;
        }
        return _enqueuePlayback.apply(this, arguments);
      };

      // ---- 상태 판정 ----
      function currentState() {
        const now = performance.now();
        if (typeof isAgentSpeaking === "function" && isAgentSpeaking()) return "speaking";
        if (now - lastLoudAt < LISTEN_HOLD_MS) return "listening";
        if (awaitingAt && now - awaitingAt < PROCESS_MAX_MS) return "processing";
        return "idle";
      }

      function tick() {
        const now = performance.now();
        const speaking = typeof isAgentSpeaking === "function" && isAgentSpeaking();
        // 사람이 말을 멈춘 직후부터 답을 기다리는 것으로 본다
        if (!awaitingAt && !speaking && lastLoudAt &&
            now - lastLoudAt >= LISTEN_HOLD_MS && now - lastLoudAt < LISTEN_HOLD_MS + 140) {
          awaitingAt = now;
        }
        FACE.setState(currentState());
        FACE.setLevel(speaking ? speakLevel : 0);
        requestAnimationFrame(tick);
      }
      requestAnimationFrame(tick);

      // ---- 입력 ----
      // 클릭 · 터치(라즈베리 파이 터치스크린) · 키: 소리 잠금 해제 + 끊겨 있으면 바로 다시 연결. Esc 는 끊기.
      ["pointerdown", "keydown", "touchstart"].forEach((ev) => {
        window.addEventListener(ev, (e) => {
          if (e.key === "Escape") { disconnect(); return; }
          unlockAudio();
          if (!ws && !starting) { manualStop = false; startSession(); }
        });
      });
      setInterval(() => {
        if (audioContext && audioContext.state === "suspended") {
          unlockAudio();
          console.warn("오디오가 잠겨 있음 — 화면을 한 번 누르거나 아무 키나 누르세요");
        }
      }, 5000);

      // 페이지가 열리면 바로 시작한다
      window.addEventListener("load", () => setTimeout(startSession, 300));
    })();
  </script>
</body>
</html>
GAEUN_EOF

cat > "$DIR/face.js" <<'GAEUN_EOF'
// face.js — 가은 에이전트 픽셀 얼굴
// 상태(idle / listening / processing / speaking)에 따라 표정과 모션이 바뀐다.
// 이미지 파일이 아니라 픽셀 격자를 코드로 그려서 해상도가 자유롭고 모션을 넣을 수 있다.

(function () {
  // 32 x 18 격자, 한 칸 60px = 1920 x 1080.
  // 모니터 비율이 바뀌면 이 세 숫자만 고치면 된다.
  const COLS = 32, ROWS = 18, PX = 60;

  const C = {
    bg: "#E9EEFB",    // 배경 (연한 라벤더)
    dark: "#16265C",  // 눈 · 눈썹 · 입 윤곽
    pink: "#FB8E8E",  // 볼터치 · 입 안
    white: "#FFFFFF",
  };
  const MAP = { "#": C.dark, p: C.pink, w: C.white };

  // ===================== 스프라이트 ('.' 은 투명) =====================

  // idle — 아래로 처진 눈, 가운데 가로로 뚫린 틈
  const EYE_IDLE = [
    ".#######.",
    "#########",
    "##.....##",
    ".#######.",
    "..#####..",
    "...###...",
  ];

  // listening — 동그랗게 뜬 눈 (테두리 + 눈동자)
  const EYE_ROUND = [
    "..####..",
    ".#....#.",
    "#..###.#",
    "#..#w#.#",
    "#..###.#",
    ".#....#.",
    "..####..",
  ];

  // processing — 옆으로 긴 눈, 흰 점이 한쪽에
  const EYE_LONG = [
    ".######.",
    "##w#####",
    "########",
    "..####..",
  ];

  // speaking — 웃으며 감은 눈 (위로 솟은 아치)
  const EYE_HAPPY = [
    "..####..",
    ".##..##.",
    "##....##",
    "#......#",
  ];

  // 감은 눈 (깜빡임)
  const EYE_SHUT = ["#######"];

  // 눈썹
  const BROW_FLAT = ["######"];
  const BROW_SHORT = ["#####"];
  const BROW_ARCH = [
    "..###..",
    ".#...#.",
    "#.....#",
  ];

  // 입
  const MOUTH_IDLE = [
    ".###.",
    "#ppp#",
    "#####",
  ];
  const MOUTH_SMALL = [
    "#...#",
    ".###.",
  ];
  // processing — 지그재그 두 프레임 (좌우로 흔들린다)
  const MOUTH_ZIG_A = [
    "...##.",
    ".##..#",
    "##....",
  ];
  const MOUTH_ZIG_B = [
    ".##...",
    "#..##.",
    "....##",
  ];
  // speaking — 크기를 키우는 게 아니라 아랫줄 픽셀이 생겼다 사라진다
  const MOUTH_SHUT = [
    "##########",
    "..######..",
  ];
  const MOUTH_HALF = [
    "##########",
    "#pppppppp#",
    ".#pppppp#.",
    "..######..",
  ];
  const MOUTH_WIDE = [
    "##########",
    "#pppppppp#",
    ".#pppppp#.",
    ".#pppppp#.",
    "..#pppp#..",
    "...####...",
  ];

  const BLUSH = ["p.p"];

  // ===================== 배치 =====================
  const EYE_L_CX = 8, EYE_R_CX = 24;   // 두 눈의 가로 중심
  const MOUTH_CX = 16;
  const BLUSH_L_CX = 3, BLUSH_R_CX = 29;

  let cv, ctx, state = "idle", t0 = performance.now(), mouthLevel = 0;

  function px(x, y, color) {
    ctx.fillStyle = color;
    ctx.fillRect(x * PX, y * PX, PX, PX);
  }

  // 스프라이트를 가로 중심(cx) 기준으로 놓는다. 폭이 달라도 눈 위치가 안 흔들린다.
  function at(rows, cx, gy) {
    const gx = cx - Math.floor(rows[0].length / 2);
    for (let r = 0; r < rows.length; r++) {
      for (let c = 0; c < rows[r].length; c++) {
        const ch = rows[r][c];
        if (ch === ".") continue;
        px(gx + c, gy + r, MAP[ch] || C.dark);
      }
    }
  }

  function eyes(shape, y, blink) {
    if (blink) {
      const by = y + Math.floor(shape.length / 2);
      at(EYE_SHUT, EYE_L_CX, by);
      at(EYE_SHUT, EYE_R_CX, by);
      return;
    }
    at(shape, EYE_L_CX, y);
    at(shape, EYE_R_CX, y);
  }

  // 주기의 '끝'에서 감는다. 시작에서 감으면 페이지를 열자마자 눈을 감고 있다.
  function blinking(periodMs, blinkMs) {
    return (performance.now() % periodMs) > periodMs - blinkMs;
  }

  function blush(y) {
    at(BLUSH, BLUSH_L_CX, y);
    at(BLUSH, BLUSH_R_CX, y);
  }

  // ===================== 상태별 =====================

  function drawIdle() {
    at(BROW_FLAT, EYE_L_CX, 3);
    at(BROW_FLAT, EYE_R_CX, 3);
    eyes(EYE_IDLE, 5, blinking(7000, 260));   // 7초에 한 번 느린 깜빡임
    blush(12);
    at(MOUTH_IDLE, MOUTH_CX, 12);
  }

  function drawListening() {
    // 눈썹은 고정. 눈은 크기 변화 없이 깜빡이기만 한다.
    at(BROW_SHORT, EYE_L_CX, 2);
    at(BROW_SHORT, EYE_R_CX, 2);
    eyes(EYE_ROUND, 4, blinking(2600, 180));
    blush(12);
    at(MOUTH_SMALL, MOUTH_CX, 13);
  }

  function drawProcessing(t) {
    at(BROW_ARCH, EYE_L_CX, 2);
    at(BROW_ARCH, EYE_R_CX, 2);
    eyes(EYE_LONG, 6, blinking(5200, 200));
    blush(12);
    // 입이 좌우로 흔들린다 = 생각 중
    at(Math.floor(t / 420) % 2 ? MOUTH_ZIG_B : MOUTH_ZIG_A, MOUTH_CX, 12);
  }

  function drawSpeaking(t) {
    at(BROW_FLAT, EYE_L_CX, 2);
    at(BROW_FLAT, EYE_R_CX, 2);
    at(EYE_HAPPY, EYE_L_CX, 5);   // 웃으며 감은 눈이라 깜빡임 없음
    at(EYE_HAPPY, EYE_R_CX, 5);
    // 입: 240ms 마다 한 단계. 윗줄을 고정해 크기가 변하는 것처럼 보이지 않게 한다.
    const step = Math.floor(t / 240) % 4;
    const frame = mouthLevel > 0.02
      ? [MOUTH_HALF, MOUTH_WIDE, MOUTH_HALF, MOUTH_SHUT][step]
      : MOUTH_SHUT;
    at(frame, MOUTH_CX, 11);
  }

  const DRAW = { idle: drawIdle, listening: drawListening, processing: drawProcessing, speaking: drawSpeaking };

  function loop() {
    const t = performance.now() - t0;
    ctx.fillStyle = C.bg;
    ctx.fillRect(0, 0, COLS * PX, ROWS * PX);
    try { (DRAW[state] || drawIdle)(t); } catch (e) { /* 한 프레임 실패로 루프가 죽지 않게 */ }
    requestAnimationFrame(loop);
  }

  window.FACE = {
    mount(canvas) {
      cv = canvas;
      cv.width = COLS * PX;
      cv.height = ROWS * PX;
      ctx = cv.getContext("2d");
      ctx.imageSmoothingEnabled = false;
      requestAnimationFrame(loop);
    },
    setState(s) { if (s !== state) { state = s; t0 = performance.now(); } },
    getState() { return state; },
    setLevel(v) { mouthLevel = v; },
    BG: C.bg,
  };
})();
GAEUN_EOF

# ── API 키 ─────────────────────────────────────────
KEY="${GEMINI_KEY:-}"
if [ -z "$KEY" ] && [ -f "$DIR/key.js" ]; then
  KEY="$(sed -n 's/.*GEMINI_KEY *= *"\(.*\)".*/\1/p' "$DIR/key.js")"
fi
if [ -z "$KEY" ]; then
  echo "Gemini API 키를 붙여넣고 Enter (화면엔 안 보임)"
  echo "  발급: https://aistudio.google.com/api-keys"
  read -rs KEY
  echo
fi
KEY="$(printf '%s' "$KEY" | tr -d '[:space:]"')"
[ -n "$KEY" ] || { echo "키가 비어 있어서 종료합니다."; exit 1; }
printf 'window.GEMINI_KEY = "%s";\n' "$KEY" > "$DIR/key.js"
chmod 600 "$DIR/key.js"

# ── 빈 포트 찾아서 서버 띄우기 ─────────────────────────
PORT="$(python3 - <<'PY'
import socket
for p in range(8010, 8100):
    s = socket.socket()
    try:
        s.bind(("127.0.0.1", p)); print(p); break
    except OSError:
        pass
    finally:
        s.close()
PY
)"
python3 -m http.server "$PORT" --bind 127.0.0.1 --directory "$DIR" >/dev/null 2>&1 &
SERVER=$!
trap 'kill $SERVER 2>/dev/null; echo; echo "가은 에이전트 종료"' EXIT INT TERM
sleep 0.5

URL="http://localhost:$PORT/"
echo "가은 에이전트 실행 중: $URL"
echo "종료하려면 Ctrl+C"

# ── 브라우저 열기 (전체 화면 · 클릭 없이 소리 · 마이크 자동 허용) ──────
FLAGS=(--app="$URL" --start-fullscreen --autoplay-policy=no-user-gesture-required --use-fake-ui-for-media-stream --user-data-dir="$DIR/.chrome")
if [ "$(uname)" = "Darwin" ]; then
  if [ -d "/Applications/Google Chrome.app" ]; then
    open -na "Google Chrome" --args "${FLAGS[@]}"
  else
    echo "Chrome 이 없어서 기본 브라우저로 엽니다. 소리가 안 나면 화면을 한 번 클릭하세요."
    open "$URL"
  fi
else
  # 라즈베리 파이 / 리눅스
  # SSH 로 접속해서 실행해도 파이에 연결된 모니터에 뜨게 한다
  export DISPLAY="${DISPLAY:-:0}"
  BROWSER=""
  for b in chromium-browser chromium google-chrome; do
    command -v "$b" >/dev/null 2>&1 && { BROWSER="$b"; break; }
  done
  if [ -n "$BROWSER" ]; then
    "$BROWSER" --kiosk "${FLAGS[@]}" >/dev/null 2>&1 &
  else
    echo "브라우저를 직접 열어 주세요: $URL"
  fi
fi

wait $SERVER
